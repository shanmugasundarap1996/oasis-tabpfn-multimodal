# Draft 8 chain (Amendment 9): waits for part43 (OASIS-1, H) and part49 (OASIS-2 download), then runs
# collect -> part50 fidelity -> part47 freeze (harmonised) -> part48 OASIS-2 locked external test.
$env:KMP_DUPLICATE_LIB_OK = 'TRUE'; $env:HF_HUB_OFFLINE = '1'; $env:TABPFN_DISABLE_TELEMETRY = '1'
Set-Location '.'
$py = 'python'
$log = 'outputs\_runner\draft8_chain.log'
function Busy($pat) { [bool](Get-CimInstance Win32_Process -Filter "name='python.exe'" | Where-Object { $_.CommandLine -match $pat }) }
function Step($name, $args_) {
    Add-Content $log "$(Get-Date -Format s) START $name $args_"
    & $py $name $args_ *>> "outputs\_runner\$($name -replace '\.py','')_$args_.log"
    if ($LASTEXITCODE -ne 0) { Add-Content $log "$(Get-Date -Format s) FAILED $name $args_"; exit 1 }
    Add-Content $log "$(Get-Date -Format s) DONE $name $args_"
}
while (Busy 'part43_harmonised_mri.py oasis1') { Start-Sleep 60 }
$n = (Get-ChildItem '..\mri_harmonised\oasis1' -Filter *.npz).Count
if ($n -lt 166) { Add-Content $log "$(Get-Date -Format s) part43 ended with $n/166 - restarting"; Step 'part43_harmonised_mri.py' 'oasis1' }
Step 'part43_harmonised_mri.py' 'collect'
Step 'part50_h_fidelity.py' ''
Step 'part47_freeze_models.py' 'harmonised'
while (-not (Test-Path '..\oasis2_raw\_SUBSET_DONE.txt')) { Start-Sleep 60 }
Step 'part48_external_locked.py' 'oasis2'
Add-Content $log "$(Get-Date -Format s) CHAIN COMPLETE"
