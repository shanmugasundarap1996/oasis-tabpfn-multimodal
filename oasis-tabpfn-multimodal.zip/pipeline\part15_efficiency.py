"""Part 15 - Efficiency / sustainability.

Each final candidate is fitted on all 166 subjects with a representative configuration
(the most frequently selected hyperparameters in its nested-CV part, where available).
Reported: input dimension, learned parameters, preprocessing parameters (scaler/PCA),
training time (median of 5), inference time per subject (median of 20), peak Python memory.
Performance columns are copied from the nested-CV summaries (Parts 04-10).
"""
import time
import tracemalloc

import numpy as np
import pandas as pd
import torch

import config
from common import PhaseRun, embedding_cols, load_cohort
from gnn import FIXED, DenseGAT, DenseGCN, normalize_adj
from graphs import knn_adjacency, node_features
from models import build

OUT = config.OUTPUT_DIR
SUMMARIES = {
    "Clinical C5 - LR": (OUT / "part04_clinical/summary.csv", "C5_clinical_full", "LR"),
    "MRI 512 - LR": (OUT / "part05_mri/summary.csv", "MRI_512", "LR"),
    "Fusion raw 520 - LR": (OUT / "part07_fusion/summary.csv", "Fusion_raw_520", "LR"),
    "Fusion PCA - LR": (OUT / "part07_fusion/summary.csv", "Fusion_PCA_nested", "LR"),
    "Fusion PCA - SVM": (OUT / "part07_fusion/summary.csv", "Fusion_PCA_nested", "SVM_RBF"),
    "Fusion PCA - RF": (OUT / "part07_fusion/summary.csv", "Fusion_PCA_nested", "RF"),
    "Fusion PCA - XGBoost": (OUT / "part07_fusion/summary.csv", "Fusion_PCA_nested", "XGBoost"),
    "GCN (transductive)": (OUT / "part09_gnn/summary.csv", "GNN_transductive", "GCN"),
    "GAT (transductive)": (OUT / "part09_gnn/summary.csv", "GNN_transductive", "GAT"),
}
PARAMS07 = OUT / "part07_fusion/best_params.csv"
SEL09 = OUT / "part09_gnn/selected_configs.csv"


def modal_params(model):
    p = pd.read_csv(PARAMS07)
    p = p[(p.group == "Fusion_PCA_nested") & (p.model == model)].drop(columns=["group", "model", "seed", "fold"])
    p = p.dropna(axis=1, how="all")
    return {c: p[c].mode().iloc[0] for c in p.columns}


def parse(v, key=""):
    if isinstance(v, float) and v.is_integer() and not any(s in key for s in ("__C", "learning_rate", "gamma")):
        return int(v)
    if isinstance(v, str):
        if v.startswith("PCA("):
            return int(v.split("n_components=")[1].split(",")[0].rstrip(")"))
        if v == "passthrough":
            return None
        if v == "None":
            return None
        try:
            return float(v) if "." in v or "e" in v else int(v)
        except ValueError:
            return v
    return v


def count_sklearn(pipe):
    clf = pipe.named_steps["clf"]
    prep = pipe.named_steps["prep"]
    pre = 0
    for _, t, cols in prep.transformers_:
        if t == "drop":
            continue
        pre += 2 * len(cols)                                   # scaler mean + scale
        if "pca" in t.named_steps and t.named_steps["pca"] != "passthrough":
            pre += t.named_steps["pca"].components_.size + len(cols)
    name = type(clf).__name__
    if name == "LogisticRegression":
        learned = clf.coef_.size + clf.intercept_.size
    elif name == "SVC":
        learned = clf.support_vectors_.size + clf.dual_coef_.size + 1
    elif name == "RandomForestClassifier":
        learned = sum(e.tree_.node_count for e in clf.estimators_)
    else:
        learned = len(clf.get_booster().trees_to_dataframe())
    return learned, pre


def time_it(fn, reps):
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter(); fn(); ts.append(time.perf_counter() - t0)
    return float(np.median(ts))


with PhaseRun("part15_efficiency", __file__,
              inputs=[config.COHORT_FILE, PARAMS07, SEL09] + sorted({str(v[0]) for v in SUMMARIES.values()}),
              params={"train_reps": 5, "inference_reps": 20, "threads": "default"}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    y = df[config.TARGET_COL].to_numpy()
    rows = []

    sk_specs = {
        "Clinical C5 - LR": ("LR", (), config.CLINICAL_FULL, None, {"clf__C": 1.0}),
        "MRI 512 - LR": ("LR", emb, (), None, {"clf__C": 0.01}),
        "Fusion raw 520 - LR": ("LR", emb, config.CLINICAL_FULL, None, {"clf__C": 0.01}),
    }
    for model, label in [("LR", "Fusion PCA - LR"), ("SVM_RBF", "Fusion PCA - SVM"),
                         ("RF", "Fusion PCA - RF"), ("XGBoost", "Fusion PCA - XGBoost")]:
        mp = {key: parse(v, key) for key, v in modal_params(model).items()}
        k = mp.pop("prep__mri__pca", 16)
        sk_specs[label] = (model, emb, config.CLINICAL_FULL, k, mp)

    for label, (model, mri, tab, k, hp) in sk_specs.items():
        pipe, _ = build(model, mri_cols=mri, tab_cols=tab, pca_dim=k)
        pipe.set_params(**{p: v for p, v in hp.items() if v is not None or "max_depth" in p})
        X = df[list(mri) + list(tab)]
        train_t = time_it(lambda: pipe.fit(X, y), 5)
        tracemalloc.start(); pipe.fit(X, y); peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
        infer_t = time_it(lambda: pipe.predict_proba(X), 20) / len(X)
        learned, pre = count_sklearn(pipe)
        rows.append({"model": label, "input_dim": len(mri) + len(tab),
                     "model_input_dim": (k if k else len(mri)) + len(tab),
                     "learned_params": learned, "preprocessing_params": pre,
                     "train_time_s": train_t, "inference_ms_per_subject": 1000 * infer_t,
                     "peak_python_mem_MB": peak / 2 ** 20, "config": str({"pca_k": k, **hp})})
        print(f"  {label} done")

    sel = pd.read_csv(SEL09)
    torch.set_num_threads(4)
    for arch, Model in [("GCN", DenseGCN), ("GAT", DenseGAT)]:
        s = sel[sel.arch == arch]
        cfg = {**FIXED, "graph": s.graph.mode().iloc[0], "k": int(s.k.mode().iloc[0]),
               "weight_decay": float(s.weight_decay.mode().iloc[0])}
        idx = np.arange(len(df))
        Xn, _ = node_features(df, emb, idx, idx[:1], cfg["graph"])
        A = knn_adjacency(Xn, cfg["k"])
        x, A_hat = torch.tensor(Xn, dtype=torch.float32), normalize_adj(A)
        mask = torch.tensor((A + np.eye(len(A))) > 0)
        yt = torch.tensor(y)

        def train():
            torch.manual_seed(0)
            m = Model(Xn.shape[1], cfg["hidden"], cfg["dropout"])
            opt = torch.optim.Adam(m.parameters(), lr=cfg["lr"], weight_decay=cfg["weight_decay"])
            for _ in range(cfg["epochs"]):
                m.train(); opt.zero_grad()
                torch.nn.functional.cross_entropy(m(x, A_hat, mask), yt).backward(); opt.step()
            return m
        train_t = time_it(train, 5)
        tracemalloc.start(); m = train(); peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
        m.eval()
        with torch.no_grad():
            infer_t = time_it(lambda: m(x, A_hat, mask), 20) / len(df)
        rows.append({"model": f"{arch} (transductive)", "input_dim": len(emb) + len(config.CLINICAL_FULL),
                     "model_input_dim": Xn.shape[1], "learned_params": sum(p.numel() for p in m.parameters()),
                     "preprocessing_params": None, "train_time_s": train_t,
                     "inference_ms_per_subject": 1000 * infer_t, "peak_python_mem_MB": peak / 2 ** 20,
                     "config": str(cfg)})
        print(f"  {arch} done")

    eff = pd.DataFrame(rows)
    perf = []
    for label, (f, g, m) in SUMMARIES.items():
        s = pd.read_csv(f)
        s = s[(s.group == g) & (s.model == m)].iloc[0]
        perf.append({"model": label, "balanced_accuracy": s.balanced_accuracy_mean, "mcc": s.mcc_mean,
                     "roc_auc": s.roc_auc_mean, "brier": s.brier_mean})
    eff = eff.merge(pd.DataFrame(perf), on="model", how="left")
    mri_k = eff.model_input_dim - len(config.CLINICAL_FULL)
    eff["mri_dim_reduction_pct"] = np.where(eff.model.str.contains("PCA"), 100 * (1 - mri_k / 512), np.nan)
    run.save_csv(eff, "efficiency_table.csv")
    pd.set_option("display.width", 250)
    print("\n", eff.drop(columns="config").round(4).to_string(index=False))
