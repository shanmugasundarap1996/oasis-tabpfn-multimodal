"""Part 30 - Re-run of the proposed framework and key baselines with the documented, label-free MRI
features of Part 29 (frozen ImageNet ResNet18), on the identical cohort (N = 166) and frozen folds.

Also: embedding audit (label-permutation test, cross-validated prediction of nWBV), and paired
comparison of Kaggle-embedding vs own-embedding results for the same models. Resumable per fold."""
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LogisticRegression, RidgeCV
from sklearn.metrics import r2_score
from sklearn.model_selection import cross_val_predict, permutation_test_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

import config
from common import (PhaseRun, check_oof_integrity, embedding_cols, iter_outer_folds, load_cohort,
                    run_nested_cv, summarize)
from compare_tools import paired_table, pca_grid, tabpfn_spec
from models import build

OWN = config.RAW_DIR / "mri_embeddings_own.csv"
V5 = config.OUTPUT_DIR / "part19_v5_tabpfn" / "fold_metrics.csv"
P07 = config.OUTPUT_DIR / "part07_fusion" / "fold_metrics.csv"
P06 = config.OUTPUT_DIR / "part06_pca" / "nested_fold_metrics.csv"

with PhaseRun("part30_own_mri_benchmark", __file__,
              inputs=[config.COHORT_FILE, OWN, config.FOLDS_FILE, config.INNER_FOLDS_FILE, V5, P07, P06]) as run:
    base = load_cohort()
    old_emb = embedding_cols(base)
    own = pd.read_csv(OWN)
    df = base.drop(columns=old_emb).merge(own, on="subject_id", how="left", validate="one_to_one")
    assert len(df) == len(base) and df[old_emb].notna().all().all(), "own embedding missing for some subjects"
    df = df.set_index("subject_id").loc[base.subject_id].reset_index()          # identical row order
    run.save_csv(df[["subject_id", "target_binary"] + old_emb], "cohort_own_embeddings.csv")
    emb = embedding_cols(df)
    y = df[config.TARGET_COL].to_numpy()
    C5, T = config.CLINICAL_FULL, config.TRANSPORTABLE_CLINICAL

    # ---------------- embedding audit
    seed42 = [(tr, te) for s, f, tr, te in iter_outer_folds(df) if s == 42]
    X = df[emb].to_numpy(float)
    score, perm, p = permutation_test_score(make_pipeline(StandardScaler(), LogisticRegression(C=1.0, max_iter=5000,
                                            class_weight="balanced")), X, y, cv=seed42, scoring="roc_auc",
                                            n_permutations=1000, random_state=42, n_jobs=-1)
    nwbv = cross_val_predict(make_pipeline(StandardScaler(), RidgeCV(alphas=np.logspace(-2, 4, 25))), X,
                             df.nWBV.to_numpy(float), cv=seed42)
    audit = pd.DataFrame([{"true_label_auc": score, "perm_auc_mean": perm.mean(), "perm_auc_sd": perm.std(),
                           "perm_auc_max": perm.max(), "p_value": p, "nWBV_cv_r2": r2_score(df.nWBV, nwbv),
                           "nWBV_cv_pearson": stats.pearsonr(df.nWBV, nwbv)[0]}])
    run.save_csv(audit, "embedding_audit.csv")
    print("audit:\n", audit.round(4).to_string(index=False), flush=True)

    # ---------------- nested benchmark
    specs = [tabpfn_spec("OwnMRI", emb, C5), tabpfn_spec("OwnMRI", emb, T, name="TabPFN_transportable")]
    for name in ["RF", "LR", "XGBoost"]:
        pipe, grid = build(name, mri_cols=emb, tab_cols=C5, pca_dim=8, extra_grid=pca_grid())
        specs.append({"group": "OwnMRI", "name": f"Fusion_PCA_{name}", "features": emb + C5, "pipeline": pipe, "grid": grid})
    pipe, grid = build("LR", mri_cols=emb, pca_dim=8, extra_grid=pca_grid())
    specs.append({"group": "OwnMRI", "name": "MRI_only_LR", "features": emb, "pipeline": pipe, "grid": grid})
    folds, preds, params = run_nested_cv(df, specs, ckpt_dir=str(run.dir / "_ckpt"))
    run.save_csv(folds, "fold_metrics.csv"); run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summ = summarize(folds); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))

    clin = pd.read_csv(config.OUTPUT_DIR / "part04_clinical" / "fold_metrics.csv")
    others = {m: folds[folds.model == m] for m in folds.model.unique() if m != "TabPFN_v2"}
    others["Clinical_C5_LR"] = clin[(clin.group == "C5_clinical_full") & (clin.model == "LR")]
    others["Clinical_C5_XGBoost"] = clin[(clin.group == "C5_clinical_full") & (clin.model == "XGBoost")]
    tab = paired_table(folds[folds.model == "TabPFN_v2"], "TabPFN_v2 (own MRI)", others)
    run.save_csv(tab, "tabpfn_vs_baselines_own.csv")
    print(tab[tab.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))

    # ---------------- Kaggle vs own embeddings (same model, same folds)
    v5 = pd.read_csv(V5); p7 = pd.read_csv(P07); p6 = pd.read_csv(P06)
    pairs = [("TabPFN_v2", v5), ("Fusion_PCA_RF", p7[(p7.group == "Fusion_PCA_nested") & (p7.model == "RF")]),
             ("Fusion_PCA_LR", p7[(p7.group == "Fusion_PCA_nested") & (p7.model == "LR")]),
             ("MRI_only_LR", p6[p6.model == "LR"])]
    kv = pd.concat([paired_table(folds[folds.model == m], f"{m} own", {f"{m} Kaggle": k}) for m, k in pairs])
    run.save_csv(kv, "own_vs_kaggle.csv")
    print(kv[kv.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))
    assert check_oof_integrity(preds, df)
