"""Part 07 - Conventional multimodal fusion, fusion ablation, transportable model.

Early fusion = [MRI block || clinical block], each block imputed/standardised inside the
training fold; MRI block optionally reduced by PCA with k tuned in inner CV.
Deltas versus Part 04 (clinical) and Part 06 (MRI) are paired on the identical frozen folds.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

import config
from common import (PhaseRun, check_oof_integrity, embedding_cols, load_cohort,
                    run_nested_cv, summarize)
from models import CLASSIFIERS, build

NESTED_K = [k for k in config.PCA_DIMS if k <= 64]
PART04 = config.OUTPUT_DIR / "part04_clinical" / "fold_metrics.csv"
PART06 = config.OUTPUT_DIR / "part06_pca" / "nested_fold_metrics.csv"
KEY = ["model", "seed", "fold"]
DELTA_METRICS = ["balanced_accuracy", "macro_f1", "mcc", "roc_auc", "pr_auc", "brier"]


def pca_grid():
    return {"prep__mri__pca": [PCA(n_components=k, random_state=42) for k in NESTED_K] + ["passthrough"]}


def paired_delta(A, B, label):
    rows = []
    A, B = A.set_index(KEY), B.set_index(KEY)
    for model in sorted(set(A.index.get_level_values(0)) & set(B.index.get_level_values(0))):
        for m in DELTA_METRICS:
            d = (A.loc[model, m] - B.loc[model, m]).dropna().to_numpy()
            boot = np.random.default_rng(0).choice(d, (5000, len(d))).mean(1)
            rows.append({"comparison": label, "model": model, "metric": m,
                         "mean_A": A.loc[model, m].mean(), "mean_B": B.loc[model, m].mean(),
                         "mean_delta": d.mean(), "ci95_low": np.percentile(boot, 2.5),
                         "ci95_high": np.percentile(boot, 97.5),
                         "folds_A_better": int((d > 0).sum()), "n_folds": len(d)})
    return rows


with PhaseRun("part07_fusion", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PART04, PART06],
              params={"nested_k": NESTED_K + ["passthrough(512)"],
                      "clinical_full": config.CLINICAL_FULL,
                      "transportable": config.TRANSPORTABLE_CLINICAL}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    specs = []

    # main fusion: raw 520-D and PCA-nested, four models each
    for name in CLASSIFIERS:
        pipe, grid = build(name, mri_cols=emb, tab_cols=config.CLINICAL_FULL)
        specs.append({"group": "Fusion_raw_520", "name": name, "features": emb + config.CLINICAL_FULL,
                      "pipeline": pipe, "grid": grid})
        pipe, grid = build(name, mri_cols=emb, tab_cols=config.CLINICAL_FULL, pca_dim=8, extra_grid=pca_grid())
        specs.append({"group": "Fusion_PCA_nested", "name": name, "features": emb + config.CLINICAL_FULL,
                      "pipeline": pipe, "grid": grid})
        # transportable model (variables available in OASIS-3 / ADNI)
        pipe, grid = build(name, mri_cols=emb, tab_cols=config.TRANSPORTABLE_CLINICAL, pca_dim=8,
                           extra_grid=pca_grid())
        specs.append({"group": "Transportable_PCA_nested", "name": name,
                      "features": emb + config.TRANSPORTABLE_CLINICAL, "pipeline": pipe, "grid": grid})

    # ablation (LR, PCA-nested): which clinical information adds to MRI
    ablation_sets = {
        "Abl_MRI+Age": ["Age"],
        "Abl_MRI+MMSE": ["MMSE"],
        "Abl_MRI+Age+MMSE": ["Age", "MMSE"],
        "Abl_MRI+C4_noMMSE": config.CLINICAL_NO_MMSE,
        "Abl_MRI+C5_full": config.CLINICAL_FULL,
    }
    for g, tab in ablation_sets.items():
        pipe, grid = build("LR", mri_cols=emb, tab_cols=tab, pca_dim=8, extra_grid=pca_grid())
        specs.append({"group": g, "name": "LR", "features": emb + tab, "pipeline": pipe, "grid": grid})
    # same ablation for the strongest non-linear learner family
    pipe, grid = build("XGBoost", mri_cols=emb, tab_cols=config.CLINICAL_NO_MMSE, pca_dim=8, extra_grid=pca_grid())
    specs.append({"group": "Abl_MRI+C4_noMMSE", "name": "XGBoost",
                  "features": emb + config.CLINICAL_NO_MMSE, "pipeline": pipe, "grid": grid})

    print(f"{len(specs)} configurations x 25 outer folds")
    folds, preds, params = run_nested_cv(df, specs)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summary = summarize(folds)
    run.save_csv(summary, "summary.csv")
    print("\nFusion results (mean ± SD over 25 outer folds):")
    print(summary.sort_values(["group", "mcc_mean"], ascending=[True, False])
          [["group", "model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))

    if "prep__mri__pca" in params:
        params["selected_k"] = params["prep__mri__pca"].map(
            lambda s: np.nan if pd.isna(s) else
            (512 if s == "passthrough" else int(s.split("n_components=")[1].split(",")[0].rstrip(")"))))
        freq = params.dropna(subset=["selected_k"]).groupby(["group", "model", "selected_k"]).size().unstack(fill_value=0)
        run.save_csv(freq.reset_index(), "selected_k_frequency.csv")
        print("\nSelected MRI PCA k (25 folds):\n", freq.to_string())

    # ---------------- paired deltas (RQ1)
    clin = pd.read_csv(PART04)
    mri = pd.read_csv(PART06)
    c5 = clin[clin.group == "C5_clinical_full"]
    c4 = clin[clin.group == "C4_clinical_no_MMSE"]
    rows = []
    for g in ["Fusion_PCA_nested", "Fusion_raw_520"]:
        F = folds[folds.group == g]
        rows += paired_delta(F, c5, f"{g} - Clinical C5")
        rows += paired_delta(F, mri, f"{g} - MRI PCA nested")
    T = folds[folds.group == "Transportable_PCA_nested"]
    rows += paired_delta(T, folds[folds.group == "Fusion_PCA_nested"], "Transportable - Fusion_PCA_nested")
    A4 = folds[folds.group == "Abl_MRI+C4_noMMSE"]
    rows += paired_delta(A4, c4, "MRI+C4 (no MMSE) - Clinical C4")
    rows += paired_delta(A4, mri, "MRI+C4 (no MMSE) - MRI PCA nested")
    deltas = pd.DataFrame(rows)
    run.save_csv(deltas, "paired_deltas.csv")
    print("\nPaired deltas (MCC):")
    print(deltas[deltas.metric == "mcc"][["comparison", "model", "mean_A", "mean_B", "mean_delta",
                                          "ci95_low", "ci95_high", "folds_A_better"]].round(4).to_string(index=False))

    checks = pd.DataFrame([
        ("25 outer folds per configuration", bool((folds.groupby(["group", "model"]).size() == 25).all())),
        ("each subject predicted once per seed per configuration", check_oof_integrity(preds, df)),
        ("CDR / label not in any feature list",
         all(not set(s["features"]) & set(config.FORBIDDEN_PREDICTORS) for s in specs)),
        ("Part 04 / Part 06 deltas paired on 25 identical folds", bool((deltas.n_folds == 25).all())),
    ], columns=["check", "passed"])
    print("\n", checks.to_string(index=False))
    run.save_csv(checks, "integrity_checks.csv")

    # ---------------- figure: clinical -> MRI -> fusion (best model per family by MCC)
    fam = pd.concat([summarize(c5).assign(family="Clinical C5"),
                     summarize(c4).assign(family="Clinical C4 (no MMSE)"),
                     summarize(mri).assign(family="MRI (PCA nested)"),
                     summary[summary.group == "Abl_MRI+C4_noMMSE"].assign(family="MRI + C4 (no MMSE)"),
                     summary[summary.group == "Fusion_PCA_nested"].assign(family="Fusion PCA (C5)"),
                     summary[summary.group == "Transportable_PCA_nested"].assign(family="Transportable")])
    best = fam.sort_values("mcc_mean").groupby("family").tail(1)
    order = ["Clinical C4 (no MMSE)", "Clinical C5", "MRI (PCA nested)", "MRI + C4 (no MMSE)",
             "Transportable", "Fusion PCA (C5)"]
    best = best.set_index("family").loc[order]
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    for ax, m in zip(axes, ["balanced_accuracy", "mcc", "roc_auc"]):
        ax.barh(range(len(order)), best[f"{m}_mean"], xerr=best[f"{m}_sd"], color="#5b7fa6", capsize=3)
        ax.set_yticks(range(len(order)))
        ax.set_yticklabels([f"{o}\n({best.loc[o, 'model']})" for o in order], fontsize=8)
        ax.set_title(m.replace("_", " "))
    fig.suptitle("Part 07 - best model per representation (25 outer folds)")
    fig.tight_layout()
    run.save_fig(fig, "fig_modality_comparison.png")
    plt.close(fig)
