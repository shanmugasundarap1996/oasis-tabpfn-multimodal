"""Classical model zoo with frozen hyperparameter grids (same as Part 04).
Optional PCA on the MRI block is fitted inside each training fold via the pipeline."""
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from xgboost import XGBClassifier

class CappedPCA(PCA):
    """PCA whose n_components is capped at min(n_samples, n_features) of the data it is fitted on
    (inner training folds have ~88 subjects, so k = 96 / 128 become 88 there). The effective
    number of components is available as n_components_ after fitting."""

    def fit(self, X, y=None):
        return self._capped(super().fit, X)

    def fit_transform(self, X, y=None):
        return self._capped(super().fit_transform, X)

    def _capped(self, fn, X):
        k = self.n_components
        if isinstance(k, int):
            self.n_components = min(k, *X.shape)
        try:
            return fn(X)
        finally:
            self.n_components = k


CLASSIFIERS = {
    "LR": (lambda s: LogisticRegression(max_iter=5000, class_weight="balanced", random_state=s),
           {"clf__C": [0.01, 0.1, 1, 10]}),
    "SVM_RBF": (lambda s: SVC(kernel="rbf", probability=True, class_weight="balanced", random_state=s),
                {"clf__C": [0.1, 1, 10], "clf__gamma": ["scale", 0.01, 0.1]}),
    "RF": (lambda s: RandomForestClassifier(n_estimators=300, class_weight="balanced",
                                            random_state=s, n_jobs=1),
           {"clf__max_depth": [None, 3, 5], "clf__min_samples_leaf": [1, 3, 5]}),
    "XGBoost": (lambda s: XGBClassifier(subsample=0.8, colsample_bytree=0.8, eval_metric="logloss",
                                        random_state=s, n_jobs=1, verbosity=0),
                {"clf__max_depth": [2, 3], "clf__n_estimators": [100, 300],
                 "clf__learning_rate": [0.03, 0.1]}),
}


def preprocessor(mri_cols=(), tab_cols=(), pca_dim=None, seed=42):
    """Median-impute + standardise each block; optional PCA on the MRI block only."""
    blocks = []
    if mri_cols:
        steps = [("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]
        if pca_dim is not None:
            steps.append(("pca", CappedPCA(n_components=pca_dim, random_state=seed)))
        blocks.append(("mri", Pipeline(steps), list(mri_cols)))
    if tab_cols:
        blocks.append(("tab", Pipeline([("imp", SimpleImputer(strategy="median")),
                                        ("sc", StandardScaler())]), list(tab_cols)))
    return ColumnTransformer(blocks)


def build(model, mri_cols=(), tab_cols=(), pca_dim=None, seed=42, extra_grid=None):
    """Return (pipeline, grid). extra_grid can add e.g. {'prep__mri__pca__n_components': [...]}."""
    make, grid = CLASSIFIERS[model]
    pipe = Pipeline([("prep", preprocessor(mri_cols, tab_cols, pca_dim, seed)), ("clf", make(seed))])
    return pipe, {**grid, **(extra_grid or {})}
