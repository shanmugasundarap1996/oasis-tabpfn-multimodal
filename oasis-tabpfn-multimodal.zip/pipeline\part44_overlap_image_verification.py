"""Part 44 - Amendment 8: verify the OASIS-1/OASIS-2 record linkage by raw-image fingerprint, and categorise
all 150 OASIS-2 participants (confirmed / probable / possible / no detected overlap).

For each OASIS-2 first-visit session on disk (partial download), every raw MPRAGE repeat is compared with every
raw repeat of the best-matching OASIS-1 session (Pearson correlation of raw voxel intensities; both releases use
the same 256 x 256 x 128 acquisition layout). Null: the same OASIS-2 session against the other, non-matched
OASIS-1 sessions of this set."""
import tarfile
from itertools import product

import nibabel as nib
import numpy as np
import pandas as pd

import config
from common import PhaseRun

O2_RAW = config.BASE_DIR / "oasis2_raw"
O1_RAW = config.BASE_DIR / "oasis1_raw"
TMP = config.BASE_DIR / "mri_harmonised" / "_tmp_part44"
P42 = config.OUTPUT_DIR / "part42_external_clinical"
THRESHOLD = 0.99


def load(path):
    return np.asarray(nib.load(str(path)).dataobj).squeeze().astype(np.float32).ravel()


def max_corr(a_list, b_list):
    return max(float(np.corrcoef(a, b)[0, 1]) for a, b in product(a_list, b_list))


with PhaseRun("part44_overlap_image_verification", __file__,
              inputs=[P42 / "overlap_diagnostic_pairs.csv", P42 / "overlap_flags.csv"],
              params={"threshold": THRESHOLD}) as run:
    pairs = pd.read_csv(P42 / "overlap_diagnostic_pairs.csv")
    o2_dirs = {p.name.replace("_MR1", ""): p for p in O2_RAW.glob("OAS2_RAW_PART*/*_MR1")}
    sub = pairs[pairs.oasis2.isin(o2_dirs)].reset_index(drop=True)
    need = set(sub.oasis1)
    print(f"{len(sub)} OASIS-2 sessions on disk with a candidate; OASIS-1 sessions needed: {len(need)}", flush=True)

    # extract the needed OASIS-1 raw repeats
    TMP.mkdir(parents=True, exist_ok=True)
    have = {p.name for p in TMP.iterdir() if p.is_dir()}
    for disc in sorted(O1_RAW.glob("*_disc*.tar.gz")):
        if need <= have:
            break
        with tarfile.open(disc, "r:gz") as tf:
            for m in tf:
                parts = m.name.split("/")
                if len(parts) >= 4 and parts[-2] == "RAW" and parts[-3] in need and m.name.endswith((".img", ".hdr")):
                    m.name = f"{parts[-3]}/{parts[-1]}"
                    tf.extract(m, TMP)
        have = {p.name for p in TMP.iterdir() if p.is_dir()}
        print(f"  {disc.name}: {len(need & have)}/{len(need)} OASIS-1 sessions extracted", flush=True)

    o1 = {s: [load(f) for f in sorted((TMP / s).glob("*mpr-*_anon.img"))] for s in need}
    o2 = {s: [load(f) for f in sorted((o2_dirs[s] / "RAW").glob("mpr-*.nifti.img"))] for s in sub.oasis2}
    rows = []
    for _, r in sub.iterrows():
        match = max_corr(o2[r.oasis2], o1[r.oasis1])
        null = [max_corr(o2[r.oasis2], o1[s]) for s in need if s != r.oasis1]
        rows.append({"oasis2": r.oasis2, "oasis1_candidate": r.oasis1, "d_etiv_pct": r.d_etiv_pct,
                     "same_age": r.age1 == r.age2, "same_mmse": r.mmse1 == r.mmse2, "same_cdr": r.cdr1 == r.cdr2,
                     "max_corr_candidate": match, "max_corr_null": max(null), "median_corr_null": float(np.median(null)),
                     "image_confirmed": match >= THRESHOLD and match > max(null)})
    ver = pd.DataFrame(rows).sort_values("d_etiv_pct")
    run.save_csv(ver, "image_verification.csv")
    print(ver.round(4).to_string(index=False), flush=True)

    # categories for all 150 OASIS-2 participants
    flags = pd.read_csv(P42 / "overlap_flags.csv")
    cat = flags[["subject_id", "n_candidates"]].merge(pairs.rename(columns={"oasis2": "subject_id"}), on="subject_id",
                                                     how="left")
    conf = set(ver.oasis2[ver.image_confirmed])
    cat["category"] = np.select(
        [cat.subject_id.isin(conf), cat.d_etiv_pct < 0.5, cat.n_candidates > 0],
        ["confirmed (image)", "probable (record linkage)", "possible (broad rule)"], "no detected overlap")
    run.save_csv(cat, "overlap_categories.csv")
    tight = cat[cat.d_etiv_pct < 0.5]
    summary = pd.DataFrame([
        {"item": k, "n": v} for k, v in cat.category.value_counts().items()] + [
        {"item": "eTIV<0.5%: identical age", "n": int((tight.age1 == tight.age2).sum())},
        {"item": "eTIV<0.5%: identical MMSE", "n": int((tight.mmse1 == tight.mmse2).sum())},
        {"item": "eTIV<0.5%: identical age and MMSE", "n": int(((tight.age1 == tight.age2) & (tight.mmse1 == tight.mmse2)).sum())},
        {"item": "eTIV<0.5%: identical CDR", "n": int((tight.cdr1 == tight.cdr2).sum())},
        {"item": "eTIV<0.5%: total", "n": len(tight)},
        {"item": "image-checked sessions", "n": len(ver)},
        {"item": "image-checked with eTIV<0.5%", "n": int((ver.d_etiv_pct < 0.5).sum())},
        {"item": "image-checked with eTIV<0.5% and confirmed", "n": int(((ver.d_etiv_pct < 0.5) & ver.image_confirmed).sum())},
        {"item": "image-checked with eTIV>=0.5% and confirmed", "n": int(((ver.d_etiv_pct >= 0.5) & ver.image_confirmed).sum())}])
    run.save_csv(summary, "overlap_summary.csv")
    print(summary.to_string(index=False))
