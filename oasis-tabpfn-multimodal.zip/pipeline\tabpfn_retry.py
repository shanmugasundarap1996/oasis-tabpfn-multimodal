"""Guard against ARPACK failures (error -8, LAPACK dsteqr) in TabPFN's internal 'add SVD features' preprocessing
step, seen deterministically for one training matrix in Part 40 (seed 42, fold 5) and sporadically in Part 22.

Only when sklearn's TruncatedSVD(algorithm="arpack") raises, the same step is refitted with
TruncatedSVD(algorithm="randomized", n_iter=20), which estimates the same leading singular subspace. Every fallback
is printed and appended to outputs/_runner/tabpfn_svd_fallbacks.txt for reporting. Import once in the main process;
grid-search workers need no patch because GridSearchCV scores failed candidates as NaN (none occurred)."""
import time
from pathlib import Path

from scipy.sparse.linalg import ArpackError
from tabpfn import TabPFNClassifier
from tabpfn.preprocessing.steps import add_svd_features_step as _svd

_LOG = Path(__file__).resolve().parent / "outputs" / "_runner" / "tabpfn_svd_fallbacks.txt"
_orig_svd_fit = _svd.AddSVDFeaturesStep._fit


def _svd_fit_with_fallback(self, X, feature_schema):
    try:
        return _orig_svd_fit(self, X, feature_schema)
    except ArpackError:
        n_samples, n_features = X.shape
        seed, _ = _svd.infer_random_state(self.random_state)
        t = _svd.get_svd_features_transformer(self.global_transformer_name, n_samples, n_features, random_state=seed)
        t.set_params(svd__algorithm="randomized", svd__n_iter=20)
        t.fit(_svd._pin_layout(X))
        self.is_no_op, self.transformer_, self.feature_schema_updated_ = False, t, feature_schema
        msg = f"{time.strftime('%Y-%m-%dT%H:%M:%S')} ARPACK failed on X {X.shape}; randomized SVD fallback used"
        print("  [tabpfn_retry] " + msg, flush=True)
        with open(_LOG, "a", encoding="utf-8") as fh:
            fh.write(msg + "\n")
        return feature_schema


_svd.AddSVDFeaturesStep._fit = _svd_fit_with_fallback

_orig_fit = TabPFNClassifier.fit


def _fit_with_retry(self, X, y, *args, **kwargs):
    for attempt in range(3):
        try:
            return _orig_fit(self, X, y, *args, **kwargs)
        except ArpackError:
            if attempt == 2:
                raise
            print(f"  [tabpfn_retry] ARPACK failure outside the SVD step, retry {attempt + 1}", flush=True)
            time.sleep(2)


TabPFNClassifier.fit = _fit_with_retry
