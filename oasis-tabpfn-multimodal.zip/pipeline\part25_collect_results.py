"""Part 25 - Collect every result needed to continue the paper into ONE text file:
outputs/FINAL_RESULTS_SUMMARY.txt  (bring this file back to continue)."""
import json

import pandas as pd

import config
from common import PhaseRun

OUT = config.OUTPUT_DIR
VERSIONS = ["v1_stacking", "v2_ordinal", "v3_gated_net", "v4_metric_learning", "v5_tabpfn",
            "v6_tabpfn_threshold", "v7_tabpfn_rf_ensemble", "v8_tabpfn_kbag", "v9_tabpfn_featsel",
            "v10_superlearner", "v11_save_pfn"]


def read(path):
    try:
        return pd.read_csv(path)
    except Exception:
        return None


with PhaseRun("part25_collect_results", __file__) as run:
    L = ["FINAL RESULTS SUMMARY", "=" * 70, ""]

    L += ["1. SIGNIFICANCE SEARCH (baseline Fusion PCA-RF MCC 0.852; rule: MCC higher, p < 0.05/11 = 0.0045, AUC not worse)", ""]
    rows = []
    for v in VERSIONS:
        f = OUT / f"part19_{v}" / "verdict.json"
        if f.exists():
            j = json.loads(f.read_text(encoding="utf-8"))
            rows.append({"version": v, "MCC": round(j["mean_mcc_new"], 4), "AUC": round(j["mean_auc_new"], 4),
                         "dMCC": round(j["delta_mcc"], 4), "p_MCC": round(j["p_wilcoxon_mcc"], 4),
                         "SIGNIFICANT": j["SIGNIFICANTLY_BETTER"]})
        else:
            rows.append({"version": v, "MCC": "not run"})
    L += [pd.DataFrame(rows).to_string(index=False), ""]

    L += ["2. PART 22 - TabPFN analyses", ""]
    for title, f in [("Modality ablation", "ablation_summary.csv"), ("Full minus ablated", "ablation_deltas.csv"),
                     ("Permutation importance (AUC drop)", "permutation_importance.csv"),
                     ("Missing MRI at test time", "missing_mri_summary.csv"),
                     ("Calibration slopes", "calibration_slopes.csv"), ("Errors by CDR", "error_by_cdr.csv")]:
        t = read(OUT / "part22_tabpfn_analyses" / f)
        L += [f"--- {title}", t.round(4).to_string(index=False) if t is not None else "not available", ""]
    eff = OUT / "part22_tabpfn_analyses" / "efficiency_summary.json"
    L += ["--- Efficiency", eff.read_text(encoding="utf-8") if eff.exists() else "not available", ""]

    L += ["3. PART 23 - Subgroups", ""]
    t = read(OUT / "part23_subgroups" / "subgroup_summary.csv")
    L += [t.round(3).to_string(index=False) if t is not None else "not available", ""]

    L += ["4. FIGURES (paper/figures)", ""]
    figs = sorted((config.BASE_DIR / "paper" / "figures").glob("*.pdf"))
    L += [f.name for f in figs] or ["none"]
    L += ["", "5. QUEUE LOG", ""]
    q = OUT / "_runner" / "queue_status.txt"
    L += [q.read_text(encoding="utf-8-sig") if q.exists() else "no queue log"]

    text = "\n".join(str(x) for x in L)
    (OUT / "FINAL_RESULTS_SUMMARY.txt").write_text(text, encoding="utf-8")
    run.save_text(text, "FINAL_RESULTS_SUMMARY.txt")
    print(text)
