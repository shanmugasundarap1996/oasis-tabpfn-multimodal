"""Part 05 - MRI embedding audit + MRI-only baselines.

1. Integrity: duplicates, near-duplicates, value range (what kind of features these are).
2. Content: which clinical quantities the embedding encodes (descriptive PC correlations,
   and cross-validated prediction of nWBV / eTIV / Age from the embedding).
3. Leakage sanity: label-permutation test on the frozen seed-42 folds.
4. MRI-only LR / SVM-RBF / RF / XGBoost with nested tuning on the 25 frozen folds.
5. Provenance checklist (what can and cannot be verified from the CSV).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression, RidgeCV
from sklearn.metrics import r2_score
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.model_selection import cross_val_predict, permutation_test_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

import config
from common import (PhaseRun, check_oof_integrity, embedding_cols, iter_outer_folds,
                    load_cohort, run_nested_cv, summarize)
from models import CLASSIFIERS, build

N_PERMUTATIONS = 1000

with PhaseRun("part05_mri", __file__,
              inputs=[config.COHORT_FILE, config.EMBED_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE],
              params={"n_permutations": N_PERMUTATIONS, "permutation_model": "LR C=1, seed-42 folds",
                      "grids": {k: v[1] for k, v in CLASSIFIERS.items()}}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    X = df[emb].to_numpy(float)
    y = df[config.TARGET_COL].to_numpy()
    seed42 = [(tr, te) for s, f, tr, te in iter_outer_folds(df) if s == 42]

    # ---------------- 1. integrity
    full = pd.read_csv(config.EMBED_FILE)
    Xf = full[emb].to_numpy(float)
    S = cosine_similarity(Xf)
    np.fill_diagonal(S, -1)
    var = X.var(axis=0)
    integrity = pd.DataFrame([
        ("subjects in full embedding file", len(full)),
        ("subjects in cohort", len(df)),
        ("embedding dimensions", len(emb)),
        ("exact duplicate rows (full file)", int(pd.DataFrame(Xf).duplicated(keep=False).sum())),
        ("pairs cosine > 0.9999 (full file)", int(np.triu(S > 0.9999, 1).sum())),
        ("max pairwise cosine (full file)", round(float(S.max()), 6)),
        ("median nearest-neighbour cosine", round(float(np.median(S.max(1))), 6)),
        ("min value", round(float(X.min()), 6)),
        ("max value", round(float(X.max()), 6)),
        ("fraction of exact zeros", round(float((X == 0).mean()), 6)),
        ("all values non-negative", bool((X >= 0).all())),
        ("near-constant dims (var < 1e-8)", int((var < 1e-8).sum())),
        ("missing values", int(np.isnan(X).sum())),
    ], columns=["item", "value"])
    print(integrity.to_string(index=False))
    run.save_csv(integrity, "embedding_integrity.csv")

    # ---------------- 2. what the embedding encodes
    pcs = PCA(n_components=10, random_state=42).fit_transform(StandardScaler().fit_transform(X))
    corr_rows = []
    for v in ["Age", "MMSE", "nWBV", "eTIV", "ASF", "Educ", "sex_binary"]:
        ok = df[v].notna().to_numpy()
        for k in range(10):
            rho, p = stats.spearmanr(pcs[ok, k], df.loc[ok, v])
            corr_rows.append({"variable": v, "pc": k + 1, "spearman_rho": rho, "p_value": p})
    corr = pd.DataFrame(corr_rows)
    run.save_csv(corr, "pc_clinical_correlations_descriptive.csv")
    print("\nMax |rho| of first 10 PCs with each variable (descriptive, whole-cohort PCA):")
    print(corr.assign(a=corr.spearman_rho.abs()).sort_values("a").groupby("variable").tail(1)
          [["variable", "pc", "spearman_rho", "p_value"]].to_string(index=False))

    reg_rows = []
    ridge = make_pipeline(StandardScaler(), RidgeCV(alphas=np.logspace(-2, 4, 25)))
    for v in ["nWBV", "eTIV", "Age", "MMSE"]:
        pred = cross_val_predict(ridge, X, df[v].to_numpy(float), cv=seed42)
        reg_rows.append({"target": v, "cv_r2": r2_score(df[v], pred),
                         "pearson_r": stats.pearsonr(df[v], pred)[0]})
    reg = pd.DataFrame(reg_rows)
    print("\nCross-validated prediction of clinical quantities from the embedding (seed-42 folds):")
    print(reg.round(4).to_string(index=False))
    run.save_csv(reg, "embedding_predicts_clinical_cv.csv")

    # ---------------- 3. label-permutation test
    perm_model = make_pipeline(StandardScaler(),
                               LogisticRegression(C=1.0, max_iter=5000, class_weight="balanced"))
    score, perm_scores, p_perm = permutation_test_score(
        perm_model, X, y, cv=seed42, scoring="roc_auc", n_permutations=N_PERMUTATIONS,
        random_state=42, n_jobs=-1)
    perm = pd.DataFrame([{"true_label_auc": score, "perm_auc_mean": perm_scores.mean(),
                          "perm_auc_sd": perm_scores.std(), "perm_auc_95pct": np.percentile(perm_scores, 95),
                          "perm_auc_max": perm_scores.max(), "p_value": p_perm,
                          "n_permutations": N_PERMUTATIONS}])
    print("\nLabel-permutation test:\n", perm.round(4).to_string(index=False))
    run.save_csv(perm, "permutation_test.csv")
    run.save_csv(pd.DataFrame({"perm_auc": perm_scores}), "permutation_null_distribution.csv")

    fig, ax = plt.subplots(figsize=(6, 3.8))
    ax.hist(perm_scores, bins=40, color="#9aa9bd")
    ax.axvline(score, color="#b03a2e", lw=2, label=f"true labels AUC = {score:.3f}")
    ax.set_xlabel("ROC-AUC"); ax.set_ylabel("Permutations")
    ax.set_title(f"MRI embedding label-permutation test (p = {p_perm:.4f})")
    ax.legend()
    fig.tight_layout()
    run.save_fig(fig, "fig_permutation_test.png")
    plt.close(fig)

    # ---------------- 4. MRI-only baselines (nested)
    specs = []
    for name in CLASSIFIERS:
        pipe, grid = build(name, mri_cols=emb)
        specs.append({"group": "MRI_512", "name": name, "features": emb, "pipeline": pipe, "grid": grid})
    folds, preds, params = run_nested_cv(df, specs)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summary = summarize(folds)
    run.save_csv(summary, "summary.csv")
    print("\nMRI-only (mean ± SD over 25 outer folds):")
    print(summary[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))

    checks = pd.DataFrame([
        ("25 outer folds per model", bool((folds.groupby("model").size() == 25).all())),
        ("each subject predicted once per seed per model", check_oof_integrity(preds, df)),
        ("one embedding row per subject", bool(full.subject_id.is_unique)),
        ("no exact duplicate embeddings", int(integrity.set_index("item").loc["exact duplicate rows (full file)", "value"]) == 0),
        ("permutation null centred at chance (|mean-0.5| < 0.05)", bool(abs(perm_scores.mean() - 0.5) < 0.05)),
    ], columns=["check", "passed"])
    print("\n", checks.to_string(index=False))
    run.save_csv(checks, "integrity_checks.csv")

    # ---------------- 5. provenance checklist
    nonneg = bool((X >= 0).all())
    zeros = float((X == 0).mean())
    md = f"""# MRI embedding provenance checklist

Status: **UNVERIFIED** - the code that produced `mri_embeddings.csv` is not in the project.
The items below must be confirmed from that code (or replaced by Part 05b) before submission.

| Item | Evidence available from the CSV | Status |
|---|---|---|
| Backbone = ResNet18, 512-D global-average-pooled output | 512 dims; all values non-negative = {nonneg}; exact-zero fraction = {zeros:.4f} (consistent with post-ReLU average pooling) | partially consistent |
| 2D slice(s) vs 3D volume; which slices | not recoverable from CSV | UNVERIFIED |
| Input image (raw / atlas-registered / skull-stripped / bias-corrected) | not recoverable | UNVERIFIED |
| Intensity normalisation, resizing, channel replication | not recoverable | UNVERIFIED |
| Weights: frozen ImageNet vs fine-tuned on dementia labels | not recoverable | UNVERIFIED - critical |
| If fine-tuned: subject-level split, no slices of a test subject in training | not recoverable | UNVERIFIED - critical |
| If fine-tuned: were CV test subjects used to train the extractor? | not recoverable | UNVERIFIED - critical |
| One vector per subject (slice aggregation rule) | one row per subject confirmed; aggregation rule unknown | partially verified |
| Label-permutation test | true AUC {score:.3f} vs null {perm_scores.mean():.3f} ± {perm_scores.std():.3f}, p = {p_perm:.4f} | shows signal is label-related, cannot rule out extractor leakage |

Note: the label column in the embedding file uses the names "Non Demented / Very mild Dementia / Dementia",
which match the folder names of public slice-level OASIS image collections. If the extractor was
fine-tuned on such a collection with a random (slice-level) split, MRI results would be optimistically biased.
Part 05b (frozen ImageNet ResNet18 on the original OASIS-1 images) removes this risk.
"""
    run.save_text(md, "mri_provenance_checklist.md")
