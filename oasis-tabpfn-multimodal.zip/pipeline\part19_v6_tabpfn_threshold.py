"""Part 19 v6 - TabPFN (k selected in v5) + decision threshold tuned for MCC on inner out-of-fold
predictions. TabPFN's AUC exceeded the baseline significantly; a fold-specific threshold may turn that
ranking advantage into a classification (MCC) advantage. Resumable via cache.py."""
import config
from common import PhaseRun
from newmethods import BASELINE_FILE, PROTOCOL_FILE, run_cached_version

KEYS = ["tabpfn|full|sel"]

with PhaseRun("part19_v6_tabpfn_threshold", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"keys": KEYS, "threshold": "inner-OOF MCC-optimal, grid 0.05-0.95"}) as run:
    run_cached_version(run, "v6_tabpfn_threshold", KEYS, lambda P, y: (P[KEYS[0]]["oof"], P[KEYS[0]]["test"], None))
