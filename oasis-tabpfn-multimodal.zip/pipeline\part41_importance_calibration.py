"""Part 41 - Amendment 6, M6 + M7 + M8 (label-free ResNet MRI features, N = 166, frozen Part 30 folds).

M7: permutation importance of the proposed model by block (MRI / MMSE / volumetrics / demographics): per outer fold the
    model is refit with the k selected by inner CV in Part 30, each block is permuted jointly across test subjects
    (5 repeats), and the drop in AUC and rise in Brier score are recorded.
M6: calibration slope and calibration-in-the-large (pooled out-of-fold predictions per seed, averaged over seeds) for
    Part 30 / Part 33 models; global Holm correction over all paired tests of Parts 30, 31 (ablation), 33 and 36.
M8: per-sex calibration of the proposed model, and the female-male AUC gap within the CDR 0 vs 0.5 subset
    (subject bootstrap, 2000 resamples)."""
import re

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, roc_auc_score
import config
import tabpfn_retry  # noqa: F401  (retries sporadic ARPACK failures)
from common import PhaseRun, embedding_cols, iter_outer_folds, load_cohort
from compare_tools import _holm, tabpfn_spec

OWN = config.RAW_DIR / "mri_embeddings_own.csv"
O = config.OUTPUT_DIR
P30, P31, P33, P36 = (O / "part30_own_mri_benchmark", O / "part31_own_mri_extended", O / "part33_own_modern_and_recal",
                      O / "part36_morph_benchmark")
BLOCKS = {"Demographics": ["Age", "sex_binary", "Educ", "SES"], "Volumetrics": ["eTIV", "nWBV", "ASF"], "MMSE": ["MMSE"]}
N_PERM = 5
PERM_SEEDS = (42, 2026)   # time-feasibility restriction (Amendment 6 note, 21:35, before any importance was summarised)


def cal_slope_citl(y, p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    lp = np.log(p / (1 - p)).reshape(-1, 1)
    slope = LogisticRegression(C=1e6, max_iter=1000).fit(lp, y).coef_[0, 0]
    return slope, float(np.mean(y) - np.mean(p))


with PhaseRun("part41_importance_calibration", __file__,
              inputs=[config.COHORT_FILE, OWN, P30 / "best_params.csv", P30 / "oof_predictions.csv",
                      P33 / "oof_predictions.csv"], params={"n_perm": N_PERM, "blocks": BLOCKS}) as run:
    base = load_cohort()
    df = base.drop(columns=embedding_cols(base)).merge(pd.read_csv(OWN), on="subject_id", how="left", validate="one_to_one")
    df = df.set_index("subject_id").loc[base.subject_id].reset_index()
    emb, C5 = embedding_cols(df), config.CLINICAL_FULL
    blocks = {"MRI (512-D, PCA)": emb, **BLOCKS}
    y = df.target_binary.to_numpy()

    # ---------------- M7 permutation importance (resumable per fold)
    bp = pd.read_csv(P30 / "best_params.csv")
    bp = bp[bp.model == "TabPFN_v2"].set_index(["seed", "fold"])
    ck = run.dir / "_perm_ckpt"; ck.mkdir(exist_ok=True)
    rows = []
    for seed, fold, tr, te in iter_outer_folds(df):
        if seed not in PERM_SEEDS:
            continue
        f = ck / f"s{seed}_f{fold}.csv"
        if f.exists():
            rows.append(pd.read_csv(f)); continue
        k = int(re.search(r"n_components=(\d+)", str(bp.loc[(seed, fold)].filter(like="pca").iloc[0])).group(1))
        pipe = tabpfn_spec("perm", emb, C5)["pipeline"].set_params(prep__mri__pca=PCA(n_components=k, random_state=42))
        Xtr, Xte = df.iloc[tr][emb + C5], df.iloc[te][emb + C5].reset_index(drop=True)
        pipe.fit(Xtr, y[tr])
        p0 = pipe.predict_proba(Xte)[:, 1]
        auc0, br0 = roc_auc_score(y[te], p0), brier_score_loss(y[te], p0)
        rng = np.random.default_rng(1000 * seed + fold)
        out = []
        for b, cols in blocks.items():
            for r in range(N_PERM):
                Xp = Xte.copy()
                Xp[cols] = Xte[cols].to_numpy()[rng.permutation(len(Xte))]
                pp = pipe.predict_proba(Xp)[:, 1]
                out.append({"seed": seed, "fold": fold, "k": k, "block": b, "repeat": r,
                            "delta_auc": auc0 - roc_auc_score(y[te], pp), "delta_brier": brier_score_loss(y[te], pp) - br0})
        d = pd.DataFrame(out); tmp = f.with_suffix(".tmp"); d.to_csv(tmp, index=False); tmp.replace(f)
        rows.append(d); print(f"  perm seed {seed} fold {fold} done", flush=True)
    perm = pd.concat(rows)
    fold_mean = perm.groupby(["block", "seed", "fold"])[["delta_auc", "delta_brier"]].mean().reset_index()
    imp = fold_mean.groupby("block").agg(delta_auc_mean=("delta_auc", "mean"), delta_auc_sd=("delta_auc", "std"),
                                         delta_brier_mean=("delta_brier", "mean"), delta_brier_sd=("delta_brier", "std"),
                                         folds_auc_drop_gt0=("delta_auc", lambda s: int((s > 0).sum())))
    imp = imp.sort_values("delta_auc_mean", ascending=False).reset_index()
    run.save_csv(perm, "permutation_importance_raw.csv"); run.save_csv(imp, "permutation_importance.csv")
    print(imp.round(4).to_string(index=False), flush=True)

    # ---------------- M6 calibration slope / CITL
    oof = pd.concat([pd.read_csv(P30 / "oof_predictions.csv"), pd.read_csv(P33 / "oof_predictions.csv")])
    cal = []
    for m, g in oof.groupby("model"):
        s = [cal_slope_citl(h.y_true.to_numpy(), h.y_prob.to_numpy()) for _, h in g.groupby("seed")]
        cal.append({"model": m, "calibration_slope": np.mean([a for a, _ in s]), "slope_sd_over_seeds": np.std([a for a, _ in s]),
                    "calibration_in_the_large": np.mean([b for _, b in s])})
    cal = pd.DataFrame(cal).sort_values("model"); run.save_csv(cal, "calibration_slope.csv")
    print(cal.round(3).to_string(index=False), flush=True)

    tabs = {"part30_main": P30 / "tabpfn_vs_baselines_own.csv", "part31_ablation": P31 / "ablation_vs_full.csv",
            "part33_modern": P33 / "tabpfn_vs_modern_recal_own.csv", "part36_morph": P36 / "v12_vs_baselines.csv"}
    allp = pd.concat([pd.read_csv(p).assign(family=k) for k, p in tabs.items()], ignore_index=True)
    allp["p_holm_global"] = _holm(allp.p_wilcoxon)
    allp["sig_family"] = allp.p_holm < 0.05; allp["sig_global"] = allp.p_holm_global < 0.05
    run.save_csv(allp, "global_holm.csv")
    print(allp[allp.sig_family][["family", "comparator", "metric", "delta", "p_holm", "p_holm_global", "sig_global"]]
          .round(4).to_string(index=False), flush=True)

    # ---------------- M8 subgroup calibration and CDR-restricted sex gap
    o = oof[oof.model == "TabPFN_v2"].merge(df[["subject_id", "sex_binary", "CDR"]], on="subject_id")
    sg = []
    for sx, g in o.groupby("sex_binary"):
        s = [cal_slope_citl(h.y_true.to_numpy(), h.y_prob.to_numpy()) for _, h in g.groupby("seed")]
        sg.append({"sex": "female" if sx == 0 else "male", "n": g.subject_id.nunique(),
                   "brier": np.mean([brier_score_loss(h.y_true, h.y_prob) for _, h in g.groupby("seed")]),
                   "calibration_slope": np.mean([a for a, _ in s]), "calibration_in_the_large": np.mean([b for _, b in s]),
                   "share_cdr_gt0": float((g.drop_duplicates("subject_id").CDR > 0).mean())})
    sub = o[o.CDR.isin([0, 0.5])]
    P = sub.pivot_table(index="subject_id", columns="seed", values="y_prob")
    meta = sub.drop_duplicates("subject_id").set_index("subject_id").loc[P.index]
    yv, Pv, sexv = meta.y_true.to_numpy(), P.to_numpy(), meta.sex_binary.to_numpy()

    def auc_sex(idx):
        return np.mean([roc_auc_score(yv[idx], Pv[idx, j]) for j in range(Pv.shape[1])])
    fi, mi = np.where(sexv == 0)[0], np.where(sexv == 1)[0]
    d0 = auc_sex(fi) - auc_sex(mi)
    rng = np.random.default_rng(42); boot = []
    for _ in range(2000):
        a, b = rng.choice(fi, len(fi)), rng.choice(mi, len(mi))
        if len(set(yv[a])) < 2 or len(set(yv[b])) < 2:
            continue
        boot.append(auc_sex(a) - auc_sex(b))
    lo, hi = np.percentile(boot, [2.5, 97.5])
    sg.append({"sex": "female-male AUC gap, CDR 0 vs 0.5 only", "n": len(yv), "brier": np.nan,
               "calibration_slope": d0, "calibration_in_the_large": np.nan, "share_cdr_gt0": np.nan,
               "auc_female": auc_sex(fi), "auc_male": auc_sex(mi), "gap_ci_low": lo, "gap_ci_high": hi})
    sg = pd.DataFrame(sg); run.save_csv(sg, "subgroup_calibration.csv")
    print(sg.round(3).to_string(index=False))
