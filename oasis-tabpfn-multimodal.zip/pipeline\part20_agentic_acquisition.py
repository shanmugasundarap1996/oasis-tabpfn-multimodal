"""Part 20 - Agentic cost-aware multimodal acquisition (see AGENT_PROTOCOL.md).

Per outer fold:
  1. Evidence agent: one LR per information state S0..S3 (C tuned on inner folds).
  2. Cross-fitted (inner-fold OOF) probabilities of the training subjects for every state ->
     per-subject Brier loss at every state.
  3. Planner: RF regressors R[s][t] predict the Brier loss at terminal state t from the
     information available at state s.
  4. Test patients: perceive -> plan (argmin_t E[Brier_t] + lambda * extra cost) -> act
     (acquire cheapest modality towards t) -> observe -> re-plan, until STOP.
"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.base import clone
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GridSearchCV

import config
from common import (PhaseRun, binary_metrics, embedding_cols, inner_splits, iter_outer_folds,
                    load_cohort)
from models import build

PROTOCOL = config.PIPELINE_DIR / "AGENT_PROTOCOL.md"
BASELINE = config.OUTPUT_DIR / "part07_fusion" / "fold_metrics.csv"
DEMO = ["Age", "sex_binary", "Educ", "SES"]
BIO = ["eTIV", "nWBV", "ASF"]
STATES = {"S0": (False, False), "S1": (True, False), "S2": (False, True), "S3": (True, True)}  # (MMSE, MRI)
REACH = {"S0": ["S0", "S1", "S2", "S3"], "S1": ["S1", "S3"], "S2": ["S2", "S3"], "S3": ["S3"]}
LAMBDAS = [0, 0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05]
MRI_COSTS = {"main_10to1": 10, "sens_5to1": 5, "sens_20to1": 20}
TAUS = [0.6, 0.7, 0.8, 0.9, 0.95]
NI_MARGIN = 0.03
MISSING_RATES = [0.3, 0.5]
N_RANDOM = 20


def cost(state, mri_cost):
    mmse, mri = STATES[state]
    return int(mmse) * 1 + int(mri) * mri_cost


def state_spec(state, emb):
    mmse, mri = STATES[state]
    tab = DEMO + (["MMSE"] if mmse else []) + (BIO if mri else [])
    mri_cols = emb if mri else []
    pipe, grid = build("LR", mri_cols=mri_cols, tab_cols=tab, pca_dim=8 if mri else None)
    return pipe, {"clf__C": grid["clf__C"]}, list(mri_cols) + tab


def entropy(p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return -(p * np.log(p) + (1 - p) * np.log(1 - p))


def planner_features(model, X, p):
    Z = model.named_steps["prep"].transform(X)
    return np.c_[Z, p, entropy(p)]


def run_agent(E, lam, mri_cost, mri_available):
    """Sequential decisions for all test subjects. E[(s, t)] = planner's predicted Brier loss at
    terminal t using only the information available at s (precomputed per subject; the value at
    state s is only consulted once the agent has actually reached s). Returns stop states, paths."""
    n = len(mri_available)
    stops, paths = [], []
    for i in range(n):
        s, path = "S0", ["S0"]
        while True:
            cand = [t for t in REACH[s] if mri_available[i] or not STATES[t][1]]
            if cand == [s]:
                break                         # nothing left to acquire
            score = {t: E[(s, t)][i] + lam * (cost(t, mri_cost) - cost(s, mri_cost)) for t in cand}
            t = min(score, key=score.get)
            if t == s:
                break
            if s == "S0" and t == "S3":
                s = "S1"                      # cheapest modality first, then re-plan
            else:
                s = t
            path.append(s)
        stops.append(s)
        paths.append(">".join(path))
    return np.array(stops), paths


with PhaseRun("part20_agent", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL, BASELINE],
              params={"lambdas": LAMBDAS, "mri_costs": MRI_COSTS, "taus": TAUS, "ni_margin": NI_MARGIN,
                      "missing_rates": MISSING_RATES, "n_random": N_RANDOM}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    y = df[config.TARGET_COL].to_numpy()
    rows, decisions = [], []

    for seed, fold, tr, te in iter_outer_folds(df):
        cv_in = inner_splits(df, seed, fold, tr)
        models, feats, P_te, P_oof = {}, {}, {}, {}
        # 1. evidence agent per state + 2. cross-fitted OOF on training subjects
        for s in STATES:
            pipe, grid, cols = state_spec(s, emb)
            gs = GridSearchCV(pipe, grid, cv=cv_in, scoring=config.TUNING_SCORING, n_jobs=-1)
            gs.fit(df.iloc[tr][cols], y[tr])
            models[s], feats[s] = gs.best_estimator_, cols
            P_te[s] = models[s].predict_proba(df.iloc[te][cols])[:, 1]
            oof = np.zeros(len(tr))
            for itr, iva in cv_in:
                m = clone(models[s]).fit(df.iloc[tr[itr]][cols], y[tr[itr]])
                oof[iva] = m.predict_proba(df.iloc[tr[iva]][cols])[:, 1]
            P_oof[s] = oof
        brier_oof = {s: (P_oof[s] - y[tr]) ** 2 for s in STATES}
        # 3. planner regressors
        Z_tr = {s: planner_features(models[s], df.iloc[tr][feats[s]], P_oof[s]) for s in ["S0", "S1", "S2"]}
        Z_te = {s: planner_features(models[s], df.iloc[te][feats[s]], P_te[s]) for s in ["S0", "S1", "S2"]}
        R = {}
        for s in ["S0", "S1", "S2"]:
            for t in REACH[s]:
                R[(s, t)] = RandomForestRegressor(n_estimators=300, min_samples_leaf=10, random_state=seed,
                                                  n_jobs=-1).fit(Z_tr[s], brier_oof[t])
        E = {k: r.predict(Z_te[k[0]]) for k, r in R.items()}

        def record(policy, param, stop_states, mri_cost, scenario="full_availability", extra=None):
            prob = np.array([P_te[s][i] for i, s in enumerate(stop_states)])
            m = binary_metrics(y[te], (prob >= 0.5).astype(int), prob)
            m.update({"policy": policy, "param": param, "mri_cost_ratio": mri_cost, "scenario": scenario,
                      "seed": seed, "fold": fold,
                      "mean_cost": float(np.mean([cost(s, mri_cost) for s in stop_states])),
                      "mri_rate": float(np.mean([STATES[s][1] for s in stop_states])),
                      "mmse_rate": float(np.mean([STATES[s][0] for s in stop_states]))})
            if extra:
                m.update(extra)
            rows.append(m)

        full_avail = np.ones(len(te), dtype=bool)
        # static policies
        for s in STATES:
            for c in MRI_COSTS.values():
                record("static", s, np.array([s] * len(te)), c)
        # heuristic uncertainty agent
        for tau in TAUS:
            st = []
            for i in range(len(te)):
                s = "S0"
                if max(P_te["S0"][i], 1 - P_te["S0"][i]) < tau:
                    s = "S1"
                    if max(P_te["S1"][i], 1 - P_te["S1"][i]) < tau:
                        s = "S3"
                st.append(s)
            for c in MRI_COSTS.values():
                record("heuristic_uncertainty", tau, np.array(st), c)
        # learned agent (+ random control at matched MRI rate, main cost only)
        for cname, c in MRI_COSTS.items():
            for lam in LAMBDAS:
                stop, paths = run_agent(E, lam, c, full_avail)
                record("agent", lam, stop, c)
                if cname == "main_10to1":
                    decisions += [{"seed": seed, "fold": fold, "lambda": lam, "subject_id": df.subject_id.iloc[j],
                                   "CDR": df.CDR.iloc[j], "y_true": int(y[j]), "path": p, "stop": s,
                                   "p_S0": P_te["S0"][k], "p_final": P_te[s][k]}
                                  for k, (j, p, s) in enumerate(zip(te, paths, stop))]
                    q = int(round(np.mean([STATES[s][1] for s in stop]) * len(te)))
                    rng = np.random.default_rng(seed * 100 + fold)
                    mets = []
                    for _ in range(N_RANDOM):
                        st = np.array(["S1"] * len(te), dtype=object)
                        st[rng.choice(len(te), q, replace=False)] = "S3"
                        prob = np.array([P_te[s][i] for i, s in enumerate(st)])
                        mets.append(binary_metrics(y[te], (prob >= 0.5).astype(int), prob))
                    mm = pd.DataFrame(mets).mean(numeric_only=True).to_dict()
                    mm.update({"policy": "random_matched", "param": lam, "mri_cost_ratio": c,
                               "scenario": "full_availability", "seed": seed, "fold": fold,
                               "mean_cost": 1 + q / len(te) * c, "mri_rate": q / len(te), "mmse_rate": 1.0})
                    rows.append(mm)
        # missing-MRI scenario
        c = MRI_COSTS["main_10to1"]
        for r in MISSING_RATES:
            for rep in range(5):
                rng = np.random.default_rng(seed * 1000 + fold * 10 + rep)
                avail = np.ones(len(te), dtype=bool)
                avail[rng.choice(len(te), int(round(r * len(te))), replace=False)] = False
                for lam in [0, 0.002, 0.005]:
                    stop, _ = run_agent(E, lam, c, avail)
                    record("agent", lam, stop, c, scenario=f"MRI_missing_{r}", extra={"rep": rep})
                Xm = df.iloc[te][feats["S3"]].copy()
                Xm.loc[Xm.index[~avail], emb + BIO] = np.nan
                prob = models["S3"].predict_proba(Xm)[:, 1]
                m = binary_metrics(y[te], (prob >= 0.5).astype(int), prob)
                m.update({"policy": "static_full_imputed", "param": "S3", "mri_cost_ratio": c,
                          "scenario": f"MRI_missing_{r}", "seed": seed, "fold": fold, "rep": rep,
                          "mean_cost": 1 + avail.mean() * c, "mri_rate": avail.mean(), "mmse_rate": 1.0})
                rows.append(m)
        print(f"  seed {seed} fold {fold} done")

    res = pd.DataFrame(rows)
    run.save_csv(res, "agent_fold_metrics.csv")
    run.save_csv(pd.DataFrame(decisions), "agent_decisions_main_cost.csv")

    # ---------------- summaries
    full = res[res.scenario == "full_availability"]
    summ = full.groupby(["mri_cost_ratio", "policy", "param"]).agg(
        mcc=("mcc", "mean"), mcc_sd=("mcc", "std"), macro_f1=("macro_f1", "mean"),
        balanced_accuracy=("balanced_accuracy", "mean"), roc_auc=("roc_auc", "mean"),
        brier=("brier", "mean"), ece=("ece", "mean"),
        mean_cost=("mean_cost", "mean"), mri_rate=("mri_rate", "mean"), mmse_rate=("mmse_rate", "mean")).reset_index()
    run.save_csv(summ, "frontier_summary.csv")
    main = summ[summ.mri_cost_ratio == MRI_COSTS["main_10to1"]]
    pd.set_option("display.width", 250)
    print("\nMain cost ratio (MRI:MMSE = 10:1):\n", main.round(4).to_string(index=False))

    # ---------------- pre-registered success test: agent vs static S3 (main cost)
    key = ["seed", "fold"]
    ref = full[(full.policy == "static") & (full.param == "S3") &
               (full.mri_cost_ratio == MRI_COSTS["main_10to1"])].set_index(key).sort_index()
    ni = []
    for lam in LAMBDAS:
        a = full[(full.policy == "agent") & (full.param == lam) &
                 (full.mri_cost_ratio == MRI_COSTS["main_10to1"])].set_index(key).sort_index()
        d = (a.mcc - ref.mcc).to_numpy()
        boot = np.random.default_rng(0).choice(d, (10000, len(d))).mean(1)
        rnd = full[(full.policy == "random_matched") & (full.param == lam)].set_index(key).sort_index()
        dr = (a.mcc - rnd.mcc).to_numpy()
        ni.append({"lambda": lam, "agent_mcc": a.mcc.mean(), "static_full_mcc": ref.mcc.mean(),
                   "delta_mcc": d.mean(), "ci95_low": np.percentile(boot, 2.5), "ci95_high": np.percentile(boot, 97.5),
                   "p_noninferiority": float((boot <= -NI_MARGIN).mean()),
                   "agent_auc": a.roc_auc.mean(), "agent_mri_rate": a.mri_rate.mean(),
                   "agent_mean_cost": a.mean_cost.mean(), "static_full_cost": ref.mean_cost.mean(),
                   "random_matched_mcc": rnd.mcc.mean(), "delta_vs_random": dr.mean(),
                   "p_vs_random_wilcoxon": stats.wilcoxon(dr).pvalue if np.any(dr != 0) else 1.0})
    ni = pd.DataFrame(ni)
    order = np.argsort(ni.p_noninferiority.to_numpy())
    holm, running = np.empty(len(ni)), 0.0
    for rank, i in enumerate(order):
        running = max(running, (len(ni) - rank) * ni.p_noninferiority.iloc[i])
        holm[i] = min(running, 1.0)
    ni["p_ni_holm"] = holm
    ni["mri_reduction_ge_20pct"] = ni.agent_mri_rate <= 0.80
    ni["SUCCESS"] = ni.mri_reduction_ge_20pct & (ni.p_ni_holm < 0.05)
    run.save_csv(ni, "noninferiority_vs_full_fusion.csv")
    print("\nNon-inferiority vs static full fusion (margin 0.03 MCC, Holm over lambdas):\n",
          ni.round(4).to_string(index=False))
    verdict = {"criterion": "MRI rate <= 80% AND Holm-adjusted non-inferiority p < 0.05 (margin 0.03 MCC)",
               "any_success": bool(ni.SUCCESS.any()),
               "successful_lambdas": ni.loc[ni.SUCCESS, "lambda"].tolist(),
               "best_operating_point": (ni[ni.SUCCESS].sort_values("agent_mri_rate").iloc[0].to_dict()
                                        if ni.SUCCESS.any() else None)}
    run.save_json(verdict, "verdict.json")
    print("\nVERDICT:", json.dumps(verdict, indent=2, default=str))

    miss = res[res.scenario != "full_availability"].groupby(["scenario", "policy", "param"]).agg(
        mcc=("mcc", "mean"), roc_auc=("roc_auc", "mean"), mean_cost=("mean_cost", "mean"),
        mri_rate=("mri_rate", "mean")).reset_index()
    run.save_csv(miss, "missing_mri_summary.csv")
    print("\nMissing-MRI scenario:\n", miss.round(4).to_string(index=False))

    dec = pd.DataFrame(decisions)
    paths = dec.groupby(["lambda", "CDR"]).path.value_counts(normalize=True).rename("share").reset_index()
    run.save_csv(paths, "agent_paths_by_cdr.csv")

    # ---------------- frontier figure
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.8))
    for ax, xcol, xl in [(axes[0], "mean_cost", "mean acquisition cost per patient (MMSE = 1, MRI = 10)"),
                         (axes[1], "mri_rate", "fraction of patients sent to MRI")]:
        for pol, style in [("agent", "o-"), ("heuristic_uncertainty", "s--"), ("random_matched", "x:")]:
            s = main[main.policy == pol].sort_values(xcol)
            ax.plot(s[xcol], s.mcc, style, label=pol.replace("_", " "))
        st = main[main.policy == "static"]
        ax.scatter(st[xcol], st.mcc, c="k", marker="D", zorder=5, label="static S0/S1/S2/S3")
        for _, r in st.iterrows():
            ax.annotate(r.param, (r[xcol], r.mcc), textcoords="offset points", xytext=(5, -10), fontsize=8)
        ax.set_xlabel(xl); ax.set_ylabel("MCC (25 outer folds)")
    axes[0].legend(fontsize=8)
    fig.suptitle("Agentic acquisition: diagnostic performance vs acquisition burden")
    fig.tight_layout()
    run.save_fig(fig, "fig_performance_cost_frontier.png")
    plt.close(fig)
