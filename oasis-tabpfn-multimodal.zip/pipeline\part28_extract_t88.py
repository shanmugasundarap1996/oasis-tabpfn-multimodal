"""Part 28 - Extract the atlas-registered, skull-stripped, bias-corrected T1 images
(PROCESSED/MPRAGE/T88_111/*_t88_masked_gfc.img/.hdr) from the 12 OASIS-1 archives.

Each archive is processed as soon as its download is verified complete (status log line 'OK <name>');
a per-archive marker makes the step resumable. Only the T88 images are extracted (not the full archives)."""
import re
import tarfile
import time
from pathlib import Path

import pandas as pd

import config
from common import PhaseRun

RAW = config.BASE_DIR / "oasis1_raw"
OUT = config.BASE_DIR / "oasis1_t88"
PATTERN = re.compile(r"T88_111/[^/]*_t88_masked_gfc\.(img|hdr)$")
MAX_WAIT_H = 6


def downloaded_ok(i):
    log = RAW / "download_status.txt"
    return log.exists() and f"OK   oasis_cross-sectional_disc{i}.tar.gz" in log.read_text(encoding="utf-8-sig")


with PhaseRun("part28_extract_t88", __file__, params={"pattern": PATTERN.pattern}) as run:
    OUT.mkdir(exist_ok=True)
    start, pending = time.time(), list(range(1, 13))
    while pending:
        progressed = False
        for i in list(pending):
            marker = OUT / f"_done_disc{i}.txt"
            if marker.exists():
                pending.remove(i); continue
            if not downloaded_ok(i):
                continue
            n = 0
            with tarfile.open(RAW / f"oasis_cross-sectional_disc{i}.tar.gz", "r:gz") as tf:
                for m in tf:
                    if m.isfile() and PATTERN.search(m.name):
                        sess = m.name.split("/")[1]                       # e.g. OAS1_0001_MR1
                        dst = OUT / sess / Path(m.name).name
                        dst.parent.mkdir(exist_ok=True)
                        if not (dst.exists() and dst.stat().st_size == m.size):
                            tmp = dst.with_suffix(dst.suffix + ".part")
                            with tf.extractfile(m) as src, open(tmp, "wb") as fh:
                                fh.write(src.read())
                            tmp.replace(dst)
                        n += 1
            marker.write_text(f"{n} files", encoding="utf-8")
            print(f"  disc{i}: {n} files extracted", flush=True)
            pending.remove(i); progressed = True
        if pending and not progressed:
            if time.time() - start > MAX_WAIT_H * 3600:
                raise TimeoutError(f"archives not downloaded after {MAX_WAIT_H} h: {pending}")
            time.sleep(60)
    sessions = sorted(p.name for p in OUT.iterdir() if p.is_dir())
    inv = pd.DataFrame({"session": sessions,
                        "img": [bool(list((OUT / s).glob("*.img"))) for s in sessions],
                        "hdr": [bool(list((OUT / s).glob("*.hdr"))) for s in sessions]})
    run.save_csv(inv, "t88_inventory.csv")
    print(f"sessions: {len(inv)}, complete pairs: {int((inv.img & inv.hdr).sum())}")
    assert (inv.img & inv.hdr).all()
