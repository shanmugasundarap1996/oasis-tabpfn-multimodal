"""Part 22 - Analyses of the proposed system (TabPFN v2 multimodal framework).

Per outer fold the TabPFN pipeline is refitted with the MRI PCA k that inner CV selected in
Part 19 v5 (no new tuning), then:
 (a) modality ablation with the same in-context learner (k fixed at 16 for MRI-containing sets,
     a priori, since Part 06 showed performance is flat in k): clinical C4, C5, MRI only,
     MRI+MMSE, transportable (Age, Sex, Educ, MMSE + MRI);
 (b) group permutation importance on the test fold (drop in ROC-AUC when one variable or the
     whole MRI block is permuted);
 (c) missing-MRI robustness (MRI block missing for 30 / 50 / 100 % of test subjects, imputed with
     training medians by the pipeline);
 (d) efficiency (fit and inference time, parameter count);
 (e) per-subject error analysis and calibration (slope / intercept).
"""
import json
import os
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.calibration import calibration_curve
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from tabpfn import TabPFNClassifier
from tabpfn.constants import ModelVersion

import config
from cache import get as cache_get
from common import PhaseRun, binary_metrics, embedding_cols, iter_outer_folds, load_cohort, summarize
from models import preprocessor

V5 = config.OUTPUT_DIR / "part19_v5_tabpfn"
RF_OOF = config.OUTPUT_DIR / "part07_fusion" / "oof_predictions.csv"
GROUPS = ["MRI embedding", "MMSE", "Age", "sex_binary", "Educ", "SES", "eTIV", "nWBV", "ASF"]
MISSING = [0.3, 0.5, 1.0]
ABLATION_K = 16


def tabpfn_pipe(mri_cols, tab_cols, k):
    return Pipeline([("prep", preprocessor(mri_cols, tab_cols, pca_dim=k if mri_cols else None)),
                     ("clf", TabPFNClassifier.create_default_for_version(ModelVersion.V2, device="cpu",
                                                                         random_state=42))])


def slope_intercept(y, p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    lr = LogisticRegression(C=1e6, max_iter=1000).fit(np.log(p / (1 - p)).reshape(-1, 1), y)
    return float(lr.coef_[0, 0]), float(lr.intercept_[0])


with PhaseRun("part22_tabpfn_analyses", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, V5 / "best_params.csv", V5 / "oof_predictions.csv", RF_OOF],
              params={"ablation_k": ABLATION_K, "groups": GROUPS, "missing_rates": MISSING}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    y = df[config.TARGET_COL].to_numpy()
    full_feats = emb + config.CLINICAL_FULL
    sel = pd.read_csv(V5 / "best_params.csv")
    sel["k"] = sel.prep__mri__pca.str.extract(r"n_components=(\d+)").astype(int)
    ablations = {
        "TabPFN clinical C4 (no MMSE)": ([], config.CLINICAL_NO_MMSE),
        "TabPFN clinical C5": ([], config.CLINICAL_FULL),
        "TabPFN MRI only": (emb, []),
        "TabPFN MRI + MMSE": (emb, ["MMSE"]),
        "TabPFN transportable (Age, Sex, Educ, MMSE + MRI)": (emb, config.TRANSPORTABLE_CLINICAL),
    }
    abl_rows, perm_rows, miss_rows, eff_rows = [], [], [], []
    ckpt_dir = run.dir / "_fold_checkpoints"
    ckpt_dir.mkdir(exist_ok=True)
    abl_keys = {"TabPFN clinical C4 (no MMSE)": "tabpfn|c4|0", "TabPFN clinical C5": "tabpfn|c5|0",
                "TabPFN MRI only": "tabpfn|mri|16", "TabPFN MRI + MMSE": "tabpfn|mri_mmse|16",
                "TabPFN transportable (Age, Sex, Educ, MMSE + MRI)": "tabpfn|transport|16"}
    assert set(abl_keys) == set(ablations)
    for seed, fold, tr, te in iter_outer_folds(df):
        # (a) modality ablation from the resumable prediction cache
        for name, key in abl_keys.items():
            pa = cache_get(key, df, seed, fold, tr, te, y)["test"]
            m = binary_metrics(y[te], (pa >= 0.5).astype(int), pa)
            m.update({"group": "TabPFN_ablation", "model": name, "seed": seed, "fold": fold})
            abl_rows.append(m)
        ck = ckpt_dir / f"s{seed}_f{fold}.json"
        if ck.exists():                                   # resume: fold already analysed
            d = json.loads(ck.read_text(encoding="utf-8"))
            perm_rows += d["perm"]; miss_rows += d["miss"]; eff_rows += d["eff"]
            print(f"  seed {seed} fold {fold} restored from checkpoint", flush=True)
            continue
        n_perm, n_miss, n_eff = len(perm_rows), len(miss_rows), len(eff_rows)
        k = int(sel[(sel.seed == seed) & (sel.fold == fold)].k.iloc[0])
        Xtr, Xte = df.iloc[tr][full_feats], df.iloc[te][full_feats]
        pipe = tabpfn_pipe(emb, config.CLINICAL_FULL, k)
        t0 = time.perf_counter(); pipe.fit(Xtr, y[tr]); t_fit = time.perf_counter() - t0
        t0 = time.perf_counter(); prob = pipe.predict_proba(Xte)[:, 1]; t_inf = time.perf_counter() - t0
        eff_rows.append({"seed": seed, "fold": fold, "k": k, "fit_s": t_fit, "inference_s_fold": t_inf,
                         "inference_ms_per_subject": 1000 * t_inf / len(te)})
        base_auc = roc_auc_score(y[te], prob)

        # (b) group permutation importance
        rng = np.random.default_rng(seed * 100 + fold)
        for g in GROUPS:
            Xp = Xte.copy()
            cols = emb if g == "MRI embedding" else [g]
            Xp[cols] = Xp[cols].to_numpy()[rng.permutation(len(Xp))]
            perm_rows.append({"seed": seed, "fold": fold, "group": g,
                              "auc_drop": base_auc - roc_auc_score(y[te], pipe.predict_proba(Xp)[:, 1])})

        # (c) missing MRI at test time
        for r in MISSING:
            Xm = Xte.copy()
            idx = rng.choice(len(Xm), int(round(r * len(Xm))), replace=False)
            Xm.iloc[idx, [Xm.columns.get_loc(c) for c in emb]] = np.nan
            pm = pipe.predict_proba(Xm)[:, 1]
            m = binary_metrics(y[te], (pm >= 0.5).astype(int), pm)
            m.update({"seed": seed, "fold": fold, "mri_missing_rate": r})
            miss_rows.append(m)

        tmp = ck.with_suffix(".tmp")
        tmp.write_text(json.dumps({"perm": perm_rows[n_perm:], "miss": miss_rows[n_miss:], "eff": eff_rows[n_eff:]},
                                  default=float), encoding="utf-8")
        os.replace(tmp, ck)
        print(f"  seed {seed} fold {fold} done (k={k})", flush=True)

    # ---------------- (a) ablation summary + paired deltas vs full TabPFN
    abl = pd.DataFrame(abl_rows)
    full = pd.read_csv(V5 / "fold_metrics.csv").assign(group="TabPFN_ablation", model="TabPFN full fusion (proposed)")
    allm = pd.concat([abl, full[abl.columns.intersection(full.columns)]], ignore_index=True)
    run.save_csv(allm, "ablation_fold_metrics.csv")
    abl_sum = summarize(allm)
    run.save_csv(abl_sum, "ablation_summary.csv")
    F = full.set_index(["seed", "fold"]).sort_index()
    drows = []
    for name in ablations:
        A = abl[abl.model == name].set_index(["seed", "fold"]).sort_index()
        for m in ["mcc", "roc_auc"]:
            d = (F[m] - A[m]).to_numpy()
            drows.append({"ablation": name, "metric": m, "full": F[m].mean(), "ablated": A[m].mean(),
                          "delta_full_minus_ablated": d.mean(),
                          "p_wilcoxon": stats.wilcoxon(d).pvalue if np.any(d != 0) else 1.0})
    deltas = pd.DataFrame(drows)
    order = np.argsort(deltas.p_wilcoxon.to_numpy()); running = 0.0; h = np.empty(len(deltas))
    for rank, i in enumerate(order):
        running = max(running, (len(deltas) - rank) * deltas.p_wilcoxon.iloc[i]); h[i] = min(running, 1.0)
    deltas["p_holm"] = h
    run.save_csv(deltas, "ablation_deltas.csv")
    pd.set_option("display.width", 250)
    print("\nModality ablation (TabPFN):\n",
          abl_sum[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))
    print("\nFull minus ablated:\n", deltas.round(4).to_string(index=False))

    # ---------------- (b) permutation importance
    perm = pd.DataFrame(perm_rows)
    run.save_csv(perm, "permutation_importance_per_fold.csv")
    imp = perm.groupby("group").auc_drop.agg(["mean", "std"]).sort_values("mean", ascending=False).reset_index()
    run.save_csv(imp, "permutation_importance.csv")
    print("\nGroup permutation importance (AUC drop):\n", imp.round(4).to_string(index=False))

    # ---------------- (c) missing MRI
    miss = pd.DataFrame(miss_rows)
    run.save_csv(miss, "missing_mri_per_fold.csv")
    ms = miss.groupby("mri_missing_rate")[["mcc", "roc_auc", "balanced_accuracy"]].agg(["mean", "std"])
    run.save_csv(ms.reset_index(), "missing_mri_summary.csv")
    print("\nMissing MRI at test time:\n", ms.round(4).to_string())

    # ---------------- (d) efficiency
    eff = pd.DataFrame(eff_rows)
    run.save_csv(eff, "efficiency_per_fold.csv")
    # Parameter count only (descriptive). TabPFN's internal SVD can fail numerically (ARPACK) on a
    # particular fit, so retry with other preprocessing seeds and skip the count if all fail.
    clf, n_params = None, None
    for rs in (42, 0, 1, 2):
        try:
            p = tabpfn_pipe(emb, config.CLINICAL_FULL, 16)
            p.named_steps["clf"].set_params(random_state=rs)
            clf = p.fit(df[full_feats], y).named_steps["clf"]
            break
        except Exception as e:
            print(f"  parameter-count fit failed (random_state={rs}): {type(e).__name__}")
    for attr in ("model_", "models_", "executor_") if clf is not None else ():
        obj = getattr(clf, attr, None)
        mods = obj if isinstance(obj, (list, tuple)) else [obj]
        try:
            n_params = int(sum(p.numel() for m_ in mods for p in m_.parameters()))
            break
        except Exception:
            continue
    effs = {"fit_s_median": eff.fit_s.median(), "inference_ms_per_subject_median": eff.inference_ms_per_subject.median(),
            "pretrained_parameters": n_params, "trainable_parameters_on_our_data": 0,
            "selected_k_frequency": eff.k.value_counts().to_dict()}
    run.save_json(effs, "efficiency_summary.json")
    print("\nEfficiency:", effs)

    # ---------------- (e) calibration + error analysis
    oof = pd.read_csv(V5 / "oof_predictions.csv")
    rf = pd.read_csv(RF_OOF)
    rf = rf[(rf.group == "Fusion_PCA_nested") & (rf.model == "RF")]
    lr = pd.read_csv(RF_OOF)
    lr = lr[(lr.group == "Fusion_PCA_nested") & (lr.model == "LR")]
    cal = []
    for name, p in [("TabPFN (proposed)", oof), ("Fusion PCA - RF", rf), ("Fusion PCA - LR", lr)]:
        sl = [slope_intercept(s.y_true.to_numpy(), s.y_prob.to_numpy()) for _, s in p.groupby(["seed", "fold"])]
        cal.append({"model": name, "cal_slope_median": np.median([a for a, _ in sl]),
                    "cal_intercept_median": np.median([b for _, b in sl]),
                    "pooled_slope": slope_intercept(p.y_true.to_numpy(), p.y_prob.to_numpy())[0]})
    cal = pd.DataFrame(cal)
    run.save_csv(cal, "calibration_slopes.csv")
    print("\nCalibration:\n", cal.round(3).to_string(index=False))
    fig, ax = plt.subplots(figsize=(5.2, 5))
    ax.plot([0, 1], [0, 1], "--", color="grey")
    for name, p in [("TabPFN (proposed)", oof), ("Fusion PCA - RF", rf), ("Fusion PCA - LR", lr)]:
        fr, mp = calibration_curve(p.y_true, p.y_prob, n_bins=10, strategy="quantile")
        ax.plot(mp, fr, marker="o", ms=3, label=name)
    ax.set_xlabel("mean predicted probability"); ax.set_ylabel("observed fraction CDR > 0")
    ax.legend(fontsize=8); ax.set_title("Reliability (pooled OOF, 5 repeats)")
    fig.tight_layout(); run.save_fig(fig, "fig_reliability_tabpfn.png"); plt.close(fig)

    err = oof.assign(wrong=oof.y_true != oof.y_pred).groupby("subject_id").agg(
        error_rate=("wrong", "mean"), y_true=("y_true", "first")).reset_index()
    err = err.merge(df[["subject_id", "CDR", "Age", "MMSE", "nWBV"]], on="subject_id")
    run.save_csv(err, "per_subject_error_rates.csv")
    by_cdr = err.groupby("CDR").agg(n=("subject_id", "size"), mean_error_rate=("error_rate", "mean"),
                                    consistent_errors=("error_rate", lambda s: int((s >= 0.6).sum()))).reset_index()
    run.save_csv(by_cdr, "error_by_cdr.csv")
    print("\nError rate by CDR:\n", by_cdr.round(3).to_string(index=False))

    fig, ax = plt.subplots(figsize=(6, 3.8))
    ax.barh(imp.group[::-1], imp["mean"][::-1], xerr=imp["std"][::-1], color="#5b7fa6", capsize=2)
    ax.set_xlabel("drop in ROC-AUC when permuted (25 test folds)")
    ax.set_title("TabPFN: group permutation importance")
    fig.tight_layout(); run.save_fig(fig, "fig_permutation_importance.png"); plt.close(fig)
