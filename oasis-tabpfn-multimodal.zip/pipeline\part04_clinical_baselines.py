"""Part 04 - Clinical baselines + MMSE ablation.

Feature sets C1-C5 x {LR, SVM-RBF, RF, XGBoost}, nested tuning on frozen inner folds,
evaluated on the frozen 5x5 outer folds.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from xgboost import XGBClassifier

import config
from common import (PhaseRun, assert_no_forbidden, check_oof_integrity, load_cohort,
                    run_nested_cv, summarize)

FEATURE_SETS = {
    "C1_demographics": config.DEMOGRAPHICS,
    "C2_mri_biomarkers": config.MRI_BIOMARKERS,
    "C3_cognitive_MMSE": config.COGNITIVE,
    "C4_clinical_no_MMSE": config.CLINICAL_NO_MMSE,
    "C5_clinical_full": config.CLINICAL_FULL,
}


def model_zoo(seed=42):
    def pipe(clf, scale=True):
        steps = [("imp", SimpleImputer(strategy="median"))]
        if scale:
            steps.append(("sc", StandardScaler()))
        return Pipeline(steps + [("clf", clf)])

    return {
        "LR": (pipe(LogisticRegression(max_iter=5000, class_weight="balanced", random_state=seed)),
               {"clf__C": [0.01, 0.1, 1, 10]}),
        "SVM_RBF": (pipe(SVC(kernel="rbf", probability=True, class_weight="balanced", random_state=seed)),
                    {"clf__C": [0.1, 1, 10], "clf__gamma": ["scale", 0.01, 0.1]}),
        "RF": (pipe(RandomForestClassifier(n_estimators=300, class_weight="balanced",
                                           random_state=seed, n_jobs=1), scale=False),
               {"clf__max_depth": [None, 3, 5], "clf__min_samples_leaf": [1, 3, 5]}),
        "XGBoost": (pipe(XGBClassifier(subsample=0.8, colsample_bytree=0.8, eval_metric="logloss",
                                       random_state=seed, n_jobs=1, verbosity=0), scale=False),
                    {"clf__max_depth": [2, 3], "clf__n_estimators": [100, 300],
                     "clf__learning_rate": [0.03, 0.1]}),
    }


with PhaseRun("part04_clinical", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE],
              params={"feature_sets": FEATURE_SETS,
                      "grids": {k: v[1] for k, v in model_zoo().items()},
                      "tuning": config.TUNING_SCORING,
                      "threshold": config.DECISION_THRESHOLD}) as run:
    df = load_cohort()
    specs = []
    for fs, feats in FEATURE_SETS.items():
        assert_no_forbidden(feats)
        for name, (pipe, grid) in model_zoo().items():
            specs.append({"group": fs, "name": name, "features": feats, "pipeline": pipe, "grid": grid})
    print(f"{len(specs)} configurations x 25 outer folds")

    folds, preds, params = run_nested_cv(df, specs)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")

    summary = summarize(folds)
    run.save_csv(summary, "summary.csv")
    show = ["group", "model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]
    print("\nSummary (mean ± SD over 25 outer folds):")
    print(summary.sort_values("mcc_mean", ascending=False)[show].to_string(index=False))

    # ---------------- MMSE ablation: paired per-fold differences
    rows = []
    key = ["model", "seed", "fold"]
    for a, b, label in [("C5_clinical_full", "C4_clinical_no_MMSE", "add MMSE to C4 (C5 - C4)"),
                        ("C5_clinical_full", "C3_cognitive_MMSE", "add C4 to MMSE (C5 - C3)"),
                        ("C3_cognitive_MMSE", "C4_clinical_no_MMSE", "MMSE alone vs C4 (C3 - C4)")]:
        A = folds[folds.group == a].set_index(key)
        B = folds[folds.group == b].set_index(key)
        for model in folds.model.unique():
            for m in ["balanced_accuracy", "macro_f1", "mcc", "roc_auc"]:
                d = (A.loc[model, m] - B.loc[model, m]).to_numpy()
                boot = np.random.default_rng(0).choice(d, (5000, len(d))).mean(1)
                rows.append({"comparison": label, "model": model, "metric": m,
                             "mean_A": A.loc[model, m].mean(), "mean_B": B.loc[model, m].mean(),
                             "mean_delta": d.mean(), "ci95_low": np.percentile(boot, 2.5),
                             "ci95_high": np.percentile(boot, 97.5),
                             "folds_A_better": int((d > 0).sum()), "n_folds": len(d)})
    ablation = pd.DataFrame(rows)
    run.save_csv(ablation, "mmse_ablation.csv")
    print("\nMMSE ablation (MCC):")
    print(ablation[ablation.metric == "mcc"].round(4).to_string(index=False))

    # ---------------- integrity checks
    checks = pd.DataFrame([
        ("25 outer folds per configuration", bool((folds.groupby(["group", "model"]).size() == 25).all())),
        ("each subject predicted once per seed per configuration", check_oof_integrity(preds, df)),
        ("no forbidden predictor in any feature set",
         all(not set(f) & set(config.FORBIDDEN_PREDICTORS) for f in FEATURE_SETS.values())),
        ("probabilities within [0,1]", bool(preds.y_prob.between(0, 1).all())),
    ], columns=["check", "passed"])
    print("\n", checks.to_string(index=False))
    run.save_csv(checks, "integrity_checks.csv")
    assert checks.passed.all()

    # ---------------- figure
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.2), sharey=False)
    groups = list(FEATURE_SETS)
    models = list(model_zoo())
    w = 0.2
    for ax, m in zip(axes, ["balanced_accuracy", "mcc", "roc_auc"]):
        for i, model in enumerate(models):
            s = summary[summary.model == model].set_index("group").loc[groups]
            ax.bar(np.arange(len(groups)) + (i - 1.5) * w, s[f"{m}_mean"], w,
                   yerr=s[f"{m}_sd"], capsize=2, label=model)
        ax.set_xticks(np.arange(len(groups)))
        ax.set_xticklabels([g.split("_", 1)[0] for g in groups])
        ax.set_title(m.replace("_", " "))
    axes[0].legend(fontsize=8)
    fig.suptitle("Part 04 - clinical baselines (C1 demo, C2 MRI biomarkers, C3 MMSE, C4 no-MMSE, C5 full)")
    fig.tight_layout()
    run.save_fig(fig, "fig_clinical_baselines.png")
    plt.close(fig)
