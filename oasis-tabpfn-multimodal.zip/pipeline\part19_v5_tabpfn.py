"""Part 19 v5 - In-context learning with a tabular foundation model (TabPFN v2).
TabPFN is a transformer pre-trained on millions of synthetic tabular tasks; it predicts a new
task by conditioning on the training rows (no gradient training on our data). Input = PCA-fusion
features (MRI PCA-k + C5 clinical); k tuned on the frozen inner folds."""
import json

import tabpfn
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from tabpfn import TabPFNClassifier
from tabpfn.constants import ModelVersion

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from models import preprocessor
from newmethods import BASELINE_FILE, PROTOCOL_FILE, compare

NESTED_K = [k for k in config.PCA_DIMS if k <= 64]
GRID = {"prep__mri__pca": [PCA(n_components=k, random_state=42) for k in NESTED_K]}

with PhaseRun("part19_v5_tabpfn", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"tabpfn_version": tabpfn.__version__, "model_version": "v2", "device": "cpu",
                      "grid": {k: [str(v) for v in vs] for k, vs in GRID.items()}}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    feats = emb + config.CLINICAL_FULL
    pipe = Pipeline([("prep", preprocessor(emb, config.CLINICAL_FULL, pca_dim=8)),
                     ("clf", TabPFNClassifier.create_default_for_version(ModelVersion.V2, device="cpu",
                                                                         random_state=42))])
    spec = [{"group": "v5_tabpfn", "name": "TabPFN_v2", "features": feats, "pipeline": pipe, "grid": GRID}]
    folds, preds, params = run_nested_cv(df, spec)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summary = summarize(folds)
    run.save_csv(summary, "summary.csv")
    print(summary[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))
    table, verdict = compare(folds, "v5_tabpfn")
    run.save_csv(table, "comparison_vs_baseline.csv")
    run.save_json(verdict, "verdict.json")
    print("\n", table[table.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))
    print("\nVERDICT:", json.dumps(verdict, indent=2, default=str))
    assert check_oof_integrity(preds, df)
