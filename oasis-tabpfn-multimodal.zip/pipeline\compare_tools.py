"""Shared helpers for Parts 27-30: TabPFN spec builder and paired comparison tables."""
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline

import config
from models import preprocessor

NESTED_K = [8, 16, 24, 32, 64]
N_TRAIN, N_TEST = 133, 33


def pca_grid():
    return {"prep__mri__pca": [PCA(n_components=k, random_state=42) for k in NESTED_K]}


def tabpfn_spec(group, mri_cols, tab_cols, name="TabPFN_v2"):
    """Proposed model as a nested-CV spec (MRI PCA k tuned on inner folds)."""
    from tabpfn import TabPFNClassifier
    from tabpfn.constants import ModelVersion
    pipe = Pipeline([("prep", preprocessor(mri_cols, tab_cols, pca_dim=8)),
                     ("clf", TabPFNClassifier.create_default_for_version(ModelVersion.V2, device="cpu",
                                                                         random_state=42))])
    return {"group": group, "name": name, "features": list(mri_cols) + list(tab_cols),
            "pipeline": pipe, "grid": pca_grid()}


def _holm(p):
    p = np.asarray(p, float)
    out, run = np.empty_like(p), 0.0
    for r, i in enumerate(np.argsort(p)):
        run = max(run, (len(p) - r) * p[i]); out[i] = min(run, 1.0)
    return out


def _nb(d, n_tr=N_TRAIN, n_te=N_TEST):
    v = np.var(d, ddof=1)
    if v == 0:
        return 1.0
    t = d.mean() / np.sqrt((1 / len(d) + n_te / n_tr) * v)
    return float(2 * stats.t.sf(abs(t), len(d) - 1))


def paired_table(ref, ref_name, others, metrics=("mcc", "roc_auc", "balanced_accuracy", "brier"),
                 n_tr=N_TRAIN, n_te=N_TEST):
    """ref / others: fold-metric frames (one row per seed, fold). Difference = ref - other.
    Holm over all others x metrics; Wilcoxon primary, Nadeau-Bengio sensitivity."""
    R = ref.set_index(["seed", "fold"]).sort_index()
    rows = []
    for name, O in others.items():
        O = O.set_index(["seed", "fold"]).sort_index()
        assert (O.index == R.index).all()
        for m in metrics:
            d = (R[m] - O[m]).to_numpy()
            boot = np.random.default_rng(0).choice(d, (10000, len(d))).mean(1)
            rows.append({"reference": ref_name, "comparator": name, "metric": m, "mean_ref": R[m].mean(),
                         "mean_comp": O[m].mean(), "delta": d.mean(), "ci95_low": np.percentile(boot, 2.5),
                         "ci95_high": np.percentile(boot, 97.5),
                         "p_wilcoxon": stats.wilcoxon(d).pvalue if np.any(d != 0) else 1.0,
                         "p_nadeau_bengio": _nb(d, n_tr, n_te)})
    t = pd.DataFrame(rows)
    t["p_holm"] = _holm(t.p_wilcoxon)
    t["p_nb_holm"] = _holm(t.p_nadeau_bengio)
    return t
