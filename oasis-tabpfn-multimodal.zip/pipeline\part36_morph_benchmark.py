"""Part 36 - Amendment 5 (v12): proposed TabPFN framework with label-free regional tissue morphometry (Part 35)
as the MRI block; same cohort, frozen folds and nested tuning as Part 30. Primary test fixed in the protocol:
v12 vs every baseline, Wilcoxon + Holm over all comparisons x 4 metrics; Nadeau-Bengio as sensitivity.
Resumable per fold."""
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import RidgeCV
from sklearn.metrics import r2_score
from sklearn.model_selection import cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, iter_outer_folds, load_cohort, run_nested_cv, summarize
from compare_tools import paired_table, pca_grid, tabpfn_spec
from models import build

MORPH = config.RAW_DIR / "mri_morph_own.csv"
P04 = config.OUTPUT_DIR / "part04_clinical" / "fold_metrics.csv"
P30 = config.OUTPUT_DIR / "part30_own_mri_benchmark" / "fold_metrics.csv"
P31 = config.OUTPUT_DIR / "part31_own_mri_extended" / "ablation_fold_metrics.csv"
# Multithreaded MKL LU in randomized PCA (5661 columns, k = 64) livelocks in this install; joblib workers
# already run single-threaded, so the main-process refit is limited the same way (results unaffected).
threadpool_limits(1, user_api="blas")

with PhaseRun("part36_morph_benchmark", __file__,
              inputs=[config.COHORT_FILE, MORPH, config.FOLDS_FILE, config.INNER_FOLDS_FILE, P04, P30, P31]) as run:
    base = load_cohort()
    morph = pd.read_csv(MORPH)
    df = base.drop(columns=embedding_cols(base)).merge(morph, on="subject_id", how="left", validate="one_to_one")
    df = df.set_index("subject_id").loc[base.subject_id].reset_index()
    mri = [c for c in morph.columns if c != "subject_id"]
    assert df[mri].notna().all().all(), "morphometry missing for some subjects"
    C5 = config.CLINICAL_FULL
    print(f"cohort {len(df)}, morphometry features {len(mri)}", flush=True)

    # audit: atrophy encoding (nWBV) by the morphometry block, seed-42 outer folds
    seed42 = [(tr, te) for s, f, tr, te in iter_outer_folds(df) if s == 42]
    nwbv = cross_val_predict(make_pipeline(StandardScaler(), RidgeCV(alphas=np.logspace(-2, 5, 29))),
                             df[mri].to_numpy(float), df.nWBV.to_numpy(float), cv=seed42)
    audit = pd.DataFrame([{"n_features": len(mri), "nWBV_cv_r2": r2_score(df.nWBV, nwbv),
                           "nWBV_cv_pearson": stats.pearsonr(df.nWBV, nwbv)[0]}])
    run.save_csv(audit, "morph_audit.csv")
    print(audit.round(4).to_string(index=False), flush=True)

    specs = [tabpfn_spec("Morph", mri, C5, name="TabPFN_morph")]
    for name in ["RF", "LR", "XGBoost"]:
        pipe, grid = build(name, mri_cols=mri, tab_cols=C5, pca_dim=8, extra_grid=pca_grid())
        specs.append({"group": "Morph", "name": f"Fusion_PCA_{name}_morph", "features": mri + C5, "pipeline": pipe,
                      "grid": grid})
    pipe, grid = build("LR", mri_cols=mri, pca_dim=8, extra_grid=pca_grid())
    specs.append({"group": "Morph", "name": "MRI_only_LR_morph", "features": mri, "pipeline": pipe, "grid": grid})
    folds, preds, params = run_nested_cv(df, specs, ckpt_dir=str(run.dir / "_ckpt"))
    run.save_csv(folds, "fold_metrics.csv"); run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summ = summarize(folds); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "mcc", "roc_auc", "brier"]].to_string(index=False), flush=True)

    clin, p30, p31 = pd.read_csv(P04), pd.read_csv(P30), pd.read_csv(P31)
    others = {m: folds[folds.model == m] for m in folds.model.unique() if m != "TabPFN_morph"}
    others["Clinical_C5_LR"] = clin[(clin.group == "C5_clinical_full") & (clin.model == "LR")]
    others["Clinical_C5_XGBoost"] = clin[(clin.group == "C5_clinical_full") & (clin.model == "XGBoost")]
    others["TabPFN_clinical_only"] = p31[p31.model == "TabPFN_clinical_only"]
    others["TabPFN_ResNet"] = p30[p30.model == "TabPFN_v2"]
    tab = paired_table(folds[folds.model == "TabPFN_morph"], "TabPFN_morph (v12)", others)
    run.save_csv(tab, "v12_vs_baselines.csv")
    print(tab[tab.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))
    assert check_oof_integrity(preds, df)
