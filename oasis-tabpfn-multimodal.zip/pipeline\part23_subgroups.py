"""Part 23 - Subgroup (fairness) analysis of the proposed model from saved out-of-fold predictions.

Subgroups: sex (female / male) and age band (60-74 / >= 75). Test folds are too small for per-fold
subgroup metrics, so each repeat's pooled out-of-fold predictions (all 166 subjects predicted once per
seed) are evaluated per subgroup; mean +- SD over the 5 repeats, plus a subject-level bootstrap CI of
the between-group difference (repeat-averaged probabilities). Compared with fusion-RF (baseline).
"""
import numpy as np
import pandas as pd

import config
from common import PhaseRun, binary_metrics, load_cohort

OUT = config.OUTPUT_DIR
MODELS = {
    "TabPFN (proposed)": (OUT / "part19_v5_tabpfn/oof_predictions.csv", None, None),
    "Fusion PCA - RF (baseline)": (OUT / "part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "RF"),
}
METRICS = ["balanced_accuracy", "mcc", "roc_auc", "sensitivity", "specificity", "brier"]

with PhaseRun("part23_subgroups", __file__, inputs=[config.COHORT_FILE] + [v[0] for v in MODELS.values()],
              params={"subgroups": ["sex", "age band 60-74 / >=75"], "unit": "pooled OOF per repeat"}) as run:
    df = load_cohort()
    info = df[["subject_id", "sex_binary", "Age"]].assign(
        sex=lambda d: d.sex_binary.map({0: "female", 1: "male"}),
        age_band=lambda d: np.where(d.Age >= 75, ">=75", "60-74"))
    rows, diffs = [], []
    for name, (f, g, m) in MODELS.items():
        p = pd.read_csv(f)
        if g:
            p = p[(p.group == g) & (p.model == m)]
        p = p.merge(info, on="subject_id")
        for var in ["sex", "age_band"]:
            for level, s in p.groupby(var):
                for seed, ss in s.groupby("seed"):
                    met = binary_metrics(ss.y_true, ss.y_pred, ss.y_prob)
                    rows.append({"model": name, "variable": var, "level": level, "seed": seed,
                                 "n": len(ss), "n_dementia": int(ss.y_true.sum()),
                                 **{k: met[k] for k in METRICS}})
            # bootstrap CI of between-group AUC / balanced-accuracy difference (repeat-averaged probability)
            avg = p.groupby("subject_id").agg(y=("y_true", "first"), prob=("y_prob", "mean"),
                                              grp=(var, "first")).reset_index()
            lv = sorted(avg.grp.unique())
            rng = np.random.default_rng(0)
            boot = []
            for _ in range(2000):
                b = avg.iloc[rng.integers(0, len(avg), len(avg))]
                vals = []
                for l in lv:
                    bb = b[b.grp == l]
                    if bb.y.nunique() < 2:
                        break
                    vals.append(binary_metrics(bb.y, (bb.prob >= 0.5).astype(int), bb.prob))
                if len(vals) == 2:
                    boot.append({k: vals[0][k] - vals[1][k] for k in ["roc_auc", "balanced_accuracy", "mcc"]})
            boot = pd.DataFrame(boot)
            for k in boot:
                diffs.append({"model": name, "variable": var, "difference": f"{lv[0]} - {lv[1]}", "metric": k,
                              "mean": boot[k].mean(), "ci95_low": np.percentile(boot[k], 2.5),
                              "ci95_high": np.percentile(boot[k], 97.5)})
    res = pd.DataFrame(rows)
    run.save_csv(res, "subgroup_per_repeat.csv")
    summ = res.groupby(["model", "variable", "level"]).agg(
        n=("n", "first"), n_dementia=("n_dementia", "first"),
        **{f"{k}_mean": (k, "mean") for k in METRICS}, **{f"{k}_sd": (k, "std") for k in METRICS}).reset_index()
    run.save_csv(summ, "subgroup_summary.csv")
    d = pd.DataFrame(diffs)
    run.save_csv(d, "subgroup_differences.csv")
    pd.set_option("display.width", 250)
    print(summ[["model", "variable", "level", "n", "n_dementia", "balanced_accuracy_mean", "mcc_mean",
                "roc_auc_mean", "sensitivity_mean", "specificity_mean"]].round(3).to_string(index=False))
    print("\nBetween-group differences (bootstrap 95% CI; CI including 0 = no evidence of disparity):\n",
          d.round(3).to_string(index=False))
