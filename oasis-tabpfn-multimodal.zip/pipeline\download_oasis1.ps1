# Resumable download of the 12 OASIS-1 cross-sectional archives (official OASIS server).
# - curl -C - continues each file from the exact byte where it stopped
# - a file counts as complete only when its size equals the server's Content-Length
# - single instance (lock file); safe to start again at any time
$ErrorActionPreference = "Continue"
$dest = Join-Path (Split-Path $PSScriptRoot -Parent) "oasis1_raw"
New-Item -ItemType Directory -Force $dest | Out-Null
$log = Join-Path $dest "download_status.txt"
$lock = Join-Path $dest "download.lock"
function Log($m) { "$(Get-Date -Format s)  $m" | Out-File $log -Append -Encoding utf8 }
if (Test-Path $lock) {
    $old = Get-Content $lock -ErrorAction SilentlyContinue
    if ($old -and (Get-Process -Id $old -ErrorAction SilentlyContinue)) { exit 0 }
}
$PID | Out-File $lock -Encoding ascii
try {
    Log "downloader started (pid $PID)"
    for ($i = 1; $i -le 12; $i++) {
        $name = "oasis_cross-sectional_disc$i.tar.gz"
        $url = "https://download.nrg.wustl.edu/data/$name"
        $file = Join-Path $dest $name
        $expected = $null
        for ($t = 0; $t -lt 10 -and -not $expected; $t++) {
            try { $expected = [int64](Invoke-WebRequest -Uri $url -Method Head -UseBasicParsing -TimeoutSec 30).Headers['Content-Length'] }
            catch { Start-Sleep 15 }
        }
        if (-not $expected) { Log "FAIL size check $name (network?)"; exit 1 }
        for ($attempt = 1; $attempt -le 30; $attempt++) {
            $have = if (Test-Path $file) { (Get-Item $file).Length } else { 0 }
            if ($have -eq $expected) { break }
            Log "GET  $name  have=$have expected=$expected attempt=$attempt"
            & curl.exe -L -s -S -C - --retry 10 --retry-delay 10 --connect-timeout 30 -o $file $url
            Start-Sleep 2
        }
        $have = if (Test-Path $file) { (Get-Item $file).Length } else { 0 }
        if ($have -eq $expected) { Log "OK   $name  ($([math]::Round($have/1GB,2)) GB)" }
        else { Log "FAIL $name  have=$have expected=$expected"; exit 1 }
    }
    Log "ALL 12 ARCHIVES COMPLETE"
    "done" | Out-File (Join-Path $dest "DOWNLOAD_COMPLETE.txt") -Encoding ascii
}
finally { Remove-Item $lock -ErrorAction SilentlyContinue }
