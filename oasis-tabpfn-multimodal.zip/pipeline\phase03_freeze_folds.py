"""Phase 03 - Freeze subject-level 5x5 outer folds and 3-fold inner folds.

Every later phase reads these files, so all models are compared on identical splits.
Stratification uses the 3-class CDR label (0 / 0.5 / >=1) so that the small CDR>=1
group is spread evenly across folds; the binary target is balanced as a consequence.
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold

import config
from common import PhaseRun

with PhaseRun("phase03_folds", __file__, inputs=[config.COHORT_FILE],
              params={"outer_seeds": config.OUTER_SEEDS, "n_outer": config.N_OUTER_FOLDS,
                      "n_inner": config.N_INNER_FOLDS, "stratify_on": "target_3class",
                      "inner_seed_rule": "seed * 100 + outer_fold"}) as run:

    df = pd.read_csv(config.COHORT_FILE).sort_values("subject_id").reset_index(drop=True)
    assert df.subject_id.is_unique, "cohort must have one row per subject"
    ids = df.subject_id.to_numpy()
    strat = df.target_3class.to_numpy()
    y = df.target_binary.to_numpy()

    outer_rows, inner_rows, summary_rows = [], [], []
    for seed in config.OUTER_SEEDS:
        skf = StratifiedKFold(config.N_OUTER_FOLDS, shuffle=True, random_state=seed)
        for k, (tr, te) in enumerate(skf.split(ids, strat), start=1):
            assert not set(ids[tr]) & set(ids[te])
            outer_rows += [{"subject_id": s, "seed": seed, "fold": k} for s in ids[te]]
            summary_rows.append({
                "seed": seed, "fold": k, "n_train": len(tr), "n_test": len(te),
                "test_n_class0": int((y[te] == 0).sum()), "test_n_class1": int((y[te] == 1).sum()),
                "test_n_cdr05": int((strat[te] == 1).sum()), "test_n_cdr_ge1": int((strat[te] == 2).sum()),
                "train_pct_class1": round(100 * y[tr].mean(), 1),
                "test_pct_class1": round(100 * y[te].mean(), 1),
                "train_test_overlap": len(set(ids[tr]) & set(ids[te])),
            })
            iskf = StratifiedKFold(config.N_INNER_FOLDS, shuffle=True, random_state=seed * 100 + k)
            for j, (_, ite) in enumerate(iskf.split(ids[tr], strat[tr]), start=1):
                inner_rows += [{"subject_id": s, "seed": seed, "outer_fold": k, "inner_fold": j}
                               for s in ids[tr][ite]]

    outer = pd.DataFrame(outer_rows)
    inner = pd.DataFrame(inner_rows)
    summary = pd.DataFrame(summary_rows)

    # ---------------- verification
    checks = []
    per_seed = outer.groupby("seed").subject_id.agg(["size", "nunique"])
    checks.append(("each subject in exactly one test fold per seed",
                   bool((per_seed["size"] == len(df)).all() and (per_seed["nunique"] == len(df)).all())))
    checks.append(("no train/test subject overlap in any outer fold",
                   bool((summary.train_test_overlap == 0).all())))
    checks.append(("25 outer evaluations", len(summary) == config.N_OUTER_FOLDS * len(config.OUTER_SEEDS)))
    inner_cnt = inner.groupby(["seed", "outer_fold"]).subject_id.agg(["size", "nunique"])
    merged = inner.merge(outer, on=["subject_id", "seed"])
    checks.append(("inner folds contain only outer-training subjects",
                   bool((merged.fold != merged.outer_fold).all())))
    checks.append(("inner folds cover each outer-training set exactly once",
                   bool((inner_cnt["size"] == inner_cnt["nunique"]).all()
                        and (inner_cnt["size"].to_numpy() == summary.n_train.to_numpy()).all())))
    checks.append(("test-fold class-1 share within 5 pp of cohort",
                   bool((abs(summary.test_pct_class1 - 100 * y.mean()) <= 5).all())))
    wide = outer.pivot(index="subject_id", columns="seed", values="fold")
    distinct = all(not (wide[a] == wide[b]).all()
                   for i, a in enumerate(config.OUTER_SEEDS) for b in config.OUTER_SEEDS[i + 1:])
    checks.append(("partitions differ between seeds", distinct))
    checks = pd.DataFrame(checks, columns=["check", "passed"])

    print("\nFold summary:\n", summary.to_string(index=False))
    print("\nVerification:\n", checks.to_string(index=False))

    run.save_csv(outer, "outer_folds_5x5.csv")
    run.save_csv(inner, "inner_folds_3.csv")
    run.save_csv(summary, "fold_summary.csv")
    run.save_csv(checks, "fold_verification.csv")
    assert checks.passed.all(), "Fold verification failed"
