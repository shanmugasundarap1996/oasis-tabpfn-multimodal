"""Resumable prediction cache (shared by Part 19 v6+ and Part 22).

For a model key and one frozen outer fold it stores
  oof  : out-of-fold P(CDR>0) for the outer-TRAINING subjects (frozen 3-fold inner splits),
  test : P(CDR>0) for the outer-TEST subjects (model fitted on the whole outer training set).
Files: outputs/_cache/<key>/s<seed>_f<fold>.npz, written atomically (tmp + rename), so an
interrupted run resumes at the first missing fold and never reads a half-written file.

Hyperparameters are never chosen here: TabPFN 'sel' uses the k selected by inner CV in
Part 19 v5; rf/xgb/lr 'sel' use the per-fold parameters selected by inner CV in Part 07.
"""
import os
import re

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline

import config
from common import embedding_cols, inner_splits
from models import build, preprocessor

CACHE_DIR = config.OUTPUT_DIR / "_cache"
V5_PARAMS = config.OUTPUT_DIR / "part19_v5_tabpfn" / "best_params.csv"
P07_PARAMS = config.OUTPUT_DIR / "part07_fusion" / "best_params.csv"

FEATURE_SETS = {
    "full": ("mri", config.CLINICAL_FULL),
    "transport": ("mri", config.TRANSPORTABLE_CLINICAL),
    "mri_mmse": ("mri", ["MMSE"]),
    "mri_mmse_age": ("mri", ["Age", "MMSE"]),
    "mri": ("mri", []),
    "c5": (None, config.CLINICAL_FULL),
    "c4": (None, config.CLINICAL_NO_MMSE),
}
_PARAMS = {}


def _v5_k(seed, fold):
    if "v5" not in _PARAMS:
        p = pd.read_csv(V5_PARAMS)
        p["k"] = p.prep__mri__pca.str.extract(r"n_components=(\d+)").astype(int)
        _PARAMS["v5"] = p.set_index(["seed", "fold"]).k
    return int(_PARAMS["v5"].loc[(seed, fold)])


def _p07(model, seed, fold):
    if "p07" not in _PARAMS:
        _PARAMS["p07"] = pd.read_csv(P07_PARAMS)
    p = _PARAMS["p07"]
    row = p[(p.group == "Fusion_PCA_nested") & (p.model == model) & (p.seed == seed) & (p.fold == fold)].iloc[0]
    out = {}
    for c, v in row.items():
        if c in ("group", "model", "seed", "fold") or pd.isna(v):
            continue
        v = str(v)
        if c == "prep__mri__pca":
            m = re.search(r"n_components=(\d+)", v)
            out[c] = PCA(n_components=int(m.group(1)), random_state=42) if m else "passthrough"
        elif v == "None":
            out[c] = None
        else:
            f = float(v)
            out[c] = int(f) if f.is_integer() and c not in ("clf__C", "clf__learning_rate") else f
    return out


def make_estimator(key, emb, seed, fold):
    """key examples: 'tabpfn|full|sel', 'tabpfn|mri_mmse|16', 'tabpfn|c5|0', 'rf|sel', 'xgb|sel', 'lr|sel'.
    A trailing '|sev' means severity-aware context: fitted on the 3-level CDR target."""
    parts = [p for p in key.split("|") if p != "sev"]
    if parts[0] == "tabpfn":
        from tabpfn import TabPFNClassifier
        from tabpfn.constants import ModelVersion
        fs, kspec = parts[1], parts[2]
        mri, tab = FEATURE_SETS[fs]
        mri_cols = emb if mri else []
        k = _v5_k(seed, fold) if kspec == "sel" else int(kspec)
        pipe = Pipeline([("prep", preprocessor(mri_cols, tab, pca_dim=k if mri_cols else None)),
                         ("clf", TabPFNClassifier.create_default_for_version(
                             ModelVersion.V2, device="cpu", random_state=42))])
        return pipe, list(mri_cols) + list(tab)
    name = {"rf": "RF", "xgb": "XGBoost", "lr": "LR"}[parts[0]]
    pipe, _ = build(name, mri_cols=emb, tab_cols=config.CLINICAL_FULL, pca_dim=8)
    pipe.set_params(**_p07(name, seed, fold))
    return pipe, emb + config.CLINICAL_FULL


def get(key, df, seed, fold, tr, te, y, need_oof=True):
    """Return dict(oof=..., test=...) for one fold, computing and caching it if needed.
    need_oof=False skips the inner out-of-fold predictions (oof stored as NaN, recomputed later if needed).
    Severity-aware keys ('|sev') are fitted on target_3class and return P(level > 0) = 1 - P(level 0)."""
    path = CACHE_DIR / key.replace("|", "__") / f"s{seed}_f{fold}.npz"
    if path.exists():
        d = np.load(path)
        assert np.array_equal(d["tr"], tr) and np.array_equal(d["te"], te), f"fold mismatch in {path}"
        if not (need_oof and np.isnan(d["oof"]).any()):
            return {"oof": d["oof"], "test": d["test"]}
    from sklearn.base import clone
    emb = embedding_cols(df)
    est, cols = make_estimator(key, emb, seed, fold)
    sev = key.endswith("|sev")
    target = df["target_3class"].to_numpy() if sev else y

    def p_pos(model, X):
        proba = model.predict_proba(X)
        return 1 - proba[:, 0] if sev else proba[:, 1]

    oof = np.full(len(tr), np.nan)
    if need_oof:
        for itr, iva in inner_splits(df, seed, fold, tr):
            m = clone(est).fit(df.iloc[tr[itr]][cols], target[tr[itr]])
            oof[iva] = p_pos(m, df.iloc[tr[iva]][cols])
    test = p_pos(clone(est).fit(df.iloc[tr][cols], target[tr]), df.iloc[te][cols])
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.stem + ".tmp.npz")
    np.savez(tmp, oof=oof, test=test, tr=tr, te=te)
    os.replace(tmp, path)
    return {"oof": oof, "test": test}
