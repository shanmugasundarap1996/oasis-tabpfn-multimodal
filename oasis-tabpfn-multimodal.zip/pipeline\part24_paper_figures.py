"""Part 24 - Publication figures for the TabPFN paper (from saved evidence only).

fig2_roc_pr.pdf          ROC and PR curves (pooled OOF over 5 repeats): clinical, MRI, fusion-LR, fusion-RF, GCN, TabPFN
fig3_significance.pdf    paired difference (TabPFN - baseline) in MCC and AUC with 95% bootstrap CI, Holm verdict
fig4_xai_calibration.pdf (a) group permutation importance (Part 22) (b) reliability diagram (Part 22 inputs)
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.calibration import calibration_curve
from sklearn.metrics import auc, precision_recall_curve, roc_curve

import config
from common import PhaseRun

OUT = config.OUTPUT_DIR
FIG_DIR = config.BASE_DIR / "paper" / "figures"
CURVES = {
    "Clinical C5 (XGBoost)": ("part04_clinical/oof_predictions.csv", "C5_clinical_full", "XGBoost"),
    "MRI only (LR)": ("part06_pca/nested_oof_predictions.csv", "MRI_PCA_nested", "LR"),
    "Fusion (LR)": ("part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "LR"),
    "Fusion (RF)": ("part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "RF"),
    "GCN (inductive)": ("part10_inductive/oof_predictions.csv", "GNN_inductive", "GCN"),
    "TabPFN (proposed)": ("part19_v5_tabpfn/oof_predictions.csv", None, None),
}
STATS = OUT / "part21_proposed_vs_baselines/proposed_vs_baselines.csv"
PERM = OUT / "part22_tabpfn_analyses/permutation_importance.csv"
plt.rcParams.update({"font.size": 8, "axes.titlesize": 9, "pdf.fonttype": 42})


def load(f, g, m):
    p = pd.read_csv(OUT / f)
    return p if g is None else p[(p.group == g) & (p.model == m)]


with PhaseRun("part24_paper_figures", __file__,
              inputs=[STATS, PERM] + sorted({str(OUT / v[0]) for v in CURVES.values()})) as run:
    FIG_DIR.mkdir(parents=True, exist_ok=True)

    # ---------------- Fig 2: ROC / PR
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.1))
    for name, spec in CURVES.items():
        p = load(*spec)
        lw = 2.2 if "proposed" in name else 1.0
        fpr, tpr, _ = roc_curve(p.y_true, p.y_prob)
        pr, rc, _ = precision_recall_curve(p.y_true, p.y_prob)
        axes[0].plot(fpr, tpr, lw=lw, label=f"{name} ({auc(fpr, tpr):.3f})")
        axes[1].plot(rc, pr, lw=lw, label=name)
    axes[0].plot([0, 1], [0, 1], ":", color="grey")
    axes[0].set(xlabel="1 - specificity", ylabel="sensitivity", title="(a) ROC (pooled out-of-fold)")
    axes[1].set(xlabel="recall", ylabel="precision", title="(b) Precision-recall", ylim=(0.4, 1.01))
    axes[0].legend(fontsize=6, loc="lower right")
    fig.tight_layout()
    for ext in ("pdf", "png"):
        fig.savefig(FIG_DIR / f"fig2_roc_pr.{ext}", dpi=300, bbox_inches="tight")
    run.save_fig(fig, "fig2_roc_pr.png")
    plt.close(fig)

    # ---------------- Fig 3: significance forest
    st = pd.read_csv(STATS)
    st = st[st.system == "System 1: TabPFN v2"]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0), sharey=True)
    order = st[st.metric == "mcc"].sort_values("delta").baseline.tolist()
    for ax, metric, title in [(axes[0], "mcc", "(a) $\\Delta$MCC"), (axes[1], "roc_auc", "(b) $\\Delta$ROC-AUC")]:
        s = st[st.metric == metric].set_index("baseline").loc[order]
        for i, (b, r) in enumerate(s.iterrows()):
            col = "#b03a2e" if r.verdict == "significantly BETTER" else "#7f8c8d"
            ax.errorbar(r.delta, i, xerr=[[r.delta - r.ci95_low], [r.ci95_high - r.delta]], fmt="o",
                        color=col, capsize=2, ms=4)
        ax.axvline(0, color="k", lw=0.6)
        ax.set_yticks(range(len(order)))
        ax.set_yticklabels(order)
        ax.set_title(title + " TabPFN - baseline")
    axes[1].text(0.98, 0.02, "red: Holm p < 0.05", transform=axes[1].transAxes, ha="right", fontsize=6)
    fig.tight_layout()
    for ext in ("pdf", "png"):
        fig.savefig(FIG_DIR / f"fig3_significance.{ext}", dpi=300, bbox_inches="tight")
    run.save_fig(fig, "fig3_significance.png")
    plt.close(fig)

    # ---------------- Fig 4: importance + calibration
    imp = pd.read_csv(PERM).sort_values("mean")
    label = {"sex_binary": "Sex", "Educ": "Education", "MRI embedding": "MRI (all PCs)"}
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.0))
    axes[0].barh([label.get(g, g) for g in imp.group], imp["mean"], xerr=imp["std"], color="#5b7fa6", capsize=2)
    axes[0].set(xlabel="drop in ROC-AUC when permuted", title="(a) Permutation importance (TabPFN)")
    axes[1].plot([0, 1], [0, 1], ":", color="grey")
    for name in ["Fusion (LR)", "Fusion (RF)", "TabPFN (proposed)"]:
        p = load(*CURVES[name])
        fr, mp = calibration_curve(p.y_true, p.y_prob, n_bins=10, strategy="quantile")
        axes[1].plot(mp, fr, marker="o", ms=3, lw=2.2 if "proposed" in name else 1.0, label=name)
    axes[1].set(xlabel="mean predicted probability", ylabel="observed fraction CDR > 0",
                title="(b) Reliability (pooled out-of-fold)")
    axes[1].legend(fontsize=7)
    fig.tight_layout()
    for ext in ("pdf", "png"):
        fig.savefig(FIG_DIR / f"fig4_xai_calibration.{ext}", dpi=300, bbox_inches="tight")
    run.save_fig(fig, "fig4_xai_calibration.png")
    plt.close(fig)
