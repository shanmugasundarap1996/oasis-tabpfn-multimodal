"""Part 19 v4 - Metric learning: Neighbourhood Components Analysis (NCA) learns a patient-similarity
space on the PCA-fusion features; a distance-weighted kNN classifies in that space.
Tuned on frozen inner folds: MRI PCA k, NCA output dimension, number of neighbours."""
import json

from sklearn.decomposition import PCA
from sklearn.neighbors import KNeighborsClassifier, NeighborhoodComponentsAnalysis
from sklearn.pipeline import Pipeline

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from models import preprocessor
from newmethods import BASELINE_FILE, PROTOCOL_FILE, compare

NESTED_K = [k for k in config.PCA_DIMS if k <= 64]
GRID = {"prep__mri__pca": [PCA(n_components=k, random_state=42) for k in NESTED_K] + ["passthrough"],
        "nca__n_components": [2, 8],
        "knn__n_neighbors": [5, 9, 15]}

with PhaseRun("part19_v4_metric_learning", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"grid": {k: [str(v) for v in vs] for k, vs in GRID.items()}}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    feats = emb + config.CLINICAL_FULL
    pipe = Pipeline([("prep", preprocessor(emb, config.CLINICAL_FULL, pca_dim=8)),
                     ("nca", NeighborhoodComponentsAnalysis(random_state=42, max_iter=200)),
                     ("knn", KNeighborsClassifier(weights="distance"))])
    spec = [{"group": "v4_metric_learning", "name": "NCA_kNN", "features": feats, "pipeline": pipe, "grid": GRID}]
    folds, preds, params = run_nested_cv(df, spec)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summary = summarize(folds)
    run.save_csv(summary, "summary.csv")
    print(summary[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))
    table, verdict = compare(folds, "v4_metric_learning")
    run.save_csv(table, "comparison_vs_baseline.csv")
    run.save_json(verdict, "verdict.json")
    print("\n", table[table.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))
    print("\nVERDICT:", json.dumps(verdict, indent=2, default=str))
    assert check_oof_integrity(preds, df)
