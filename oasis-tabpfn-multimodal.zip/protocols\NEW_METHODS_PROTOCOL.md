# Exploratory new-method protocol (Part 19) — frozen before v1 is run (2026-10-24)

Purpose: test whether a different learning paradigm beats the current best model.
This is a pre-registered, sequential, exploratory analysis; it does not change the frozen
main analysis (Parts 01–17).

## Baseline
Fusion PCA + Random Forest (`part07_fusion/fold_metrics.csv`, group `Fusion_PCA_nested`, model `RF`),
MCC 0.852 ± 0.070, ROC-AUC 0.971 ± 0.023. (Its estimate is already slightly optimistic because it was
selected among 8 candidates, which makes the comparison conservative.)

## Evaluation (identical for every version)
- Cohort, features, frozen 5×5 outer folds and frozen 3-fold inner folds from Parts 02–03.
- All preprocessing, PCA, tuning and stacking fitted inside the outer training set; tuning by inner-CV ROC-AUC.
- CDR is never an input. (v2 uses CDR level only as the training target.)
- Threshold 0.5. Same metrics as the main analysis; OOF probabilities saved.

## Success rule (per version, vs baseline, paired over the 25 folds)
A version is **significantly better** if ALL hold:
1. mean MCC > baseline mean MCC;
2. two-sided Wilcoxon signed-rank on MCC, p < 0.01 (= 0.05 / 5 planned versions, Bonferroni);
3. mean ROC-AUC ≥ baseline mean ROC-AUC − 0.005.
Also reported (not part of the rule): Δ macro-F1, Δ balanced accuracy, Δ AUC with bootstrap CIs,
Nadeau–Bengio corrected p, comparison against Fusion PCA + LR.

## Sequence (run in this order; stop at the first version meeting the rule)
| Version | Paradigm | Method |
|---|---|---|
| v1 | Stacked late fusion | Modality experts (MRI-PCA LR, clinical XGBoost, fusion RF) → logistic meta-learner on cross-fitted expert probabilities |
| v2 | Severity-aware ordinal learning | 3-level CDR target (0 / 0.5 / ≥1); P(CDR>0) = 1 − P(level 0); RF and LR on PCA fusion |
| v3 | Gated multimodal neural network | MRI and clinical encoders, per-patient sigmoid gate, modality dropout, 3-seed ensemble |
| v4 | Metric learning | Neighbourhood Components Analysis on PCA fusion + distance-weighted kNN |
| v5 | In-context foundation model | TabPFN on PCA fusion (only if installable offline-compatible; otherwise recorded as not run) |

## Amendments
| Date | Change | Reason |
|---|---|---|
| 2026-10-29 14:30 (after a reviewer-style review of main8; before these checks were run) | **Amendment 12 — complete image-level overlap audit of the external set and reproducibility check (no new model).**

**Part 53 (image audit).** Every raw MPRAGE repeat of all 416 OASIS-1 first sessions and of the 29 external OASIS-2 participants (plus the 14 earlier image-checked sessions) is downsampled 4× (block mean) after the same axis convention, and voxel-wise Pearson correlations are computed for every OASIS-2 × OASIS-1 session pair (maximum over repeat pairs).
- **Positive controls:** the 4 record-linked pairs that correlated at r = 0.89–0.97 at full resolution (Part 44).
- **Null:** each OASIS-2 session's correlations with all non-candidate OASIS-1 sessions.
- **Rule (fixed now):** an external participant is image-flagged if its maximum correlation with any OASIS-1 session reaches the threshold T, defined label-free before looking at the 29 as the midpoint between (a) the minimum positive-control correlation and (b) the 99th percentile of the null maxima of the 14 earlier sessions.
- **Reporting:** the number of the 29 flagged. Locked external metrics are recomputed excluding flagged participants, if any, as a sensitivity analysis.

**Part 54 (reproducibility).** The frozen models (Part 47, hash-checked) are reloaded and re-applied to the saved external features. The predictions must equal the saved Part 48 predictions (max |Δp| < 1e-9).

**Results (15:20).**
- **Part 54:** LR models are bit-identical. XGBoost and clinical TabPFN differ by ~2e-8 (float rounding). The multimodal TabPFN differs by up to 0.016 in probability (TabPFN CPU numerics), so the strict 1e-9 criterion fails for TabPFN.
  - **Follow-up (Part 54b, 3 re-runs):** AUC, MCC, BA and the predicted classes are identical for every model; Brier varies by ≤ 0.0001 and calibration slope by ≤ 0.001.
  - Reported as "every reported external metric reproduced".
- **Part 53:** all 416 OASIS-1 first sessions were cached. Reader check r = 1.000.
  - Positive controls: 0.891, 0.911, 0.898, 0.978. Null-max 99th percentile: 0.794. **T = 0.843.**
  - **1 of 29 external participants image-flagged:** OAS2_0112 vs OAS1_0123, r = 0.850 (second-best 0.732).
  - The other 28 have a maximum r of 0.56–0.81.
  - Sensitivity analysis without the flagged participant (Part 53b; n = 28, 13 CDR > 0): transportable multimodal AUC 0.851 [0.687, 0.968], MCC 0.586, Brier 0.139, slope 1.06; clinical TabPFN 0.892; fusion LR 0.892. No paired difference is significant. The conclusions are unchanged. | reviewer-style review of main8 (external independence; reproducibility) |
| 2026-10-29 13:15 (user: "one more; if positive and significant we go, else we use the previous results"; before v14 was computed) | **Amendment 11 — v14 "multi-view TabPFN with an inner-CV MCC threshold" (version 14; the last version).**

**Model.** Same probabilities as v13: the mean of TabPFN [ResNet-PCA + C5] and TabPFN [morphometry-PCA + C5]. In each outer training set:
- both components are refitted on the 3 frozen inner folds, using that outer fold's k from Parts 30 and 36;
- the threshold t ∈ {0.30, 0.325, …, 0.70} maximising MCC on the pooled inner out-of-fold averaged probabilities is selected (ties → closest to 0.5);
- t is applied to that outer fold's v13 test probabilities.

The outer test data never influence t.

**Success rule (fixed now; identical to Amendment 10).**
- Primary family: v14 vs fusion RF, LR and XGBoost, clinical C5 LR and XGBoost, MRI-only LR; metrics MCC, BA, AUC, Brier; two-sided Wilcoxon over 25 folds; Holm over 24 tests.
- **"Positive":** MCC significantly higher (p_Holm < 0.05) than **every** fusion and clinical baseline.
- Also reported: Nadeau–Bengio, the version check (MCC p vs fusion RF < 0.05/14 = 0.0036), and v14 vs v13 and vs TabPFN_v2 (secondary).

**Decision fixed by the user.** If not positive, the previous results stand and no further versions are tried. Reported whatever the result.

**Result (13:20; `outputs/part52_v14_threshold/`): NOT POSITIVE.**
- **v14 performance:** MCC 0.622, BA 0.806, AUC 0.889, Brier 0.134, sensitivity 0.778, specificity 0.833. The inner-CV thresholds were mostly below 0.5.
- **MCC vs fusion and clinical baselines:** +0.03 to +0.05, p_Holm 0.21–0.74; none significant.
- **AUC and Brier vs fusion:** significant, as for v13 (the probabilities are unchanged).
- **vs v13 and TabPFN_v2:** MCC −0.011 and −0.013 (not significant).
- **Version check:** fails (MCC p vs fusion RF 0.17 > 0.0036).
- **Decision:** the previous results (Draft 7a) stand; no further versions. | user request (final version) |
| 2026-10-29 12:40 (requested by the user; before v13 was computed — only row alignment of the two prediction files was checked) | **Amendment 10 — one further version, v13 "multi-view TabPFN" (version 13 of this study).**

**Model.** For every subject, seed and outer fold, P(AD) is the mean of the out-of-fold probabilities of two existing, independently fitted leakage-free models:
- TabPFN on [PCA_k(ResNet MRI) + 8 clinical] (Part 30, `TabPFN_v2`);
- TabPFN on [PCA_k(morphometry) + 8 clinical] (Part 36, `TabPFN_morph`).

Both use the same frozen folds and inner-CV k; nothing is refitted and no weight or threshold is tuned. Threshold 0.5.

**Primary family (fixed now).** v13 vs fusion PCA RF, LR and XGBoost, clinical C5 LR and XGBoost, and MRI-only LR (Part 30 / Part 04 fold metrics).
- Metrics: MCC, BA, AUC, Brier.
- Test: two-sided Wilcoxon over 25 folds, Holm over all 24 tests.
- Superiority if p_Holm < 0.05; *robust* if Nadeau–Bengio p_Holm < 0.05 as well.

**Secondary (separate Holm).** v13 vs each component (TabPFN_v2, TabPFN_morph).

**Multiplicity disclosure.** This is the 13th model version examined on this cohort. As an extra conservative check, the unadjusted MCC p-value vs fusion RF is also compared with 0.05/13 = 0.0038.

**Disclosure.** The design uses the known performance of both components (designed after Parts 30 and 36). It is reported whatever the result, and v13 replaces the proposed model only if it meets the primary rule and the user approves.

**Result (13:03; `outputs/part51_v13_multiview/`):**
- **v13 performance:** MCC 0.633, BA 0.813, AUC 0.889, Brier 0.134 — the same as TabPFN_v2 (all Δ ≈ 0, p = 1).
- **Primary family:**
  - AUC significantly higher than fusion RF, LR and XGBoost (p_Holm 0.049, 0.014, 0.020);
  - Brier significantly lower than all three fusion models (p_Holm ≤ 0.013);
  - MCC not significant vs any baseline (p_Holm 0.15–0.16);
  - nothing significant vs clinical LR or XGBoost;
  - Nadeau–Bengio robust only vs MRI-only.
- **Version check:** MCC p vs fusion RF = 0.013 > 0.0038, so it fails.
- **Decision:** v13 does not replace the proposed model. It may be reported only as a supporting robustness note (AUC vs fusion learners). | user request for a further version (Draft 8) |
| 2026-10-29 10:00 (before any external MRI data exist; ADNI access not yet requested) | **Amendment 9 — locked external validation of the multimodal model (Draft 8 plan; no new model).**

**(1) Freeze (Part 47).** Final pipelines are fitted once on all 166 primary OASIS-1 subjects. The MRI PCA k ∈ {8,16,24,32,64} is chosen by 5-fold stratified CV on OASIS-1 (seed 42, ROC-AUC); baseline hyperparameters use the same grids. Threshold 0.5. Locked models:
- (a) **primary external model:** transportable multimodal TabPFN [PCA_k(MRI) + Age, sex, Educ, MMSE];
- (b) full multimodal TabPFN [PCA_k(MRI) + 8 clinical], evaluated only if eTIV, nWBV, ASF and SES can be reproduced;
- (c) clinical TabPFN [Age, sex, Educ, MMSE] (and C5 if available);
- (d) MRI-only LR and MRI-only TabPFN;
- (e) fusion LR and XGBoost on (a)'s inputs.

Artifacts store the fitted transformers, k*, feature order, threshold, software versions, training-data hashes and the OASIS-1 reference distribution.

**(2) MRI features.** External scans differ from the official OASIS-1 T88 volumes, so all locked MRI models are fitted on OASIS-1 features produced by the harmonised raw-MRI pipeline H (`part43`), which is applied identically to external scans. External images are reoriented to RAS with nibabel before H. The fidelity of H on OASIS-1 is reported: per-feature correlation with official-T88 features, and internal 5×5 CV AUC of TabPFN on H features.

**(3) External cohort (Part 48; ADNI).**
- Baseline visit; age ≥ 60; T1 MPRAGE and same-visit MMSE available.
- Two pre-specified labelings: (i) diagnosis CN vs AD (MCI excluded); (ii) CDR global 0 vs > 0 (closest to the OASIS target).
- Education years mapped by the Part 17 rule.
- Overlap screen against OASIS-1 (ADNI includes a Washington University site): same sex and education, age within window, MMSE identical. Flagged subjects are excluded in a sensitivity analysis.

**(4) Analysis.**
- Locked models only; no retuning, recalibration or feature selection using external labels.
- Metrics: BA, macro-F1, MCC, AUC, PR-AUC, Brier, ECE, sensitivity, specificity, calibration slope and calibration-in-the-large, with 2000-sample subject-bootstrap CIs; reliability diagram.
- Paired bootstrap: (a) vs (c), (d) and (e), Holm-corrected.
- Subgroups: sex, age 60–74 vs ≥ 75, site/scanner manufacturer.
- Internal (repeated CV) vs external comparison table, noting that the estimands differ.
- Reported whatever the direction.

**Implementation note (10:20, before any external data):** pipeline H as first written registered raw with-skull scans to a skull-stripped template and failed visually (one-subject test). It was corrected before any cohort-level use:
- template = mean of the unmasked official T88 images of disc 1 (39 sessions, intensity-scaled; label-free);
- head-to-head Mattes-MI similarity, then affine registration;
- brain mask (≥ 50 % of the 416 masked images) applied after resampling.
After the fix, the one-subject test showed correct anatomical alignment.

**Addendum (10:30, before any OASIS-2 MRI feature or locked prediction was computed):** OASIS-2 is added as a locked external set for the **full multimodal system**.
- **Data:** raw MR1 MPRAGE repeats of the 29 overlap-screened participants (Part 42 rule, no detected overlap), downloaded from the same open OASIS server (OASIS Data Use Agreement), plus the 14 sessions already on disk.
- **Method:** same locked models, pipeline H and statistics as for ADNI. The primary model is the transportable multimodal TabPFN.
- **Labels:** CDR 0 vs > 0 at visit 1, as in Part 42.
- **Status:** exploratory because of the small sample. A sensitivity set of all image-available OASIS-2 sessions, including probable overlaps, is reported only as a contamination illustration.

**Result (12:29; `outputs/part48_external_oasis2/`, `part50_h_fidelity/`):**
- **Fidelity of pipeline H on OASIS-1:**
  - Per-feature agreement with the official features is low (median r 0.27).
  - MRI-only LR AUC: 0.653 (H) vs 0.709 (official).
  - The transportable multimodal TabPFN on H performs like the official version (MCC 0.652 vs 0.620, AUC 0.883 vs 0.885; p_Holm ≥ 0.13).
- **Locked external test, OASIS-2 overlap-screened (n = 29, 14 CDR > 0), transportable multimodal TabPFN:**
  - AUC 0.862 [0.700, 0.968], MCC 0.606, BA 0.788, Brier 0.137, sensitivity 0.643, specificity 0.933, calibration slope 1.16.
  - Locked clinical TabPFN: AUC 0.900; fusion LR: 0.900; fusion XGBoost: 0.814.
  - MRI-only: AUC 0.61–0.67.
  - No paired difference is significant after Holm. MRI-only is the closest (MCC +0.42, p 0.015, p_Holm 0.39).
  - Sex gap persists: AUC 0.933 in women vs 0.815 in men.
- **All 41 image-available sessions (contamination illustration):** AUC 0.842.
- **Conclusion:** the locked multimodal model kept its internal level of discrimination and calibration on an external sample, but MRI added nothing measurable there, and between-model differences are not estimable with n = 29. | reviewer-style external-validation plan pasted by the user (Draft 8) | reviewer-style external-validation plan pasted by the user (Draft 8) |
| 2026-10-29 (after an external reviewer-style review of main7; before any of these checks was run) | **Amendment 8 — verification analyses (no new model; no result of Parts 30–42 changes).** **Part 44 (overlap verification by image fingerprint):** for the 14 OASIS-2 first-visit sessions already on disk (OAS2_0001–0018, partial download), the raw MPRAGE repeats are compared voxel-wise with the raw repeats of the best-matching OASIS-1 session from `overlap_diagnostic_pairs.csv` (same array layout, same scanner protocol): Pearson correlation of raw intensities for every repeat pair, maximum over pairs. Null distribution: the same OASIS-2 sessions against the other 13 (non-matched) OASIS-1 sessions. A pair is **image-confirmed** if its maximum correlation is ≥ 0.99 and exceeds every null value of that OASIS-2 session. Record-linkage categories reported for all 150: *confirmed* (image-confirmed), *probable* (eTIV within 0.5 % of a candidate under the overlap rule), *possible* (flagged by the broad rule only), *no detected overlap* (29). The composition of the probable group (identical age, identical MMSE, identical CDR) is tabulated. **Part 45 (subject-level uncertainty):** because the 25 folds re-use the same 166 subjects, paired differences (proposed TabPFN − comparator) in AUC, Brier and MCC are re-estimated by a subject-level bootstrap (2000 resamples of subjects; metric computed per seed on pooled out-of-fold predictions, averaged over the 5 seeds), two-sided bootstrap p, Holm over comparators × metrics; comparators = fusion LR/RF/XGBoost and MRI-only LR and transportable TabPFN (Part 30), fusion CatBoost/LightGBM/isotonic RF (Part 33), clinical C5 LR/XGBoost (Part 04) and clinical-only TabPFN (Part 31) — widened before running. Reported whatever the direction. **Part 44 result (00:35):**
- **Pre-specified rule:** 0 of 14 image-checked pairs reached r ≥ 0.99, so none is image-confirmed.
- **Tight record matches:** 4 of the 6 with eTIV < 0.5 % correlated at r = 0.89–0.97 on raw voxels, against null maxima of 0.49–0.61. The other two (OAS2_0007: 0.59 vs null 0.55; OAS2_0001: 0.54 vs null 0.59) did not separate. (Corrected 09:20; an earlier note said 5 of 6.) All 8 looser matches stayed at the null level.
- **Correction to main7:** of the 83 probable matches, only 62 have identical age and MMSE (70 identical MMSE, 72 identical CDR), not 83 as main7 stated.
- **Post-hoc flip diagnostic (`part44b`, 3 pairs):** no axis flip raises the correlation, so the sub-0.99 values are not an orientation artefact. The images are strongly similar but not identical, consistent with the same participant rather than proven identical files.
- **Conclusion:** the overlap is reported as *probable*, not confirmed.

**Part 45 result (2026-10-29 09:10, `subject_bootstrap.csv`):**
- Pooled values for the proposed model: AUC 0.881, Brier 0.135, MCC 0.627.
- **Brier vs fusion LR / RF / XGBoost / CatBoost:** Δ −0.013 to −0.023 with CIs excluding zero (unadjusted p 0.004–0.017), but **not significant after Holm over 33 tests** (p_Holm 0.11–0.43).
- **Significant after Holm:** only Brier vs LightGBM (p_Holm 0.017) and all metrics vs MRI-only LR.
- **MCC:** CIs exclude zero vs fusion XGBoost, LightGBM and clinical TabPFN; none significant after Holm.
- **AUC:** vs clinical models, none significant.
- **Conclusion:** the fold-level Brier advantage is only partly confirmed at the subject level; main7a states this. | external review of main7: identity claims need verification; fold-level CIs may understate uncertainty |
| 2026-10-28 23:05 (after Parts 40–41, before any OASIS-2 outcome was computed; only the column schema and row counts of the OASIS-2 file were inspected) | **Amendment 7 — external validation on OASIS-2 (no new model versions; the proposed model is unchanged).** **External cohort:** OASIS-2 (`data/external_oasis2/oasis_longitudinal_demographics.xlsx`, official OASIS site, SHA-256 2298ED89…F930E), first visit (Visit = 1) of each of the 150 subjects (all aged ≥ 60); target CDR > 0 at that visit (the OASIS `Group` label is not used). Educ years → OASIS-1 code by the Part 17 function `educ_years_to_oasis1` (frozen 2026-10-24); sex F = 0 / M = 1; missing SES imputed inside the pipeline (training median). **Training:** all 166 primary OASIS-1 subjects; baseline hyperparameters tuned by 5-fold stratified CV on OASIS-1 (seed 42, ROC-AUC, same grids as the main analysis); threshold 0.5; each model evaluated once on OASIS-2. **Part 42 (E1, clinical transport):** TabPFN[C5] vs LR[C5], RF[C5], XGBoost[C5]. **Part 43–44 (E2, proposed multimodal model):** because OASIS-2 releases only raw scans, both OASIS-1 (training) and OASIS-2 (test) first-session raw MPRAGE scans are processed by one harmonised pipeline H (SimpleITK: rigid average of all MR1 MPRAGE repeats → N4 bias correction → affine registration to a template = voxel-wise mean of all 416 official OASIS-1 T88 masked images (label-free) → template brain mask (voxels non-zero in ≥ 50 % of those images) → the Part 29 slices, intensity scaling and frozen ResNet18). Models: TabPFN[PCA_k(MRI-H) + C5] (k ∈ {8,16,24,32,64} by 5-fold CV on OASIS-1), TabPFN[C5], fusion LR and XGBoost[PCA(MRI-H) + C5], MRI-only LR. Fidelity of H reported on OASIS-1 (per-feature correlation with the official-T88 features; internal CV AUC). **Statistics:** AUC, MCC, BA, Brier, calibration slope and calibration-in-the-large, with 95 % subject-bootstrap CIs (2000); paired bootstrap Δ (proposed − comparator), two-sided bootstrap p, Holm within each of E1 and E2. Domain shift: covariate standardised mean differences. **Overlap check:** an OASIS-2 subject is flagged as a possible OASIS-1 participant if some OASIS-1 subject (any age) has the same sex, Educ code and SES (when both recorded), eTIV within 2 % and OASIS-2 age − OASIS-1 age in [−2, +6]; sensitivity analysis excluding flagged subjects. Results are reported whatever their direction. **Finding (23:20, Part 42 + post-hoc diagnostic `part42b_overlap_diagnostic.py`):** the pre-specified overlap rule flagged 121/150 OASIS-2 subjects. Against null age windows (2–4 tight matches), 83 OASIS-2 first visits match an OASIS-1 first session to within 0.5 % eTIV with identical age, MMSE and (87 %) CDR — i.e. the same participant and almost certainly the same visit; 70 of them are in our 166-subject training cohort. OASIS-2 is therefore **not an independent external cohort** for OASIS-1-trained models; the full-OASIS-2 numbers are reported only as a contamination demonstration, and the pre-specified sensitivity subset (29 unflagged subjects) is the only independent estimate. **Decision (23:25, user):** E2 (harmonised MRI, Parts 43–44) is not run — with only 29 independent subjects it cannot be informative; the OASIS-2 raw download was stopped (partial files in `oasis2_raw/`, local only). `part43_harmonised_mri.py` is kept unrun for a future independent cohort. | reviewer-style review: no external validation; OASIS-2 is openly downloadable with the same clinical variables |
| 2026-10-28 (after the reviewer-style review of main5, before any of these analyses) | **Amendment 6 — reviewer-driven sensitivity and supporting analyses (no new model versions; the proposed model is unchanged).** All use the label-free ResNet features of Part 29, nested tuning, threshold 0.5, Wilcoxon + Holm within each family below (primary) and Nadeau–Bengio (sensitivity). **Part 39 (cohort N = 166, frozen folds).** *Family M1 — MRI beyond non-imaging clinical data:* non-imaging clinical set NI = {Age, sex, Educ, SES, MMSE} (eTIV, nWBV and ASF excluded as MRI-derived). Primary comparison: TabPFN[MRI + NI] vs TabPFN[NI], LR[NI], XGBoost[NI]; also fusion LR[MRI + NI] reported. *Family M2 — without cognitive testing:* NM = {Age, sex, Educ, SES, eTIV, nWBV, ASF}. Primary: TabPFN[MRI + NM] vs TabPFN[NM], fusion RF[MRI + NM], fusion LR[MRI + NM], clinical C4 LR (Part 04); secondary: TabPFN[MRI + demographics] vs TabPFN[demographics]. **Part 40 (M3, full cohort):** all OASIS-1 first sessions with CDR and age ≥ 60 (no third-party-embedding filter); new 5×5 outer / 3-fold inner folds generated by the Phase 03 procedure (same seeds, stratified by CDR level); proposed TabPFN vs fusion LR, fusion XGBoost, clinical C5 LR/XGBoost, TabPFN clinical-only, MRI-only LR (RF omitted for time). **Part 41:** (M7) permutation importance of the proposed model on the Part 30 folds (refit with the inner-CV-selected k per fold; blocks MRI / MMSE / volumetrics / demographics; 5 permutations; ΔAUC and ΔBrier); (M6) calibration slope and calibration-in-the-large from Part 30/33 out-of-fold predictions (per seed, averaged) and a global Holm correction over all paired tests of Parts 30, 31-ablation, 33 and 36; (M8) per-sex calibration and the female–male AUC gap within the CDR 0 vs 0.5 subset (subject bootstrap, 2000 resamples). Results are reported whatever their direction. **Note (21:35, before any importance result was summarised):** for time feasibility (three runs sharing the CPU), M7 is restricted to the 10 outer folds of seeds 42 and 2026 (5 permutations each). | reviewer-style review (main5): MRI-derived volumetrics in the clinical block, MMSE dominance, cohort filter, statistics, interpretability, subgroup case mix |
| 2026-10-27 12:45 (after Parts 30–34 on label-free features, before any morphometry result) | **Amendment 5 — label-free regional tissue morphometry (v12).** **Representation R2:** OASIS-1 FSL-FAST tissue segmentation of the atlas-registered (T88) first-session volume (`FSL_SEG/*_fseg.img`, labels CSF/GM/WM), block-averaged into 8 mm cubes (22×26×22 grid) giving the GM and CSF fraction per cube; cubes kept if the mean fraction of that tissue over all 416 OASIS-1 sessions is ≥ 0.10 (unsupervised, label-free prevalence filter; no outcome used). Script: `part35_morphometry.py` → `data/mri_morph_own.csv`. **v12 proposed model:** TabPFN v2 on [PCA_k(R2) ‖ 8 clinical], k ∈ {8,16,24,32,64} by inner-CV ROC-AUC, threshold 0.5 — identical pipeline to the main4 proposed model, only the MRI block changes. **Baselines on R2 (same folds, nested):** fusion PCA LR, RF, XGBoost; MRI-only (R2) LR; plus the existing clinical C5 LR/XGBoost, TabPFN clinical-only (Part 31) and TabPFN with ResNet features (Part 30). Script: `part36_morph_benchmark.py`. **Primary test (fixed now):** v12 vs each baseline, paired over 25 folds, two-sided Wilcoxon on MCC, BA, ROC-AUC, Brier with Holm over all comparisons (same rule as Part 30); Nadeau–Bengio as sensitivity. A claim of superiority over a baseline requires p_Holm < 0.05; "robust" additionally requires Nadeau–Bengio p_Holm < 0.05. **Disclosure:** this is the 12th model version examined on this cohort and the second label-free MRI representation; it was motivated by the weak ImageNet-slice signal (MRI-only AUC 0.71). Results will be reported whatever their direction, and the ResNet-based analysis (Parts 30–34) remains reported in full. **Verdict (2026-10-27 13:56, `outputs/part36_morph_benchmark/v12_vs_baselines.csv`):**
- **v12 performance:** MCC 0.606, AUC 0.890, Brier 0.135.
- **Significant (Holm):** higher AUC than fusion RF/LR/XGBoost on R2 (p_Holm 0.014–0.042); lower Brier than all three (p_Holm ≤ 0.004); better than MRI-only on all metrics.
- **Not significant:** MCC versus any fusion or clinical baseline.
- **Robust under Nadeau–Bengio:** only the MRI-only comparison.
- **Against TabPFN-ResNet:** no difference after correction (ΔMCC −0.028).
- **Decision:** v12 does not replace the proposed model; it is reported as a representation-robustness analysis. | user requested a model with significant results; one principled, pre-specified change (domain-appropriate atrophy features) instead of an open-ended search |
| 2026-10-26 (after v10, before v11) | **Amendment 4.** One further version, **v11 SAVE-PFN** (Severity-Aware multi-View Ensemble in-context learning): TabPFN v2 conditioned on the 3-level CDR target (0 / 0.5 / ≥1; CDR never an input), P(CDR>0) = 1 − P(level 0), averaged over 8 views = feature sets {transportable (age, sex, education, MMSE), MRI+MMSE+Age} × MRI PCA k ∈ {8, 16, 32, 64}; threshold fixed at 0.5; no tuning. Total planned versions = 11 → **α = 0.05 / 11 = 0.0045** (all earlier verdicts remain negative at this level). Component ablation reported descriptively (not tested against the rule): identical 8 views with binary context. **Disclosure:** the view design uses findings from earlier versions on the same folds (v8 k-bagging; v9 inner-CV choice of lean feature sets; error concentration at CDR 0.5), so any positive result is exploratory and requires external validation. | user requested one more novel version; design fixed before running |
| 2026-10-25 (after v5, before v6) | **Amendment 3.** Five further versions planned (v6–v10), all built on TabPFN (best overall in v5). Total planned versions = 10, so the significance level for the MCC test becomes **α = 0.05 / 10 = 0.005 for every version** (v1–v5 re-judged at this stricter level; none changes). Sequence stops at the first version meeting the rule. New versions: **v6** TabPFN + decision threshold tuned for MCC on inner out-of-fold predictions; **v7** probability average of TabPFN and fusion-RF + inner-tuned threshold; **v8** TabPFN bagged over MRI PCA k ∈ {8,16,24,32,64} + inner-tuned threshold; **v9** TabPFN with feature set (full / transportable / MRI+MMSE / MRI+MMSE+Age, k = 16) chosen by inner-CV ROC-AUC + inner-tuned threshold; **v10** super-learner (logistic meta-learner on logits of TabPFN, RF, XGBoost, LR inner out-of-fold predictions) + inner-tuned threshold. Hyperparameters of the component models are those already selected by inner CV in Parts 07 and 19-v5; nothing is chosen on outer test folds. | user requested continued search for a significantly better model; Bonferroni over all planned versions keeps the family-wise error at 5 % |
| 2026-10-24 (after v4, before v5) | v5 uses TabPFN model version 2 (`ModelVersion.V2`, tabpfn 9.2.0, CPU); MRI PCA k tuned on inner folds; no other hyperparameters | versions ≥ 2.5 require interactive browser licence acceptance, impossible in this non-interactive environment; v2 weights are openly downloadable |
| 2026-10-24 (after v1, before v2) | v2 primary model = RF (same learner as baseline, isolates the paradigm effect); v2-LR is descriptive only and not tested against the rule | the table listed two learners for v2 without saying which one is tested |
