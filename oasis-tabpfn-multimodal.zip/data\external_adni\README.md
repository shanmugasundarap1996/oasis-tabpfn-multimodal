# ADNI data for the Draft 8 external validation — what to request and download

The locked external-validation analysis (Amendment 9; `pipeline/part48_external_locked.py`) is ready. It needs ADNI
data, which only an approved investigator can download. Menu names below can change; **verify them on the ADNI site**.

## 1. Apply for access (author task)
- Site: https://adni.loni.usc.edu → "Data & Samples" → "Access Data and Samples" → apply through the LONI Image and
  Data Archive (IDA, https://ida.loni.usc.edu).
- You will accept the ADNI Data Use Agreement and give the project title and purpose. Suggested text:
  *"External validation of a locked multimodal (T1 MRI + clinical) Alzheimer's disease classifier developed on
  OASIS-1."*
- Approval usually takes about 1–2 weeks.
- The ADNI publication policy requires the ADNI acknowledgement text and authorship statement in the paper.

## 2. Files to download after approval
| What | Where in IDA (verify) | Save as |
|---|---|---|
| Merged clinical table (baseline age, sex, education, MMSE, diagnosis) | Download → Study Data → "ADNIMERGE" (Key ADNI tables merged) | `data/external_adni/ADNIMERGE.csv` |
| Clinical Dementia Rating (global CDR) | Study Data → Assessments → "Clinical Dementia Rating (CDR)" | `data/external_adni/CDR.csv` |
| Baseline T1 MRI | Search → Advanced Image Search: Modality MRI; Research group CN and AD (MCI optional); Visit = Screening/Baseline; Description containing "MPRAGE" (ADNI1/GO/2) or "Accelerated Sagittal MPRAGE" (ADNI3); one series per subject; download as **NIfTI** | `data/external_adni/MRI/<PTID>/...` (keep the IDA folder structure) |

Download only these files: no PET, fMRI or genetics. Keep everything local and **never upload ADNI data**.

## 3. Then run
```
cd pipeline
python part48_external_locked.py adni
```
- The script checks the frozen-model hashes and builds both labelings (CN vs AD; CDR 0 vs > 0).
- It screens for OASIS-1 overlap, runs pipeline H on every T1 scan, and writes all metrics, paired tests, subgroups and
  predictions to `outputs/part48_external_adni/`.
- Before running, check the column names in `ADNI_COLS` against ADNIMERGE. Look at the first few `qc_axial` images
  in `mri_harmonised/adni/`.
