"""Part 53b - Amendment 12 sensitivity: locked external metrics recomputed without the image-flagged participant(s)
(Part 53), from the saved Part 48 predictions (no model is refitted)."""
import numpy as np
import pandas as pd

import config
import external_tools as et
from common import PhaseRun

P48, P53 = config.OUTPUT_DIR / "part48_external_oasis2", config.OUTPUT_DIR / "part53_overlap_image_audit_full"

with PhaseRun("part53b_external_without_flagged", __file__,
              inputs=[P48 / "predictions_label_cdr_overlap-screened.csv", P53 / "external_image_audit.csv"]) as run:
    pred = pd.read_csv(P48 / "predictions_label_cdr_overlap-screened.csv")
    flagged = set(pd.read_csv(P53 / "external_image_audit.csv").query("image_flagged").oasis2.str.replace("_MR1", ""))
    keep = ~pred.subject_id.isin(flagged)
    d = pred[keep]
    y = d.label_cdr.astype(int).to_numpy()
    probs = {c[2:]: d[c].to_numpy() for c in d.columns if c.startswith("p_")}
    t = et.ci_table(y, probs, f"overlap-screened minus image-flagged ({len(flagged)})")
    run.save_csv(t, "metrics_without_flagged.csv")
    run.save_csv(et.paired_bootstrap(y, probs, "multimodal_transportable_TabPFN"), "paired_without_flagged.csv")
    print(f"flagged: {sorted(flagged)}; n = {len(y)}, CDR>0 = {int(y.sum())}")
    print(t[["model", "n", "roc_auc", "roc_auc_lo", "roc_auc_hi", "mcc", "balanced_accuracy", "brier", "cal_slope"]].round(3).to_string(index=False))
