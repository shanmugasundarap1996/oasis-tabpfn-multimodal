"""Dense 2-layer GCN and GAT (plain PyTorch; N <= 166 so dense adjacency is cheap),
plus the inner-CV tuning used by Parts 09 and 10."""
import itertools

import numpy as np
import torch
import torch.nn.functional as F
from joblib import Parallel, delayed
from sklearn.metrics import roc_auc_score
from torch import nn

from graphs import inductive_adjacency, node_features, transductive_adjacency

GNN_GRID = {
    "graph": ["G1_clinical", "G3_clin+MRI_raw", "G4_clin+MRI_PCA"],
    "k": [5, 9, 15],
    "weight_decay": [5e-4, 5e-3],
}
FIXED = {"hidden": 32, "dropout": 0.5, "lr": 0.01, "epochs": 200, "distance": "euclidean", "heads": 4}


def normalize_adj(A):
    A = A + np.eye(len(A), dtype=np.float32)
    d = 1.0 / np.sqrt(A.sum(1))
    return torch.tensor(d[:, None] * A * d[None, :], dtype=torch.float32)


class DenseGCN(nn.Module):
    def __init__(self, d, h, drop):
        super().__init__()
        self.l1, self.l2, self.drop = nn.Linear(d, h), nn.Linear(h, 2), drop

    def forward(self, x, A_hat, mask=None):
        x = F.dropout(x, self.drop, self.training)
        x = F.relu(A_hat @ self.l1(x))
        x = F.dropout(x, self.drop, self.training)
        return A_hat @ self.l2(x)


class DenseGATLayer(nn.Module):
    def __init__(self, d, f, heads, drop, concat=True):
        super().__init__()
        self.W = nn.Linear(d, heads * f, bias=False)
        self.a_src = nn.Parameter(torch.empty(heads, f))
        self.a_dst = nn.Parameter(torch.empty(heads, f))
        nn.init.xavier_uniform_(self.a_src); nn.init.xavier_uniform_(self.a_dst)
        self.h, self.f, self.drop, self.concat = heads, f, drop, concat

    def forward(self, x, mask):
        n = x.shape[0]
        Wh = self.W(x).view(n, self.h, self.f)                         # N,H,F
        e = (Wh * self.a_src).sum(-1)[:, None, :] + (Wh * self.a_dst).sum(-1)[None, :, :]  # N,N,H
        e = F.leaky_relu(e, 0.2).masked_fill(~mask[:, :, None], float("-inf"))
        att = F.dropout(torch.softmax(e, dim=1), self.drop, self.training)
        out = torch.einsum("ijh,jhf->ihf", att, Wh)
        return out.reshape(n, -1) if self.concat else out.mean(1)


class DenseGAT(nn.Module):
    def __init__(self, d, h, drop, heads=4):
        super().__init__()
        self.g1 = DenseGATLayer(d, h // heads, heads, drop, concat=True)
        self.g2 = DenseGATLayer(h, 2, 1, drop, concat=False)
        self.drop = drop

    def forward(self, x, A_hat, mask):
        x = F.dropout(x, self.drop, self.training)
        x = F.elu(self.g1(x, mask))
        x = F.dropout(x, self.drop, self.training)
        return self.g2(x, mask)


def fit_predict(arch, X, A, y_train, n_train, cfg, seed, return_curve=False):
    """Train on the first n_train nodes (labels), predict P(y=1) for the remaining nodes."""
    torch.manual_seed(seed)
    x = torch.tensor(X, dtype=torch.float32)
    A_hat = normalize_adj(A)
    mask = torch.tensor((A + np.eye(len(A))) > 0)
    yt = torch.tensor(y_train, dtype=torch.long)
    Model = DenseGCN if arch == "GCN" else DenseGAT
    model = Model(X.shape[1], cfg["hidden"], cfg["dropout"])
    opt = torch.optim.Adam(model.parameters(), lr=cfg["lr"], weight_decay=cfg["weight_decay"])
    curve = []
    for _ in range(cfg["epochs"]):
        model.train(); opt.zero_grad()
        loss = F.cross_entropy(model(x, A_hat, mask)[:n_train], yt)
        loss.backward(); opt.step()
        curve.append(loss.item())
    model.eval()
    with torch.no_grad():
        prob = torch.softmax(model(x, A_hat, mask)[n_train:], 1)[:, 1].numpy()
    return (prob, curve) if return_curve else prob


def evaluate_split(arch, df, emb, y, tr, te, cfg, seed, mode="transductive", return_curve=False):
    Xtr, Xte = node_features(df, emb, tr, te, cfg["graph"], seed=seed)
    adj = transductive_adjacency if mode == "transductive" else inductive_adjacency
    A = adj(Xtr, Xte, cfg["k"], cfg["distance"])
    return fit_predict(arch, np.vstack([Xtr, Xte]), A, y[tr], len(tr), cfg, seed, return_curve)


def configs():
    keys = list(GNN_GRID)
    return [{**FIXED, **dict(zip(keys, v))} for v in itertools.product(*GNN_GRID.values())]


def _inner_score(arch, df, emb, y, tr, inner, cfg, seed, mode):
    scores = []
    for itr, iva in inner:
        p = evaluate_split(arch, df, emb, y, tr[itr], tr[iva], cfg, seed, mode)
        scores.append(roc_auc_score(y[tr[iva]], p))
    return float(np.mean(scores))


def tune(arch, df, emb, y, tr, inner, seed, mode="transductive"):
    """Inner-CV ROC-AUC for every config (parallel over configs). Returns (best_cfg, table)."""
    torch.set_num_threads(1)
    cfgs = configs()
    sc = Parallel(n_jobs=-1)(delayed(_inner_score)(arch, df, emb, y, tr, inner, c, seed, mode) for c in cfgs)
    best = cfgs[int(np.argmax(sc))]
    return best, [{**c, "inner_auc": s} for c, s in zip(cfgs, sc)]
