"""Part 11 - Missing-modality robustness.

At test time a fraction r of test subjects lose a modality (values set to missing, then
imputed with the TRAINING median by the fitted pipeline). Scenarios: MRI missing, MMSE missing,
MRI+MMSE missing. Models:
  - Fusion-LR (C5 + MRI PCA, hyperparameters + k tuned by inner CV)          [standard]
  - Fusion-LR trained with modality dropout p (training set augmented with copies whose
    MRI block / MMSE are masked with probability p), same tuned hyperparameters
  - GCN with the Part 09 per-fold configuration
Each (fold, r) masking is repeated N_REPEATS times with fixed seeds and averaged.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from sklearn.base import clone
from sklearn.decomposition import PCA
from sklearn.model_selection import GridSearchCV

import config
from common import (PhaseRun, binary_metrics, embedding_cols, inner_splits, iter_outer_folds,
                    load_cohort)
from gnn import evaluate_split
from models import build

RATES = [0.0, 0.1, 0.2, 0.3, 0.5, 1.0]
DROPOUT_P = [0.1, 0.2, 0.3, 0.5]
N_REPEATS = 5
SCENARIOS = {"MRI_missing": "mri", "MMSE_missing": "mmse", "MRI+MMSE_missing": "both"}
NESTED_K = [k for k in config.PCA_DIMS if k <= 64]
PART09_SEL = config.OUTPUT_DIR / "part09_gnn" / "selected_configs.csv"


def mask(frame, rows, what, emb):
    out = frame.copy()
    if what in ("mri", "both"):
        out.loc[out.index[rows], emb] = np.nan
    if what in ("mmse", "both"):
        out.loc[out.index[rows], "MMSE"] = np.nan
    return out


def augment(Xtr, ytr, p, emb, rng):
    """Modality dropout as data augmentation: one masked copy of the training set."""
    copy = Xtr.copy()
    m_mri = rng.random(len(copy)) < p
    m_mmse = rng.random(len(copy)) < p
    copy.loc[copy.index[m_mri], emb] = np.nan
    copy.loc[copy.index[m_mmse], "MMSE"] = np.nan
    return pd.concat([Xtr, copy]), np.concatenate([ytr, ytr])


with PhaseRun("part11_missing", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PART09_SEL],
              params={"rates": RATES, "dropout_p": DROPOUT_P, "repeats": N_REPEATS,
                      "scenarios": list(SCENARIOS)}) as run:
    torch.set_num_threads(4)
    df = load_cohort()
    emb = embedding_cols(df)
    feats = emb + config.CLINICAL_FULL
    y = df[config.TARGET_COL].to_numpy()
    sel = pd.read_csv(PART09_SEL)
    pca_grid = {"prep__mri__pca": [PCA(n_components=k, random_state=42) for k in NESTED_K] + ["passthrough"]}
    rows = []
    for seed, fold, tr, te in iter_outer_folds(df):
        pipe, grid = build("LR", mri_cols=emb, tab_cols=config.CLINICAL_FULL, pca_dim=8, extra_grid=pca_grid)
        gs = GridSearchCV(pipe, grid, cv=inner_splits(df, seed, fold, tr), scoring=config.TUNING_SCORING,
                          n_jobs=-1).fit(df.iloc[tr][feats], y[tr])
        models = {"Fusion_LR_standard": gs.best_estimator_}
        for p in DROPOUT_P:
            Xa, ya = augment(df.iloc[tr][feats], y[tr], p, emb, np.random.default_rng(seed * 100 + fold))
            models[f"Fusion_LR_dropout_p{p}"] = clone(gs.best_estimator_).fit(Xa, ya)
        cfg = sel[(sel.arch == "GCN") & (sel.seed == seed) & (sel.fold == fold)].iloc[0].to_dict()
        cfg["k"], cfg["hidden"], cfg["epochs"] = int(cfg["k"]), int(cfg["hidden"]), int(cfg["epochs"])

        for scen, what in SCENARIOS.items():
            for r in RATES:
                reps = 1 if r in (0.0, 1.0) else N_REPEATS
                for rep in range(reps):
                    rng = np.random.default_rng(seed * 1000 + fold * 10 + rep)
                    rows_te = rng.choice(len(te), int(round(r * len(te))), replace=False)
                    Xte = mask(df.iloc[te][feats], rows_te, what, emb)
                    for name, mdl in models.items():
                        prob = mdl.predict_proba(Xte)[:, 1]
                        m = binary_metrics(y[te], (prob >= 0.5).astype(int), prob)
                        rows.append({**m, "model": name, "scenario": scen, "rate": r, "rep": rep,
                                     "seed": seed, "fold": fold})
                    dfm = df.copy()
                    dfm.loc[df.index[te]] = mask(df.iloc[te], rows_te, what, emb)
                    prob = evaluate_split("GCN", dfm, emb, y, tr, te, cfg, seed * 10 + fold)
                    m = binary_metrics(y[te], (prob >= 0.5).astype(int), prob)
                    rows.append({**m, "model": "GCN", "scenario": scen, "rate": r, "rep": rep,
                                 "seed": seed, "fold": fold})
        print(f"  seed {seed} fold {fold} done")

    res = pd.DataFrame(rows)
    run.save_csv(res, "robustness_per_fold.csv")
    per_fold = res.groupby(["model", "scenario", "rate", "seed", "fold"])[
        ["balanced_accuracy", "macro_f1", "mcc", "roc_auc"]].mean().reset_index()
    summ = per_fold.groupby(["model", "scenario", "rate"]).agg(
        macro_f1=("macro_f1", "mean"), macro_f1_sd=("macro_f1", "std"),
        mcc=("mcc", "mean"), mcc_sd=("mcc", "std"),
        roc_auc=("roc_auc", "mean"), roc_auc_sd=("roc_auc", "std")).reset_index()
    run.save_csv(summ, "robustness_summary.csv")
    print("\nRobustness (mean over 25 folds):\n",
          summ.pivot_table(index=["scenario", "model"], columns="rate", values="mcc").round(3).to_string())

    fig, axes = plt.subplots(1, 3, figsize=(15, 4), sharey=True)
    for ax, scen in zip(axes, SCENARIOS):
        for name, s in summ[summ.scenario == scen].groupby("model"):
            ax.plot(s.rate, s.mcc, marker="o", label=name,
                    lw=2.5 if name in ("Fusion_LR_standard", "GCN") else 1.2)
        ax.set_title(scen.replace("_", " ")); ax.set_xlabel("fraction of test subjects affected")
    axes[0].set_ylabel("MCC (25 outer folds)")
    axes[0].legend(fontsize=7)
    fig.tight_layout()
    run.save_fig(fig, "fig_missing_modality_robustness.png")
    plt.close(fig)
