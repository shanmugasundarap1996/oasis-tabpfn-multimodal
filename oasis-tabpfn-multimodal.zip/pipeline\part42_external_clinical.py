"""Part 42 - Amendment 7, E1: external validation of the clinical (C5) models on OASIS-2.

Train on all 166 primary OASIS-1 subjects (baselines tuned by 5-fold CV on OASIS-1), evaluate once on the
first visit of the 150 OASIS-2 subjects (CDR 0 vs CDR > 0, threshold 0.5). TabPFN[C5] vs LR / RF / XGBoost[C5]:
bootstrap CIs, paired bootstrap deltas (Holm), calibration, covariate shift, and the pre-specified
OASIS-1/OASIS-2 overlap sensitivity analysis."""
import pandas as pd
from sklearn.pipeline import Pipeline

import config
import external_tools as et
import tabpfn_retry  # noqa: F401
from common import PhaseRun, load_cohort
from models import build, preprocessor

C5 = config.CLINICAL_FULL


def tabpfn_clin():
    from tabpfn import TabPFNClassifier
    from tabpfn.constants import ModelVersion
    return Pipeline([("prep", preprocessor((), C5)),
                     ("clf", TabPFNClassifier.create_default_for_version(ModelVersion.V2, device="cpu", random_state=42))])


with PhaseRun("part42_external_clinical", __file__,
              inputs=[config.COHORT_FILE, config.CLINICAL_FILE, et.OASIS2_FILE], params={"features": C5}) as run:
    tr, ext = load_cohort(), et.load_oasis2()
    y_tr, y = tr[config.TARGET_COL].to_numpy(), ext[config.TARGET_COL].to_numpy()
    print(f"OASIS-1 train n={len(tr)} (CDR>0 {y_tr.sum()}), OASIS-2 test n={len(ext)} (CDR>0 {y.sum()})", flush=True)

    models = {"TabPFN_C5": (tabpfn_clin(), {})}
    for name in ["LR", "RF", "XGBoost"]:
        models[f"{name}_C5"] = build(name, tab_cols=C5)
    probs, params = {}, []
    for name, (pipe, grid) in models.items():
        fitted, bp = et.fit_tuned(pipe, grid, tr[C5], y_tr)
        probs[name] = fitted.predict_proba(ext[C5])[:, 1]
        params.append({"model": name, **bp})
        print(f"  {name} fitted", flush=True)
    pred = ext[["subject_id", "CDR", config.TARGET_COL, "sex_binary", "Age"]].assign(**{f"p_{k}": v for k, v in probs.items()})
    run.save_csv(pred, "external_predictions.csv"); run.save_csv(pd.DataFrame(params), "best_params.csv")

    res = et.ci_table(y, probs, "all")
    flags = et.overlap_flags(ext, pd.read_csv(config.CLINICAL_FILE))
    keep = (flags.n_candidates == 0).to_numpy()
    res_s = et.ci_table(y[keep], {k: v[keep] for k, v in probs.items()}, "excluding possible overlap")
    run.save_csv(pd.concat([res, res_s]), "external_metrics.csv"); run.save_csv(flags, "overlap_flags.csv")
    comp = et.paired_bootstrap(y, probs, "TabPFN_C5"); run.save_csv(comp, "tabpfn_vs_baselines_external.csv")
    shift = et.covariate_shift(tr, ext, C5); run.save_csv(shift, "covariate_shift.csv")

    cols = ["model", "subset", "n", "roc_auc", "roc_auc_lo", "roc_auc_hi", "mcc", "balanced_accuracy", "brier",
            "cal_slope", "citl"]
    print(pd.concat([res, res_s])[cols].round(3).to_string(index=False))
    print(f"possible overlap flagged: {int((~keep).sum())} of {len(keep)}")
    print(comp[["comparator", "metric", "delta", "ci95_low", "ci95_high", "p_boot", "p_holm"]].round(4).to_string(index=False))
    print(shift.round(3).to_string(index=False))
