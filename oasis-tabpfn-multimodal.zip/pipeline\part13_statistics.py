"""Part 13 - Statistical significance for the pre-declared comparison family.

All models share the frozen 25 outer folds, so comparisons are paired by (seed, fold).
For each comparison x metric: mean difference, 95% bootstrap CI, Wilcoxon signed-rank,
rank-biserial effect size, Nadeau-Bengio corrected resampled t-test (accounts for the
overlap of training sets in repeated CV). Holm-Bonferroni across the whole primary family.
"""
import numpy as np
import pandas as pd
from scipy import stats

import config
from common import PhaseRun

OUT = config.OUTPUT_DIR
SOURCES = {
    "Clinical_C4_LR": (OUT / "part04_clinical/fold_metrics.csv", "C4_clinical_no_MMSE", "LR"),
    "Clinical_C5_LR": (OUT / "part04_clinical/fold_metrics.csv", "C5_clinical_full", "LR"),
    "Clinical_C5_XGB": (OUT / "part04_clinical/fold_metrics.csv", "C5_clinical_full", "XGBoost"),
    "MRI_PCA_LR": (OUT / "part06_pca/nested_fold_metrics.csv", "MRI_PCA_nested", "LR"),
    "Fusion_PCA_LR": (OUT / "part07_fusion/fold_metrics.csv", "Fusion_PCA_nested", "LR"),
    "Fusion_PCA_XGB": (OUT / "part07_fusion/fold_metrics.csv", "Fusion_PCA_nested", "XGBoost"),
    "Fusion_raw_LR": (OUT / "part07_fusion/fold_metrics.csv", "Fusion_raw_520", "LR"),
    "MRI+C4_noMMSE_LR": (OUT / "part07_fusion/fold_metrics.csv", "Abl_MRI+C4_noMMSE", "LR"),
    "Transportable_LR": (OUT / "part07_fusion/fold_metrics.csv", "Transportable_PCA_nested", "LR"),
    "GCN_trans": (OUT / "part09_gnn/fold_metrics.csv", "GNN_transductive", "GCN"),
    "GAT_trans": (OUT / "part09_gnn/fold_metrics.csv", "GNN_transductive", "GAT"),
    "GCN_ind": (OUT / "part10_inductive/fold_metrics.csv", "GNN_inductive", "GCN"),
    "GAT_ind": (OUT / "part10_inductive/fold_metrics.csv", "GNN_inductive", "GAT"),
}
# pre-declared primary family: (A, B, research question)
PRIMARY = [
    ("Fusion_PCA_LR", "Clinical_C5_LR", "RQ1 fusion vs clinical"),
    ("Fusion_PCA_LR", "MRI_PCA_LR", "RQ1 fusion vs MRI"),
    ("MRI+C4_noMMSE_LR", "Clinical_C4_LR", "RQ1 MRI value without MMSE"),
    ("Fusion_PCA_LR", "Fusion_raw_LR", "RQ1 PCA vs raw fusion"),
    ("GCN_trans", "Fusion_PCA_LR", "RQ2 GCN vs fusion"),
    ("GAT_trans", "Fusion_PCA_LR", "RQ2 GAT vs fusion"),
    ("GAT_trans", "GCN_trans", "RQ2 GAT vs GCN"),
    ("GCN_ind", "GCN_trans", "RQ3 inductive vs transductive GCN"),
    ("GAT_ind", "GAT_trans", "RQ3 inductive vs transductive GAT"),
    ("Transportable_LR", "Fusion_PCA_LR", "Ext transportable vs full fusion"),
]
SECONDARY = [
    ("Fusion_PCA_XGB", "Fusion_PCA_LR", "learner: XGB vs LR fusion"),
    ("Fusion_PCA_XGB", "Clinical_C5_XGB", "fusion vs clinical (XGB)"),
    ("GCN_ind", "Fusion_PCA_LR", "inductive GCN vs fusion"),
    ("GAT_ind", "Fusion_PCA_LR", "inductive GAT vs fusion"),
]
METRICS = ["balanced_accuracy", "macro_f1", "mcc", "roc_auc"]
N_TRAIN, N_TEST = 133, 33


def holm(p):
    p = np.asarray(p, float)
    order = np.argsort(p)
    out = np.empty_like(p)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (len(p) - rank) * p[i])
        out[i] = min(running, 1.0)
    return out


def rank_biserial(d):
    d = d[d != 0]
    if len(d) == 0:
        return 0.0
    r = stats.rankdata(np.abs(d))
    return float((r[d > 0].sum() - r[d < 0].sum()) / r.sum())


def nadeau_bengio(d):
    J = len(d)
    var = np.var(d, ddof=1)
    if var == 0:
        return np.nan
    t = d.mean() / np.sqrt((1 / J + N_TEST / N_TRAIN) * var)
    return float(2 * stats.t.sf(abs(t), J - 1))


def compare(data, pairs, family):
    rows = []
    for a, b, rq in pairs:
        A = data[a].set_index(["seed", "fold"]).sort_index()
        B = data[b].set_index(["seed", "fold"]).sort_index()
        assert (A.index == B.index).all() and len(A) == 25
        for m in METRICS:
            d = (A[m] - B[m]).to_numpy()
            boot = np.random.default_rng(0).choice(d, (10000, len(d))).mean(1)
            w = stats.wilcoxon(d, zero_method="wilcox") if np.any(d != 0) else None
            rows.append({"family": family, "question": rq, "A": a, "B": b, "metric": m,
                         "mean_A": A[m].mean(), "mean_B": B[m].mean(), "mean_diff": d.mean(),
                         "ci95_low": np.percentile(boot, 2.5), "ci95_high": np.percentile(boot, 97.5),
                         "wins_A": int((d > 0).sum()), "ties": int((d == 0).sum()), "wins_B": int((d < 0).sum()),
                         "wilcoxon_stat": w.statistic if w else np.nan,
                         "p_wilcoxon": w.pvalue if w else 1.0,
                         "rank_biserial": rank_biserial(d), "p_nadeau_bengio": nadeau_bengio(d)})
    out = pd.DataFrame(rows)
    out["p_holm"] = holm(out.p_wilcoxon)
    out["p_nb_holm"] = holm(out.p_nadeau_bengio.fillna(1.0))
    out["significant_holm_0.05"] = out.p_holm < 0.05
    return out


with PhaseRun("part13_stats", __file__, inputs=sorted({str(v[0]) for v in SOURCES.values()}),
              params={"primary": PRIMARY, "secondary": SECONDARY, "metrics": METRICS,
                      "holm_scope": "within family (comparisons x metrics)",
                      "nadeau_bengio_ratio": f"{N_TEST}/{N_TRAIN}"}) as run:
    data = {}
    for name, (f, g, m) in SOURCES.items():
        t = pd.read_csv(f)
        data[name] = t[(t.group == g) & (t.model == m)]
        assert len(data[name]) == 25, f"{name}: {len(data[name])} folds"
    prim = compare(data, PRIMARY, "primary")
    sec = compare(data, SECONDARY, "secondary")
    res = pd.concat([prim, sec], ignore_index=True)
    run.save_csv(res, "paired_statistics.csv")
    show = ["question", "metric", "mean_A", "mean_B", "mean_diff", "ci95_low", "ci95_high",
            "p_wilcoxon", "p_holm", "p_nb_holm", "rank_biserial", "significant_holm_0.05"]
    pd.set_option("display.width", 250)
    print("PRIMARY family (Holm across", len(prim), "tests):\n", prim[show].round(4).to_string(index=False))
    print("\nSECONDARY family:\n", sec[show].round(4).to_string(index=False))
