"""Part 54b - Amendment 12 (follow-up): do the re-run predictions of the frozen models change any reported external
metric? Re-predicts 3 times and recomputes AUC, MCC, BA, Brier and calibration slope for every model."""
import json

import joblib
import numpy as np
import pandas as pd

import config
import external_tools as et
import tabpfn_retry  # noqa: F401
from common import PhaseRun, binary_metrics

FROZEN = config.OUTPUT_DIR / "part47_frozen_harmonised"
P48 = config.OUTPUT_DIR / "part48_external_oasis2"

with PhaseRun("part54b_metric_stability", __file__, inputs=[FROZEN / "FROZEN_MODELS.json", P48 / "predictions_label_cdr_overlap-screened.csv"]) as run:
    meta = json.loads((FROZEN / "FROZEN_MODELS.json").read_text(encoding="utf-8"))["models"]
    saved = pd.read_csv(P48 / "predictions_label_cdr_overlap-screened.csv")
    data = pd.read_csv(P48 / "external_cohort_with_features.csv").set_index("subject_id").loc[saved.subject_id].reset_index()
    y = saved.label_cdr.astype(int).to_numpy()
    rows = []
    for name, m in meta.items():
        col = f"p_{name}"
        if col not in saved.columns:
            continue
        mdl = joblib.load(FROZEN / m["artifact"])
        runs = [("saved (Part 48)", saved[col].to_numpy())] + [
            (f"re-run {i + 1}", mdl.predict_proba(data[m["features_in_order"]])[:, 1]) for i in range(3)]
        for lab, p in runs:
            b = binary_metrics(y, (p >= 0.5).astype(int), p)
            rows.append({"model": name, "run": lab, "auc": b["roc_auc"], "mcc": b["mcc"], "ba": b["balanced_accuracy"],
                         "brier": b["brier"], "cal_slope": et.calibration(y, p)[0], "n_pred_pos": int((p >= 0.5).sum())})
    t = pd.DataFrame(rows)
    run.save_csv(t, "metric_stability.csv")
    span = t.groupby("model")[["auc", "mcc", "ba", "brier", "cal_slope", "n_pred_pos"]].agg(lambda s: s.max() - s.min())
    run.save_csv(span.reset_index(), "metric_span.csv")
    print(t.round(4).to_string(index=False)); print("max - min over runs:"); print(span.round(4).to_string())
