# Implementation Plan — FROZEN v1.0 (2026-10-24)
# Multimodal Dementia Classification: OASIS-1 development, OASIS-3 / ADNI external validation
# Target: IEEE JBHI Special Issue "AI-Driven Multimodal Intelligence for Sustainable Healthcare Systems"

Freeze record: the SHA-256 of this file is stored in `outputs/phase01_protocol/run_manifest.json`.
Any later change must be logged in the "Amendments" section at the bottom (date, what, why)
and Phase 01 re-run. Results produced before an amendment stay valid for the version they cite.

---

## A. JBHI requirements this plan is designed to satisfy
Source: embs.org/jbhi "Prepare and submit your manuscript" (checked 2026-10-24).

| Requirement | Consequence for the plan |
|---|---|
| IEEE double-column template, figures/tables embedded, PDF | Part 18 uses the IEEE LaTeX template |
| ≤ 14 pages **including supplementary**; mandatory charges > 8 pages ($250/p for 9–10, $350/p from 11) | Main paper target **8 pages** (max 10); 6 main tables, 6 main figures; the rest in supplement within the 14-page cap |
| Abstract ≤ 250 words: objective, methods, results, conclusion, one sentence of significance; no abbreviations/equations/references | Drafted from Part 16 numbers only |
| Public datasets: give source, citation/URL | OASIS-1, OASIS-3, ADNI citations + required acknowledgement texts |
| Human-subjects: IRB statement | Statement that original studies had IRB approval and data were used under the OASIS/ADNI Data Use Agreements |
| Cover letter: innovation, significance for JBHI, originality | Part 18; tie to special-issue topics (fusion, benchmark/validation protocol, XAI, sustainability) |
| Single-blind review, ≥ 3 reviewers, 4 suggested independent reviewers | Part 18 |
| ORCID for all authors; signed author consent form; institutional e-mails | Part 18 checklist |
| Plagiarism screening | All text written fresh; prior own work disclosed |
| Special-issue deadline 31 Oct 2026; first reviews 30 Nov; revision due 31 Dec 2026 | See timeline (Section C) |

Reporting guideline (not mandated by JBHI, adopted for rigour): **TRIPOD+AI** checklist in the supplement.

---

## B. Global rules (apply to every part)
- CDR is never a predictor (`config.FORBIDDEN_PREDICTORS`, enforced by `assert_no_forbidden`).
- Every OASIS-1 model uses the frozen outer folds from Part 03 (5 folds × 5 seeds = 25 evaluations).
- Everything learned from data (imputation, scaling, PCA, K, hyperparameters, calibration,
  thresholds) is fitted inside the outer training set only; tuning uses the frozen 3-fold inner folds.
- Tuning criterion: inner-CV ROC-AUC. Decision threshold 0.5 unless tuned inside training folds (Part 12).
- Out-of-fold probabilities are saved for every model.
- Metrics: primary = balanced accuracy, macro-F1, MCC; secondary = accuracy, sensitivity,
  specificity, precision, ROC-AUC, PR-AUC; reliability = Brier, ECE, log-loss.
- **External data are never used for training, tuning, feature selection or model choice.**
  Models are locked (Part 17a) before any external data are opened.
- Each part writes `outputs/<part>/` with results, `run_log.txt`, `run_manifest.json` (hashes, params, versions).

---

## C. Timeline (two tracks)

| Track | Window | Parts | Deliverable |
|---|---|---|---|
| **A — submission** | 24 → 31 Oct 2026 | 04–16, 17a–17b, 18 | Submitted paper on OASIS-1 with locked models and a pre-registered external-validation protocol |
| **B — revision** | Nov → 31 Dec 2026 | 05b, 17c–17f | External validation on OASIS-3 (primary) and ADNI (secondary) added in the revision |

Track B is gated by: (1) OASIS-3 / ADNI data-access approval, (2) the MRI feature extractor being
reproducible on raw scans (Part 05b). **Action for the authors today:** apply for OASIS-3
(oasis-brains.org) and ADNI (ida.loni.usc.edu) access.

---

## D. Status overview

| Part | Name | Track | Status |
|---|---|---|---|
| 01 | Freeze protocol + this plan | A | ✅ |
| 02 | Dataset audit & cohort | A | ✅ |
| 03 | Frozen subject-level folds | A | ✅ |
| 04 | Clinical baselines + MMSE ablation | A | running |
| 05 | MRI embedding audit + MRI-only baselines | A | ☐ |
| 05b | Reproducible MRI feature extractor (raw T1 → ResNet18 512-D) | B | ☐ needs raw MRI + original slice protocol |
| 06 | MRI PCA dimension study (nested) | A | ☐ |
| 07 | Multimodal fusion + fusion ablation + transportable model | A | ☐ |
| 08 | Population graph construction + K sensitivity | A | ☐ |
| 09 | GCN / GAT (transductive) | A | ☐ |
| 10 | Strict inductive graph validation | A | ☐ |
| 11 | Missing-modality robustness | A | ☐ |
| 12 | Calibration | A | ☐ |
| 13 | Statistical significance | A | ☐ |
| 14 | Explainability + error analysis | A | ☐ |
| 15 | Efficiency / sustainability | A | ☐ |
| 16 | Final model decision, tables, figures, repro package | A | ☐ |
| 17a | Lock final models (train on all OASIS-1, export) | A | ☐ |
| 17b | External-validation protocol + harmonisation code (pre-registered) | A | ☐ |
| 17c–f | OASIS-3 / ADNI cohort build, feature extraction, evaluation, analysis | B | ☐ gated by data access |
| 18 | Manuscript + JBHI compliance | A | ☐ |

---

## E. Parts

### Part 01–03 ✅
See `outputs/phase01_protocol`, `phase02_cohort`, `phase03_folds`. Cohort N = 166 (85 CDR 0 / 81 CDR > 0),
rebuilt from raw files and identical to the legacy cohort; 25 outer + inner folds verified.

### Part 04 — Clinical baselines + MMSE ablation
`part04_clinical_baselines.py` → `outputs/part04_clinical/`
- C1 demographics · C2 MRI biomarkers (eTIV, nWBV, ASF) · C3 MMSE · C4 clinical without MMSE · C5 full clinical.
- LR, SVM-RBF, RF, XGBoost; nested tuning.
- Outputs: fold metrics, OOF predictions, best params, summary, MMSE ablation (paired Δ + bootstrap CI), figure.

### Part 05 — MRI embedding audit + MRI-only baselines
`part05_mri_embedding.py` → `outputs/part05_mri/`
- Duplicates/near-duplicates; embedding statistics; correlation of embedding PCs with nWBV, eTIV, Age.
- **Label-permutation test** (e.g. 200 permutations): performance on shuffled labels must be at chance.
- MRI-only LR, SVM-RBF, RF, XGBoost on 512-D, nested tuning.
- `mri_provenance_checklist.md`: 2D/3D, slice selection, normalisation, frozen vs fine-tuned ResNet18,
  subject-level split if fine-tuned. Marked **UNVERIFIED** until the original extraction code is supplied.

### Part 05b — Reproducible MRI feature extractor (Track B)
`part05b_mri_extractor.py` → `outputs/part05b_extractor/`
- Input: OASIS-1 processed T1 (atlas-registered, skull-stripped). Frozen ImageNet ResNet18 (no fine-tuning,
  so no label leakage is possible), documented slice selection and intensity normalisation, 512-D output.
- Gate: re-extracted OASIS-1 embeddings reproduce Part 05 MRI-only performance within the 25-fold SD;
  otherwise Parts 05–16 are re-run with the reproducible embeddings and the change logged as an amendment.
- The same script is applied unchanged to OASIS-3 / ADNI (after equivalent registration + skull stripping).

### Part 06 — MRI PCA dimension study
`part06_mri_pca.py` → `outputs/part06_pca/`
- PCA fitted inside each outer training fold.
- (a) fixed k ∈ {8,16,24,32,64,96,128,512} — descriptive sensitivity;
  (b) **nested**: k chosen by inner CV per outer fold — the reported estimate.
- Fold-wise explained variance EVR_k (mean ± SD); performance vs k; frequency of selected k; figure.

### Part 07 — Multimodal fusion + fusion ablation + transportable model
`part07_fusion.py` → `outputs/part07_fusion/`
- Raw early fusion (C5 + 512 = 520-D); PCA fusion (C5 + PCA-k, k nested). LR, SVM-RBF, RF, XGBoost.
- Ablation: MRI · MRI+Age · MRI+MMSE · MRI+C4 (fusion **without MMSE**) · MRI+C5.
- **Transportable feature set T** = Age, Sex, Education, MMSE + MRI embedding (variables measured the same way
  in OASIS-3 and ADNI; SES, eTIV, nWBV, ASF excluded because they are absent or derived differently).
  Its OASIS-1 internal performance is the reference for external validation.
- ΔMetric tables (Fusion − Clinical, Fusion − MRI, T − full fusion), per fold. Answers **RQ1**.

### Part 08 — Population graph construction + K sensitivity
`part08_graph_construction.py` → `outputs/part08_graph/`
- G1 clinical · G2 MRI (PCA) · G3 clinical + raw MRI · G4 clinical + PCA-MRI; Euclidean vs cosine;
  K ∈ {3,5,7,9,11,15}; built from training-fitted transforms only.
- Edge homophily, degree statistics, kNN label-propagation accuracy; figure homophily vs K.

### Part 09 — GCN / GAT (transductive)
`part09_gnn_transductive.py` → `outputs/part09_gnn/`
- 2-layer GCN and GAT in plain PyTorch (dense adjacency, N = 166).
- Inner-CV selection of graph type, K, hidden size, dropout, weight decay, epochs.
- Key comparison: PCA-fusion + best classical model vs PCA-fusion + GCN/GAT on identical folds.

### Part 10 — Strict inductive graph validation
`part10_gnn_inductive.py` → `outputs/part10_inductive/`
- Training-only graph; each test node linked only to K training nodes; no test–test edges.
- Transductive vs inductive table with paired differences. Answers **RQ2–RQ3**.

### Part 11 — Missing-modality robustness
`part11_missing_modality.py` → `outputs/part11_missing/`
- Test-time scenarios: full; MRI missing; MMSE missing; partial clinical missing; missing rate 0–50 %.
- Standard vs modality-dropout training (p ∈ {0.1, 0.2, 0.3, 0.5}); robustness curves.

### Part 12 — Calibration
`part12_calibration.py` → `outputs/part12_calibration/`
- Brier, ECE, log-loss; reliability diagrams; uncalibrated vs Platt vs isotonic (fitted on inner folds only).

### Part 13 — Statistical significance
`part13_statistics.py` → `outputs/part13_stats/`
- Pre-declared comparison family; paired Wilcoxon on 25 folds; Holm–Bonferroni; rank-biserial;
  mean Δ with 95 % bootstrap CI; Nadeau–Bengio corrected resampled t-test as sensitivity.

### Part 14 — Explainability + error analysis
`part14_explainability.py` → `outputs/part14_xai/`
- SHAP (global + dependence) for the final model; patient-level TP/TN/FP/FN explanations;
  graph neighbourhood/homophily analysis; per-subject error rate over 25 runs; profile of repeat errors.

### Part 15 — Efficiency / sustainability
`part15_efficiency.py` → `outputs/part15_efficiency/`
- Feature dimension, parameters, train time, inference time per subject, peak memory; 512 → k reduction vs performance.

### Part 16 — Final model decision, tables, figures, reproducibility package
`part16_final_tables.py` → `outputs/part16_final/`
- Decision gate (Scenario A graph / B attention-graph / C classical fusion) on balanced accuracy, macro-F1,
  MCC, AUC, calibration, stability.
- Main paper: Table I cohort · II unimodal baselines · III fusion + ablation · IV graph (trans/inductive) ·
  V calibration + statistics · VI efficiency. Figures 1–6 (framework, cohort/protocol, performance,
  PCA/K ablation, calibration+ROC, SHAP). Remaining tables/figures → supplement.
- `requirements.txt`, README, seeds, folds, hyperparameters.

### Part 17 — External validation
**17a Lock models (Track A)** — `part17a_lock_models.py` → `outputs/part17a_locked/`
- Train the final model(s) — best full model and the transportable model T — on all 166 OASIS-1 subjects,
  hyperparameters by CV on the full cohort. Export pipeline (`joblib`), feature list, preprocessing params,
  SHA-256 of each artifact. These files are never modified afterwards.

**17b External-validation protocol + harmonisation code (Track A)** — `part17b_external_protocol.py` → `outputs/part17b_protocol/`
- Pre-registered protocol (`external_validation_protocol.md`), frozen before data access:
  - Inclusion: baseline MRI session, age ≥ 60, CDR within ± 180 days of the MRI, T1 available, MMSE available.
  - Target: CDR = 0 vs CDR > 0 (identical definition).
  - Harmonisation: Education years → OASIS-1 5-level code (< 12 → 1, 12 → 2, 13–15 → 3, 16 → 4, > 16 → 5);
    Sex → binary; MMSE as is.
  - OASIS-3: exclude subjects who also appear in OASIS-1 (overlap check by age/sex/session date where IDs differ).
  - Analyses: discrimination (AUC, balanced accuracy, macro-F1, MCC), calibration (Brier, ECE,
    calibration slope/intercept), with and without recalibration-in-the-large; subgroup by sex and age band.
- `external_harmonise.py`: maps OASIS-3 / ADNI tables to the frozen feature schema; tested on a synthetic table.
- `external_evaluate.py`: loads locked artifacts, verifies their hashes, evaluates, writes results.

**17c–17f (Track B)** — cohort build (17c), MRI feature extraction with Part 05b (17d), locked-model evaluation (17e),
analysis of transportability / domain shift (17f). OASIS-3 = primary external cohort; ADNI = secondary.

### Part 18 — Manuscript + JBHI compliance
IEEE template; structure per roadmap Phase 21; Section A checklist; TRIPOD+AI checklist; cover letter;
4 suggested reviewers; data-availability and ethics statements; dataset acknowledgements.

---

## F. Amendments
| Date | Version | Change | Reason |
|---|---|---|---|
| 2026-10-24 | 1.0 | Initial freeze | — |
