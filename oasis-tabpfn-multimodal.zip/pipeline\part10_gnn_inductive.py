"""Part 10 - Strict inductive graph validation.

Same per-fold configurations as Part 09 (selected by inner CV), only the evaluation changes:
the graph is built from training subjects; each test subject is linked only to its K nearest
training subjects; no test-test edges. Transductive vs inductive is compared fold by fold."""
import numpy as np
import pandas as pd
import torch

import config
from common import (PhaseRun, binary_metrics, check_oof_integrity, embedding_cols,
                    iter_outer_folds, load_cohort, summarize)
from gnn import evaluate_split
from graphs import inductive_adjacency, node_features

PART09_SEL = config.OUTPUT_DIR / "part09_gnn" / "selected_configs.csv"
PART09_FOLDS = config.OUTPUT_DIR / "part09_gnn" / "fold_metrics.csv"

with PhaseRun("part10_inductive", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, PART09_SEL, PART09_FOLDS],
              params={"mode": "inductive", "configs": "per-fold selections from Part 09"}) as run:
    torch.set_num_threads(4)
    df = load_cohort()
    emb = embedding_cols(df)
    y = df[config.TARGET_COL].to_numpy()
    sel = pd.read_csv(PART09_SEL)
    rows, preds, leak_checks = [], [], []
    for seed, fold, tr, te in iter_outer_folds(df):
        for arch in ["GCN", "GAT"]:
            cfg = sel[(sel.arch == arch) & (sel.seed == seed) & (sel.fold == fold)].iloc[0].to_dict()
            cfg["k"], cfg["hidden"], cfg["epochs"] = int(cfg["k"]), int(cfg["hidden"]), int(cfg["epochs"])
            prob = evaluate_split(arch, df, emb, y, tr, te, cfg, seed * 10 + fold, mode="inductive")
            pred = (prob >= config.DECISION_THRESHOLD).astype(int)
            m = binary_metrics(y[te], pred, prob)
            m.update({"group": "GNN_inductive", "model": arch, "seed": seed, "fold": fold,
                      "graph": cfg["graph"], "k": cfg["k"]})
            rows.append(m)
            preds += [{"group": "GNN_inductive", "model": arch, "seed": seed, "fold": fold,
                       "subject_id": df.subject_id.iloc[i], "y_true": int(y[i]), "y_prob": float(p),
                       "y_pred": int(q)} for i, p, q in zip(te, prob, pred)]
            # proof: no test-test edges, each test node has exactly K training neighbours
            Xtr, Xte = node_features(df, emb, tr, te, cfg["graph"], seed=seed)
            A = inductive_adjacency(Xtr, Xte, cfg["k"], cfg["distance"])
            ntr = len(tr)
            leak_checks.append({"arch": arch, "seed": seed, "fold": fold,
                                "test_test_edges": int(A[ntr:, ntr:].sum()),
                                "min_test_degree": int(A[ntr:, :ntr].sum(1).min()),
                                "max_test_degree": int(A[ntr:, :ntr].sum(1).max())})
        print(f"  seed {seed} fold {fold} done")

    folds = pd.DataFrame(rows)
    pr = pd.DataFrame(preds)
    lc = pd.DataFrame(leak_checks)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(pr, "oof_predictions.csv")
    run.save_csv(lc, "inductive_graph_checks.csv")

    trans = pd.read_csv(PART09_FOLDS)
    both = pd.concat([trans, folds])
    summary = summarize(both)
    run.save_csv(summary, "transductive_vs_inductive_summary.csv")
    print("\nTransductive vs inductive (mean ± SD, 25 folds):\n",
          summary[["group", "model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc"]].to_string(index=False))

    drows = []
    for arch in ["GCN", "GAT"]:
        I = folds[folds.model == arch].set_index(["seed", "fold"])
        T = trans[trans.model == arch].set_index(["seed", "fold"])
        for m in ["balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]:
            d = (I[m] - T[m]).to_numpy()
            boot = np.random.default_rng(0).choice(d, (5000, len(d))).mean(1)
            drows.append({"arch": arch, "metric": m, "mean_transductive": T[m].mean(),
                          "mean_inductive": I[m].mean(), "delta_ind_minus_trans": d.mean(),
                          "ci95_low": np.percentile(boot, 2.5), "ci95_high": np.percentile(boot, 97.5)})
    deltas = pd.DataFrame(drows)
    run.save_csv(deltas, "inductive_minus_transductive.csv")
    print("\nInductive - transductive:\n", deltas.round(4).to_string(index=False))

    checks = pd.DataFrame([
        ("no test-test edges in any inductive graph", bool((lc.test_test_edges == 0).all())),
        ("every test node linked to >= K training nodes", bool((lc.min_test_degree >= 1).all())),
        ("25 folds per architecture", bool((folds.groupby("model").size() == 25).all())),
        ("each subject predicted once per seed", check_oof_integrity(pr, df)),
    ], columns=["check", "passed"])
    print("\n", checks.to_string(index=False))
    run.save_csv(checks, "integrity_checks.csv")
    assert checks.passed.all()
