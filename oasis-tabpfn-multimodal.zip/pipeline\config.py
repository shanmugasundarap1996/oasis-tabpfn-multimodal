"""Frozen study configuration. Every phase script imports from here.

Changing anything in this file after Phase 01 invalidates the frozen protocol;
re-run Phase 01 and record why.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / "data"
PIPELINE_DIR = BASE_DIR / "pipeline"
OUTPUT_DIR = PIPELINE_DIR / "outputs"

# Raw source files (never modified)
CLINICAL_FILE = RAW_DIR / "oasis_cross-sectional.csv"
EMBED_FILE = RAW_DIR / "mri_embeddings.csv"

# Frozen cohort produced by Phase 02 (input for every later phase)
COHORT_FILE = OUTPUT_DIR / "phase02_cohort" / "cohort_primary_age60.csv"
FOLDS_FILE = OUTPUT_DIR / "phase03_folds" / "outer_folds_5x5.csv"
INNER_FOLDS_FILE = OUTPUT_DIR / "phase03_folds" / "inner_folds_3.csv"

# ---- Task definition ----
TASK = ("Cross-sectional classification of cognitively normal (CDR = 0) versus "
        "dementia-spectrum (CDR > 0) subjects using clinical/cognitive and "
        "structural MRI information (OASIS-1).")
MIN_AGE = 60
TARGET_COL = "target_binary"          # 0: CDR == 0, 1: CDR > 0
TARGET_SOURCE = "CDR"

# CDR defines the target -> must never be a predictor.
FORBIDDEN_PREDICTORS = ["CDR", "label", TARGET_COL, "target_3class",
                        "ID", "subject_id", "Delay", "Hand"]

# ---- Feature sets (Phase 04 clinical ablation) ----
DEMOGRAPHICS = ["Age", "sex_binary", "Educ", "SES"]           # C1
MRI_BIOMARKERS = ["eTIV", "nWBV", "ASF"]                      # C2
COGNITIVE = ["MMSE"]                                          # C3
CLINICAL_NO_MMSE = DEMOGRAPHICS + MRI_BIOMARKERS              # C4
CLINICAL_FULL = CLINICAL_NO_MMSE + COGNITIVE                  # C5
# Variables measured the same way in OASIS-1, OASIS-3 and ADNI (external validation, Part 17)
TRANSPORTABLE_CLINICAL = ["Age", "sex_binary", "Educ", "MMSE"]
EMBED_PREFIX = "emb_"
N_EMBED = 512

# ---- Validation protocol ----
OUTER_SEEDS = [42, 2026, 3407, 7319, 9871]
N_OUTER_FOLDS = 5
N_INNER_FOLDS = 3
TUNING_SCORING = "roc_auc"           # inner-CV criterion for all hyperparameter tuning
DECISION_THRESHOLD = 0.5
PCA_DIMS = [8, 16, 24, 32, 64, 96, 128]
KNN_K = [3, 5, 7, 9, 11, 15]

PRIMARY_METRICS = ["balanced_accuracy", "macro_f1", "mcc"]
SECONDARY_METRICS = ["accuracy", "sensitivity", "specificity", "precision",
                     "roc_auc", "pr_auc"]
RELIABILITY_METRICS = ["brier", "ece", "logloss"]
ALL_METRICS = PRIMARY_METRICS + SECONDARY_METRICS + RELIABILITY_METRICS
