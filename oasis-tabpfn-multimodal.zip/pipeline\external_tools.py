"""Shared helpers for the OASIS-2 external validation (Amendment 7, Parts 42-44)."""
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, StratifiedKFold

import config
from common import binary_metrics
from compare_tools import _holm
from external_validation import educ_years_to_oasis1

OASIS2_FILE = config.RAW_DIR / "external_oasis2" / "oasis_longitudinal_demographics.xlsx"
METRICS = ["roc_auc", "mcc", "balanced_accuracy", "brier", "sensitivity", "specificity", "ece"]
DELTA_METRICS = ["roc_auc", "mcc", "balanced_accuracy", "brier"]
N_BOOT = 2000


def load_oasis2():
    """First visit of every OASIS-2 subject, harmonised to the frozen OASIS-1 schema."""
    d = pd.read_excel(OASIS2_FILE)
    d = d[d.Visit == 1].copy()
    out = pd.DataFrame({
        "subject_id": d["Subject ID"].astype(str), "mri_id": d["MRI ID"].astype(str),
        "Age": d.Age.astype(float), "sex_binary": (d["M/F"] == "M").astype(int),
        "Educ": educ_years_to_oasis1(d.EDUC), "educ_years": d.EDUC, "SES": d.SES, "MMSE": d.MMSE,
        "eTIV": d.eTIV, "nWBV": d.nWBV, "ASF": d.ASF, "CDR": d.CDR})
    out = out[out.Age >= config.MIN_AGE].dropna(subset=["CDR"]).reset_index(drop=True)
    out[config.TARGET_COL] = (out.CDR > 0).astype(int)
    return out


def overlap_flags(ext, oasis1_all):
    """Possible OASIS-1 participants among OASIS-2 subjects (pre-specified rule, Amendment 7)."""
    o1 = oasis1_all.assign(sex_binary=(oasis1_all["M/F"] == "M").astype(int))
    flags = []
    for _, r in ext.iterrows():
        c = o1[(o1.sex_binary == r.sex_binary) & (o1.Educ == r.Educ)
               & ((r.Age - o1.Age).between(-2, 6)) & ((o1.eTIV - r.eTIV).abs() <= 0.02 * r.eTIV)]
        if pd.notna(r.SES):
            c = c[c.SES.isna() | (c.SES == r.SES)]
        flags.append({"subject_id": r.subject_id, "n_candidates": len(c),
                      "candidates": ";".join(c.ID.astype(str))})
    return pd.DataFrame(flags)


def fit_tuned(pipe, grid, X, y):
    if not grid or all(len(v) == 1 for v in grid.values()):
        return pipe.set_params(**{k: v[0] for k, v in (grid or {}).items()}).fit(X, y), {}
    gs = GridSearchCV(pipe, grid, scoring=config.TUNING_SCORING, refit=True, n_jobs=1,
                      cv=StratifiedKFold(5, shuffle=True, random_state=42)).fit(X, y)
    return gs.best_estimator_, {k: str(v) for k, v in gs.best_params_.items()}


def _logit(p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def calibration(y, p):
    slope = LogisticRegression(C=1e6, max_iter=1000).fit(_logit(p).reshape(-1, 1), y).coef_[0, 0]
    return float(slope), float(np.mean(y) - np.mean(p))


def metrics_ci(y, prob, seed=0):
    """Point estimates + 95 % subject-bootstrap CIs at threshold 0.5."""
    pred = (prob >= config.DECISION_THRESHOLD).astype(int)
    point = binary_metrics(y, pred, prob)
    point["cal_slope"], point["citl"] = calibration(y, prob)
    rng, boots = np.random.default_rng(seed), []
    for _ in range(N_BOOT):
        i = rng.integers(0, len(y), len(y))
        if len(np.unique(y[i])) < 2:
            continue
        b = binary_metrics(y[i], pred[i], prob[i]); b["cal_slope"], b["citl"] = calibration(y[i], prob[i])
        boots.append(b)
    boots = pd.DataFrame(boots)
    return {m: (point[m], *np.nanpercentile(boots[m], [2.5, 97.5])) for m in METRICS + ["cal_slope", "citl"]}


def paired_bootstrap(y, probs, ref, seed=0):
    """Delta (ref - comparator) with 95 % CI and two-sided bootstrap p; Holm over all rows."""
    rng = np.random.default_rng(seed)
    idx = [i for i in (rng.integers(0, len(y), len(y)) for _ in range(N_BOOT)) if len(np.unique(y[i])) == 2]
    m = lambda i, p: binary_metrics(y[i], (p[i] >= 0.5).astype(int), p[i])
    rows = []
    for name, p in probs.items():
        if name == ref:
            continue
        full = np.arange(len(y))
        a, b = m(full, probs[ref]), m(full, p)
        ba = [(m(i, probs[ref]), m(i, p)) for i in idx]
        for k in DELTA_METRICS:
            d = np.array([x[k] - z[k] for x, z in ba])
            pv = min(1.0, 2 * min((d <= 0).mean(), (d >= 0).mean()))
            rows.append({"proposed": ref, "comparator": name, "metric": k, "proposed_value": a[k],
                         "comparator_value": b[k], "delta": a[k] - b[k], "ci95_low": np.percentile(d, 2.5),
                         "ci95_high": np.percentile(d, 97.5), "p_boot": max(pv, 1 / len(idx))})
    t = pd.DataFrame(rows)
    t["p_holm"] = _holm(t.p_boot)
    return t


def ci_table(y, probs, label=""):
    rows = []
    for name, p in probs.items():
        r = {"model": name, "n": len(y), "subset": label}
        for k, (v, lo, hi) in metrics_ci(y, p).items():
            r[k], r[f"{k}_lo"], r[f"{k}_hi"] = v, lo, hi
        rows.append(r)
    return pd.DataFrame(rows)


def covariate_shift(train, ext, cols):
    return pd.DataFrame([{"feature": c, "oasis1_mean": train[c].mean(), "oasis2_mean": ext[c].mean(),
                          "smd": (ext[c].mean() - train[c].mean()) / np.sqrt((train[c].var() + ext[c].var()) / 2)}
                         for c in cols])
