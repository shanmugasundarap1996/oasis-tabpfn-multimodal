"""Part 44b - post-hoc diagnostic (not pre-specified): for the OASIS-2 / OASIS-1 pairs checked in Part 44, is the
sub-0.99 raw-image correlation explained by an axis flip or permutation of otherwise identical data?
Every axis flip combination (8) is tried for every repeat pair; correlation is also computed inside a central box
(middle 60 % of each axis) to reduce the influence of face masking."""
from itertools import product

import nibabel as nib
import numpy as np
import pandas as pd

import config

TMP = config.BASE_DIR / "mri_harmonised" / "_tmp_part44"
O2 = config.BASE_DIR / "oasis2_raw"
OUT = config.OUTPUT_DIR / "part44_overlap_image_verification"


def vol(p):
    return np.asarray(nib.load(str(p)).dataobj).squeeze().astype(np.float32)


def central(v):
    s = [slice(int(0.2 * n), int(0.8 * n)) for n in v.shape]
    return v[tuple(s)]


def corr(a, b):
    return float(np.corrcoef(a.ravel(), b.ravel())[0, 1])


ver = pd.read_csv(OUT / "image_verification.csv")
o2dirs = {p.name.replace("_MR1", ""): p for p in O2.glob("OAS2_RAW_PART*/*_MR1")}
rows = []
for _, r in ver.iterrows():
    a_list = [vol(f) for f in sorted((o2dirs[r.oasis2] / "RAW").glob("mpr-*.nifti.img"))]
    b_list = [vol(f) for f in sorted((TMP / r.oasis1_candidate).glob("*mpr-*_anon.img"))]
    best = (-1, None)
    for (i, a), (j, b) in product(enumerate(a_list), enumerate(b_list)):
        for flips in product([False, True], repeat=3):
            bb = b
            for ax, f in enumerate(flips):
                if f:
                    bb = np.flip(bb, ax)
            c = corr(central(a), central(bb))
            if c > best[0]:
                best = (c, (i + 1, j + 1, flips))
    c, (i, j, flips) = best
    a, b = a_list[i - 1], b_list[j - 1]
    for ax, f in enumerate(flips):
        if f:
            b = np.flip(b, ax)
    rows.append({"oasis2": r.oasis2, "oasis1": r.oasis1_candidate, "d_etiv_pct": r.d_etiv_pct,
                 "r_part44": r.max_corr_candidate, "best_central_r": c, "repeat_o2": i, "repeat_o1": j,
                 "flips_xyz": "".join("F" if f else "-" for f in flips),
                 "identical_voxels_frac": float(np.mean(np.isclose(a, b))), "full_r_after_flip": corr(a, b)})
    print(rows[-1], flush=True)
pd.DataFrame(rows).to_csv(OUT / "flip_diagnostic_posthoc.csv", index=False)
