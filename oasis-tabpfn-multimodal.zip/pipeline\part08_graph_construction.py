"""Part 08 - Population graph construction + K sensitivity (graph quality before any GNN).

For every outer fold, graph type G1-G4, distance (Euclidean / cosine) and K:
  - edge homophily of the training graph (training labels only),
  - degree statistics,
  - inductive kNN label propagation: each test subject is scored by the fraction of
    dementia-class subjects among its K nearest TRAINING neighbours.
This shows how much label signal the patient-similarity structure carries.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

import config
from common import PhaseRun, binary_metrics, embedding_cols, iter_outer_folds, load_cohort
from graphs import (GRAPH_PCA_DIM, GRAPH_TYPES, edge_homophily, knn_adjacency, node_features,
                    test_neighbours)

METRICS = ["euclidean", "cosine"]

with PhaseRun("part08_graph", __file__, inputs=[config.COHORT_FILE, config.FOLDS_FILE],
              params={"graph_types": GRAPH_TYPES, "distances": METRICS, "K": config.KNN_K,
                      "graph_pca_dim": GRAPH_PCA_DIM}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    y = df[config.TARGET_COL].to_numpy()
    rows = []
    for seed, fold, tr, te in iter_outer_folds(df):
        for g in GRAPH_TYPES:
            Xtr, Xte = node_features(df, emb, tr, te, g, seed=seed)
            for dist in METRICS:
                for k in config.KNN_K:
                    A = knn_adjacency(Xtr, k, dist)
                    deg = A.sum(1)
                    nn = test_neighbours(Xtr, Xte, k, dist)
                    prob = y[tr][nn].mean(1)
                    m = binary_metrics(y[te], (prob > 0.5).astype(int), prob)
                    m.update({"graph": g, "distance": dist, "k": k, "seed": seed, "fold": fold,
                              "homophily_train": edge_homophily(A, y[tr]),
                              "degree_mean": deg.mean(), "degree_max": deg.max(),
                              "isolated_nodes": int((deg == 0).sum())})
                    rows.append(m)
        print(f"  seed {seed} fold {fold} done")
    res = pd.DataFrame(rows)
    res["group"] = res.graph + "|" + res.distance
    res["model"] = "kNN_k" + res.k.astype(str)
    run.save_csv(res, "graph_quality_per_fold.csv")

    agg = res.groupby(["graph", "distance", "k"]).agg(
        homophily=("homophily_train", "mean"), homophily_sd=("homophily_train", "std"),
        degree_mean=("degree_mean", "mean"),
        knn_bal_acc=("balanced_accuracy", "mean"), knn_mcc=("mcc", "mean"),
        knn_auc=("roc_auc", "mean"), knn_auc_sd=("roc_auc", "std")).reset_index()
    run.save_csv(agg, "graph_quality_summary.csv")
    print("\nGraph quality (mean over 25 folds):\n", agg.round(4).to_string(index=False))

    best = agg.sort_values("homophily").groupby(["graph", "distance"]).tail(1)
    print("\nHighest-homophily K per graph/distance:\n", best.round(4).to_string(index=False))
    run.save_csv(best, "best_k_by_homophily_descriptive.csv")

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    for (g, d), s in agg.groupby(["graph", "distance"]):
        ls = "-" if d == "euclidean" else "--"
        axes[0].plot(s.k, s.homophily, ls, marker="o", label=f"{g} ({d[:3]})")
        axes[1].plot(s.k, s.knn_auc, ls, marker="o", label=f"{g} ({d[:3]})")
    axes[0].axhline(0.5, color="grey", lw=0.8)
    axes[0].set_title("Edge homophily of training graph"); axes[0].set_xlabel("K")
    axes[1].set_title("Inductive kNN label propagation ROC-AUC"); axes[1].set_xlabel("K")
    axes[1].legend(fontsize=7, ncol=2)
    fig.tight_layout()
    run.save_fig(fig, "fig_graph_homophily_vs_k.png")
    plt.close(fig)
