import sys
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import numpy as np
import pandas as pd

import config
import external_tools as et
from common import load_cohort

ext = et.load_oasis2()
o1 = pd.read_csv(config.CLINICAL_FILE)
o1 = o1[o1.ID.str.endswith("_MR1")].assign(sex_binary=lambda d: (d["M/F"] == "M").astype(int))
cohort = set(load_cohort().subject_id)


def best(r, lo, hi, pool):
    c = pool[(pool.sex_binary == r.sex_binary) & (pool.Educ == r.Educ) & ((r.Age - pool.Age).between(lo, hi))]
    if pd.notna(r.SES):
        c = c[c.SES.isna() | (c.SES == r.SES)]
    if c.empty:
        return np.nan, None
    d = ((c.eTIV - r.eTIV).abs() / r.eTIV * 100)
    i = d.idxmin()
    return d[i], c.loc[i]


for label, lo, hi in [("plausible window [-2,6]", -2, 6), ("null window [-30,-22]", -30, -22), ("null window [14,22]", 14, 22)]:
    res = [best(r, lo, hi, o1) for _, r in ext.iterrows()]
    d = np.array([x[0] for x in res])
    print(f"{label}: has candidate {np.isfinite(d).sum()}, |dETIV|<0.5% {np.nansum(d < 0.5)}, <1% {np.nansum(d < 1)}, "
          f"median {np.nanmedian(d):.2f}%")

rows = []
for _, r in ext.iterrows():
    dd, c = best(r, -2, 6, o1)
    if c is not None:
        rows.append({"oasis2": r.subject_id, "oasis1": c.ID, "d_etiv_pct": dd, "age2": r.Age, "age1": c.Age,
                     "mmse2": r.MMSE, "mmse1": c.MMSE, "nwbv2": r.nWBV, "nwbv1": c.nWBV, "cdr2": r.CDR, "cdr1": c.CDR,
                     "in_train_cohort": c.ID[:9] in cohort})
t = pd.DataFrame(rows).sort_values("d_etiv_pct")
print(t.head(25).round(3).to_string(index=False))
s = t[t.d_etiv_pct < 0.5]
print("tight matches", len(s), "in training cohort", s.in_train_cohort.sum(),
      "nWBV |diff| median", (s.nwbv1 - s.nwbv2).abs().median(), "CDR equal", (s.cdr1 == s.cdr2).mean())

t.to_csv(config.OUTPUT_DIR / 'part42_external_clinical' / 'overlap_diagnostic_pairs.csv', index=False)
