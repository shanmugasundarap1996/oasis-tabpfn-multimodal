"""Proposed framework: leakage-safe multimodal representation + TabPFN v2 in-context learning.

    x = [ PCA_k( standardise( impute(z_MRI) ) )  ||  standardise( impute(x_clin) ) ]
    P(CDR > 0 | x, D_train) = TabPFN_theta(x | D_train)        (theta frozen, no gradient training)

All data-dependent steps (imputation, scaling, PCA) are fitted on the training subjects only;
k is selected by inner cross-validation (ROC-AUC).
"""
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from tabpfn import TabPFNClassifier
from tabpfn.constants import ModelVersion

import config


def build_model(mri_cols, clin_cols=config.CLINICAL, k=8):
    """Multimodal TabPFN pipeline for a fixed MRI PCA dimension k."""
    mri_block = Pipeline([("imp", SimpleImputer(strategy="median")),
                          ("sc", StandardScaler()),
                          ("pca", PCA(n_components=k, random_state=config.RANDOM_STATE))])
    clin_block = Pipeline([("imp", SimpleImputer(strategy="median")),
                           ("sc", StandardScaler())])
    prep = ColumnTransformer([("mri", mri_block, list(mri_cols)),
                              ("tab", clin_block, list(clin_cols))])
    clf = TabPFNClassifier.create_default_for_version(ModelVersion.V2, device="cpu",
                                                      random_state=config.RANDOM_STATE)
    return Pipeline([("prep", prep), ("clf", clf)])


def fit_with_inner_cv(X, y, mri_cols, inner_cv, clin_cols=config.CLINICAL):
    """Choose k on the inner folds (ROC-AUC), refit on all training subjects. Returns GridSearchCV."""
    grid = {"prep__mri__pca": [PCA(n_components=k, random_state=config.RANDOM_STATE)
                               for k in config.PCA_GRID]}
    gs = GridSearchCV(build_model(mri_cols, clin_cols), grid, cv=inner_cv,
                      scoring=config.TUNING_SCORING, n_jobs=-1, refit=True)
    return gs.fit(X, y)


def selected_k(gs):
    return gs.best_params_["prep__mri__pca"].n_components
