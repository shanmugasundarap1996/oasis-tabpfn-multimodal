"""Part 19 v10 - Super learner: logistic meta-learner on the logits of TabPFN, RF, XGBoost and LR
inner out-of-fold predictions (outer-training subjects only), applied to their outer-test predictions.
Threshold tuned for MCC on the meta-learner's own cross-validated predictions of the training subjects."""
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_predict

import config
from common import PhaseRun
from newmethods import BASELINE_FILE, PROTOCOL_FILE, run_cached_version

KEYS = ["tabpfn|full|sel", "rf|sel", "xgb|sel", "lr|sel"]


def logit(p):
    p = np.clip(p, 1e-4, 1 - 1e-4)
    return np.log(p / (1 - p))


def combine(P, y):
    Z_tr = np.column_stack([logit(P[k]["oof"]) for k in KEYS])
    Z_te = np.column_stack([logit(P[k]["test"]) for k in KEYS])
    meta = LogisticRegression(C=1.0, max_iter=1000)
    oof_meta = cross_val_predict(meta, Z_tr, y, cv=StratifiedKFold(5, shuffle=True, random_state=0),
                                 method="predict_proba")[:, 1]
    meta.fit(Z_tr, y)
    return oof_meta, meta.predict_proba(Z_te)[:, 1], {f"w_{k.split('|')[0]}": w for k, w in zip(KEYS, meta.coef_[0])}


with PhaseRun("part19_v10_superlearner", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"keys": KEYS, "meta": "LogisticRegression(C=1) on logits", "threshold": "meta-OOF MCC-optimal"}) as run:
    run_cached_version(run, "v10_superlearner", KEYS, combine)
