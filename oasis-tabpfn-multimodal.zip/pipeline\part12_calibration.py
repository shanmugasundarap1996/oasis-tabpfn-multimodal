"""Part 12 - Calibration.

(a) Calibration of every key model from its saved out-of-fold probabilities:
    Brier, ECE, log-loss, calibration slope and intercept (per fold, then mean ± SD),
    reliability diagram (pooled over the 25 outer folds).
(b) Post-hoc recalibration for the classical fusion models: uncalibrated vs Platt (sigmoid)
    vs isotonic. Hyperparameters tuned on the frozen inner folds; the calibrator is then fitted
    with CalibratedClassifierCV on the same inner folds of the OUTER TRAINING set only.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV

import config
from common import (PhaseRun, binary_metrics, embedding_cols, inner_splits, iter_outer_folds,
                    load_cohort)
from models import build

OUT = config.OUTPUT_DIR
KEY_MODELS = [  # (label, file, group, model)
    ("Clinical C5 - LR", OUT / "part04_clinical/oof_predictions.csv", "C5_clinical_full", "LR"),
    ("Clinical C5 - XGBoost", OUT / "part04_clinical/oof_predictions.csv", "C5_clinical_full", "XGBoost"),
    ("MRI PCA - LR", OUT / "part06_pca/nested_oof_predictions.csv", "MRI_PCA_nested", "LR"),
    ("Fusion PCA - LR", OUT / "part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "LR"),
    ("Fusion PCA - SVM", OUT / "part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "SVM_RBF"),
    ("Fusion PCA - RF", OUT / "part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "RF"),
    ("Fusion PCA - XGBoost", OUT / "part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "XGBoost"),
    ("Transportable - LR", OUT / "part07_fusion/oof_predictions.csv", "Transportable_PCA_nested", "LR"),
    ("GCN transductive", OUT / "part09_gnn/oof_predictions.csv", "GNN_transductive", "GCN"),
    ("GAT transductive", OUT / "part09_gnn/oof_predictions.csv", "GNN_transductive", "GAT"),
    ("GCN inductive", OUT / "part10_inductive/oof_predictions.csv", "GNN_inductive", "GCN"),
    ("GAT inductive", OUT / "part10_inductive/oof_predictions.csv", "GNN_inductive", "GAT"),
]
RECAL_MODELS = ["LR", "XGBoost"]
NESTED_K = [k for k in config.PCA_DIMS if k <= 64]


def slope_intercept(y, p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    logit = np.log(p / (1 - p)).reshape(-1, 1)
    lr = LogisticRegression(C=1e6, max_iter=1000).fit(logit, y)
    return float(lr.coef_[0, 0]), float(lr.intercept_[0])


inputs = sorted({str(f) for _, f, _, _ in KEY_MODELS})
with PhaseRun("part12_calibration", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE] + inputs,
              params={"key_models": [k[0] for k in KEY_MODELS], "recalibrated": RECAL_MODELS,
                      "methods": ["uncalibrated", "sigmoid", "isotonic"]}) as run:

    # ---------------- (a) calibration of saved OOF predictions
    cal_rows, pooled = [], {}
    for label, f, g, m in KEY_MODELS:
        p = pd.read_csv(f)
        p = p[(p.group == g) & (p.model == m)]
        assert len(p) == 166 * len(config.OUTER_SEEDS), f"{label}: unexpected prediction count {len(p)}"
        for (seed, fold), s in p.groupby(["seed", "fold"]):
            met = binary_metrics(s.y_true, s.y_pred, s.y_prob)
            sl, ic = slope_intercept(s.y_true.to_numpy(), s.y_prob.to_numpy())
            cal_rows.append({"model": label, "seed": seed, "fold": fold, "brier": met["brier"],
                             "ece": met["ece"], "logloss": met["logloss"], "roc_auc": met["roc_auc"],
                             "cal_slope": sl, "cal_intercept": ic})
        pooled[label] = p
    cal = pd.DataFrame(cal_rows)
    run.save_csv(cal, "calibration_per_fold.csv")
    cal_sum = cal.groupby("model").agg(["mean", "std"])
    cal_sum.columns = [f"{a}_{b}" for a, b in cal_sum.columns]
    cal_sum = cal_sum.drop(columns=["seed_mean", "seed_std", "fold_mean", "fold_std"]).reset_index()
    run.save_csv(cal_sum, "calibration_summary.csv")
    print("Calibration of key models (mean over 25 folds):\n",
          cal_sum[["model", "brier_mean", "ece_mean", "logloss_mean", "cal_slope_mean",
                   "cal_intercept_mean"]].round(4).to_string(index=False))

    fig, axes = plt.subplots(1, 2, figsize=(12, 5.5))
    groups = [[k[0] for k in KEY_MODELS[:8]], [k[0] for k in KEY_MODELS[8:]] + ["Fusion PCA - LR"]]
    for ax, labels in zip(axes, groups):
        ax.plot([0, 1], [0, 1], "--", color="grey")
        for label in labels:
            p = pooled[label]
            frac, mean = calibration_curve(p.y_true, p.y_prob, n_bins=10, strategy="quantile")
            ax.plot(mean, frac, marker="o", ms=3, label=label)
        ax.set_xlabel("mean predicted probability"); ax.set_ylabel("observed fraction CDR > 0")
        ax.legend(fontsize=7)
    axes[0].set_title("Classical models"); axes[1].set_title("Graph models (vs fusion LR)")
    fig.tight_layout()
    run.save_fig(fig, "fig_reliability_diagrams.png")
    plt.close(fig)

    # ---------------- (b) recalibration inside training folds
    df = load_cohort()
    emb = embedding_cols(df)
    feats = emb + config.CLINICAL_FULL
    y = df[config.TARGET_COL].to_numpy()
    pca_grid = {"prep__mri__pca": [PCA(n_components=k, random_state=42) for k in NESTED_K] + ["passthrough"]}
    rows = []
    for seed, fold, tr, te in iter_outer_folds(df):
        cv_in = inner_splits(df, seed, fold, tr)
        for name in RECAL_MODELS:
            pipe, grid = build(name, mri_cols=emb, tab_cols=config.CLINICAL_FULL, pca_dim=8, extra_grid=pca_grid)
            gs = GridSearchCV(pipe, grid, cv=cv_in, scoring=config.TUNING_SCORING, n_jobs=-1)
            gs.fit(df.iloc[tr][feats], y[tr])
            variants = {"uncalibrated": gs.best_estimator_}
            for method in ["sigmoid", "isotonic"]:
                variants[method] = CalibratedClassifierCV(clone(gs.best_estimator_), method=method,
                                                          cv=cv_in).fit(df.iloc[tr][feats], y[tr])
            for method, mdl in variants.items():
                prob = mdl.predict_proba(df.iloc[te][feats])[:, 1]
                met = binary_metrics(y[te], (prob >= 0.5).astype(int), prob)
                sl, ic = slope_intercept(y[te], prob)
                rows.append({**met, "model": f"Fusion PCA - {name}", "method": method,
                             "cal_slope": sl, "cal_intercept": ic, "seed": seed, "fold": fold})
        print(f"  seed {seed} fold {fold} done")
    rc = pd.DataFrame(rows)
    run.save_csv(rc, "recalibration_per_fold.csv")
    rc_sum = rc.groupby(["model", "method"])[["brier", "ece", "logloss", "cal_slope", "cal_intercept",
                                               "roc_auc", "balanced_accuracy", "mcc"]].agg(["mean", "std"])
    rc_sum.columns = [f"{a}_{b}" for a, b in rc_sum.columns]
    rc_sum = rc_sum.reset_index()
    run.save_csv(rc_sum, "recalibration_summary.csv")
    print("\nRecalibration (fitted inside outer training folds):\n",
          rc_sum[["model", "method", "brier_mean", "ece_mean", "logloss_mean", "cal_slope_mean",
                  "roc_auc_mean", "mcc_mean"]].round(4).to_string(index=False))
