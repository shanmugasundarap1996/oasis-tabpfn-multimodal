"""Evaluation metrics (discrimination + calibration)."""
import numpy as np
from sklearn.metrics import (accuracy_score, average_precision_score, balanced_accuracy_score,
                             brier_score_loss, confusion_matrix, f1_score, log_loss,
                             matthews_corrcoef, precision_score, recall_score, roc_auc_score)


def expected_calibration_error(y, p, n_bins=10):
    y, p = np.asarray(y).astype(int), np.asarray(p, float)
    ids = np.digitize(p, np.linspace(0, 1, n_bins + 1)[1:-1], right=True)
    return float(sum((ids == b).mean() * abs(y[ids == b].mean() - p[ids == b].mean())
                     for b in range(n_bins) if np.any(ids == b)))


def binary_metrics(y, pred, prob):
    y, pred = np.asarray(y).astype(int), np.asarray(pred).astype(int)
    prob = np.clip(np.asarray(prob, float), 1e-7, 1 - 1e-7)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {
        "balanced_accuracy": balanced_accuracy_score(y, pred),
        "macro_f1": f1_score(y, pred, average="macro"),
        "mcc": matthews_corrcoef(y, pred),
        "accuracy": accuracy_score(y, pred),
        "sensitivity": recall_score(y, pred, zero_division=0),
        "specificity": tn / (tn + fp) if (tn + fp) else np.nan,
        "precision": precision_score(y, pred, zero_division=0),
        "roc_auc": roc_auc_score(y, prob),
        "pr_auc": average_precision_score(y, prob),
        "brier": brier_score_loss(y, prob),
        "ece": expected_calibration_error(y, prob),
        "logloss": log_loss(y, np.c_[1 - prob, prob], labels=[0, 1]),
    }
