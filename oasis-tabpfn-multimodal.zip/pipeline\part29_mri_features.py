"""Part 29 - Documented, label-free MRI feature extraction (replaces the third-party Kaggle embeddings).

Input : OASIS-1 atlas-registered (Talairach T88, 1 mm), skull-stripped, bias-corrected T1 volumes
        (*_t88_masked_gfc, 176 x 208 x 176) of the first session (MR1) of every subject.
Slices: fixed a priori (identical anatomy in all subjects because volumes are atlas-registered):
        5 axial slices at 40, 45, 50, 55, 60 % of axis 2 (ventricles, basal ganglia, hippocampal level)
        4 coronal slices at 45, 50, 55, 60 % of axis 1 (medial temporal lobes / hippocampus).
Intensity: per volume, clipped to [0, 99.5th percentile of brain voxels] and scaled to [0, 1];
        each slice resized to 224 x 224 (bilinear), replicated to 3 channels, ImageNet-normalised.
Network: torchvision ResNet18 with ImageNet weights (IMAGENET1K_V1), frozen, eval mode; the 512-D
        global-average-pooled output is taken per slice and averaged over the 9 slices.
No labels are used at any point, so the representation cannot leak diagnostic information.
Resumable: one .npy per session in oasis1_features/; finished sessions are skipped.
"""
import time

import nibabel as nib
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
import torchvision

import config
from common import PhaseRun

T88 = config.BASE_DIR / "oasis1_t88"
FEAT = config.BASE_DIR / "oasis1_features"
OUT_CSV = config.RAW_DIR / "mri_embeddings_own.csv"
AXIAL = [0.40, 0.45, 0.50, 0.55, 0.60]
CORONAL = [0.45, 0.50, 0.55, 0.60]
MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)


def wait_for_extraction(max_h=6):
    t0 = time.time()
    while not all((T88 / f"_done_disc{i}.txt").exists() for i in range(1, 13)):
        if time.time() - t0 > max_h * 3600:
            raise TimeoutError("extraction not finished")
        time.sleep(60)


def slices(vol):
    brain = vol[vol > 0]
    hi = np.percentile(brain, 99.5) if brain.size else 1.0
    v = np.clip(vol, 0, hi) / hi
    out = [np.rot90(v[:, :, int(round(f * (v.shape[2] - 1)))]) for f in AXIAL]
    out += [np.rot90(v[:, int(round(f * (v.shape[1] - 1))), :]) for f in CORONAL]
    return out


def embed(model, sl):
    x = torch.stack([F.interpolate(torch.tensor(s.copy(), dtype=torch.float32)[None, None], size=(224, 224),
                                   mode="bilinear", align_corners=False)[0, 0] for s in sl])
    x = x[:, None].repeat(1, 3, 1, 1)
    x = (x - MEAN) / STD
    with torch.no_grad():
        return model(x).numpy().mean(0)


with PhaseRun("part29_mri_features", __file__,
              params={"axial_fractions": AXIAL, "coronal_fractions": CORONAL, "weights": "IMAGENET1K_V1",
                      "aggregation": "mean of 9 slice embeddings", "intensity": "clip p99.5, scale [0,1]",
                      "torch": torch.__version__, "torchvision": torchvision.__version__}) as run:
    wait_for_extraction()
    torch.set_num_threads(4)
    torch.manual_seed(0)
    model = torchvision.models.resnet18(weights=torchvision.models.ResNet18_Weights.IMAGENET1K_V1)
    model.fc = torch.nn.Identity()
    model.eval()
    FEAT.mkdir(exist_ok=True)
    sessions = sorted(p.name for p in T88.iterdir() if p.is_dir() and p.name.endswith("_MR1"))
    t0 = time.time()
    for i, s in enumerate(sessions, 1):
        f = FEAT / f"{s}.npy"
        if f.exists():
            continue
        vol = np.asarray(nib.load(next((T88 / s).glob("*.img"))).dataobj).squeeze().astype(np.float32)
        e = embed(model, slices(vol))
        tmp = FEAT / f"{s}.tmp.npy"
        np.save(tmp, e.astype(np.float32)); tmp.replace(f)
        if i % 25 == 0:
            print(f"  {i}/{len(sessions)} sessions ({time.time() - t0:.0f}s)", flush=True)
    rows = []
    for s in sessions:
        e = np.load(FEAT / f"{s}.npy")
        rows.append({"subject_id": s.replace("_MR1", ""), **{f"emb_{j}": float(v) for j, v in enumerate(e)}})
    emb = pd.DataFrame(rows)
    assert emb.shape[1] == 513 and emb.subject_id.is_unique
    emb.to_csv(OUT_CSV, index=False)
    run.outputs.append(OUT_CSV)
    print(f"saved {OUT_CSV} ({len(emb)} subjects x 512)")
    # example slice panel for the methods / supplement
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    vol = np.asarray(nib.load(next((T88 / sessions[0]).glob("*.img"))).dataobj).squeeze().astype(np.float32)
    sl = slices(vol)
    fig, ax = plt.subplots(1, 9, figsize=(13, 1.8))
    for a, s_, t in zip(ax, sl, [f"ax {int(f*100)}%" for f in AXIAL] + [f"cor {int(f*100)}%" for f in CORONAL]):
        a.imshow(s_, cmap="gray"); a.set_title(t, fontsize=7); a.axis("off")
    fig.tight_layout()
    run.save_fig(fig, "fig_slice_protocol.png", dpi=200)
    plt.close(fig)
