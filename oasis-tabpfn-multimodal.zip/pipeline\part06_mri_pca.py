"""Part 06 - MRI PCA dimension study (PCA always fitted inside training folds).

(a) Fold-wise explained variance EVR_k on each outer training set.
(b) Fixed-k sensitivity: MRI-only LR for k in {8,...,128, 512}  (descriptive; k not selected here).
(c) Nested selection: k chosen by inner CV together with model hyperparameters (reported estimate).
    Inner training sets have ~88 subjects, so the nested grid is k in {8,16,24,32,64} + no-PCA.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

import config
from common import (PhaseRun, check_oof_integrity, embedding_cols, iter_outer_folds,
                    load_cohort, run_nested_cv, summarize)
from models import CLASSIFIERS, build

FIXED_K = config.PCA_DIMS + [None]                 # None = full 512
NESTED_K = [k for k in config.PCA_DIMS if k <= 64]

with PhaseRun("part06_pca", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE],
              params={"fixed_k": FIXED_K, "nested_k": NESTED_K + ["passthrough(512)"]}) as run:
    df = load_cohort()
    emb = embedding_cols(df)

    # ---------------- (a) fold-wise explained variance
    evr_rows = []
    for seed, fold, tr, te in iter_outer_folds(df):
        M = StandardScaler().fit_transform(SimpleImputer(strategy="median").fit_transform(df.iloc[tr][emb]))
        cum = np.cumsum(PCA(random_state=seed).fit(M).explained_variance_ratio_)
        for k in config.PCA_DIMS:
            evr_rows.append({"seed": seed, "fold": fold, "k": k, "cum_evr": cum[k - 1]})
    evr = pd.DataFrame(evr_rows)
    run.save_csv(evr, "evr_per_fold.csv")
    evr_sum = evr.groupby("k").cum_evr.agg(["mean", "std", "min", "max"]).reset_index()
    print("Cumulative explained variance on outer training folds:\n", evr_sum.round(4).to_string(index=False))
    run.save_csv(evr_sum, "evr_summary.csv")

    # ---------------- (b) fixed-k sensitivity (LR)
    specs = []
    for k in FIXED_K:
        pipe, grid = build("LR", mri_cols=emb, pca_dim=k)
        specs.append({"group": f"PCA_{k}" if k else "Full_512", "name": "LR",
                      "features": emb, "pipeline": pipe, "grid": grid})
    fx_folds, fx_preds, fx_params = run_nested_cv(df, specs)
    fx_folds["k"] = fx_folds.group.map(lambda g: 512 if g == "Full_512" else int(g.split("_")[1]))
    run.save_csv(fx_folds, "fixed_k_fold_metrics.csv")
    run.save_csv(fx_preds, "fixed_k_oof_predictions.csv")
    fx_sum = summarize(fx_folds, by=("group", "model", "k")).sort_values("k")
    run.save_csv(fx_sum, "fixed_k_summary.csv")
    print("\nFixed-k MRI-only LR:\n",
          fx_sum[["k", "balanced_accuracy", "macro_f1", "mcc", "roc_auc"]].to_string(index=False))

    # ---------------- (c) nested k selection (all four models)
    pca_opts = [PCA(n_components=k, random_state=42) for k in NESTED_K] + ["passthrough"]
    specs = []
    for name in CLASSIFIERS:
        pipe, grid = build(name, mri_cols=emb, pca_dim=8,
                           extra_grid={"prep__mri__pca": pca_opts})
        specs.append({"group": "MRI_PCA_nested", "name": name, "features": emb,
                      "pipeline": pipe, "grid": grid})
    ns_folds, ns_preds, ns_params = run_nested_cv(df, specs)
    ns_params["selected_k"] = ns_params["prep__mri__pca"].map(
        lambda s: 512 if s == "passthrough" else int(s.split("n_components=")[1].split(",")[0].rstrip(")")))
    run.save_csv(ns_folds, "nested_fold_metrics.csv")
    run.save_csv(ns_preds, "nested_oof_predictions.csv")
    run.save_csv(ns_params, "nested_best_params.csv")
    ns_sum = summarize(ns_folds)
    run.save_csv(ns_sum, "nested_summary.csv")
    freq = ns_params.groupby(["model", "selected_k"]).size().unstack(fill_value=0)
    run.save_csv(freq.reset_index(), "nested_selected_k_frequency.csv")
    print("\nNested MRI PCA (k tuned in inner CV):\n",
          ns_sum[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc"]].to_string(index=False))
    print("\nSelected k frequency (25 outer folds):\n", freq.to_string())

    checks = pd.DataFrame([
        ("fixed-k: 25 folds per k", bool((fx_folds.groupby("group").size() == 25).all())),
        ("nested: 25 folds per model", bool((ns_folds.groupby("model").size() == 25).all())),
        ("OOF integrity fixed-k", check_oof_integrity(fx_preds, df)),
        ("OOF integrity nested", check_oof_integrity(ns_preds, df)),
    ], columns=["check", "passed"])
    print("\n", checks.to_string(index=False))
    run.save_csv(checks, "integrity_checks.csv")

    # ---------------- figure: EVR and performance vs k
    fig, ax1 = plt.subplots(figsize=(7, 4.2))
    ks = evr_sum.k.to_numpy()
    ax1.errorbar(ks, evr_sum["mean"], yerr=evr_sum["std"], marker="s", color="#5b7083", label="cumulative EVR")
    ax1.set_xscale("log", base=2); ax1.set_xlabel("MRI PCA components k")
    ax1.set_ylabel("Cumulative explained variance")
    ax2 = ax1.twinx()
    ax2.errorbar(fx_sum.k, fx_sum.mcc_mean, yerr=fx_sum.mcc_sd, marker="o", color="#b03a2e", label="MCC (LR)")
    ax2.set_ylabel("MCC (25 outer folds)")
    ax1.set_xticks([8, 16, 32, 64, 128, 512]); ax1.set_xticklabels([8, 16, 32, 64, 128, 512])
    fig.legend(loc="lower right", bbox_to_anchor=(0.88, 0.18))
    ax1.set_title("MRI PCA: explained variance and MRI-only performance")
    fig.tight_layout()
    run.save_fig(fig, "fig_pca_evr_performance.png")
    plt.close(fig)
