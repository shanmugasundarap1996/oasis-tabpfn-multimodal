"""Part 51 - Amendment 10: v13 multi-view TabPFN = mean of the out-of-fold probabilities of TabPFN on
[ResNet MRI + clinical] (Part 30) and TabPFN on [morphometry + clinical] (Part 36), same frozen folds, threshold 0.5.
No model is refitted. Primary family and success rule as pre-registered in Amendment 10."""
import pandas as pd

import config
from common import PhaseRun, binary_metrics, summarize
from compare_tools import paired_table

O = config.OUTPUT_DIR
P30, P36, P04 = O / "part30_own_mri_benchmark", O / "part36_morph_benchmark", O / "part04_clinical"

with PhaseRun("part51_v13_multiview", __file__,
              inputs=[P30 / "oof_predictions.csv", P36 / "oof_predictions.csv", P30 / "fold_metrics.csv",
                      P36 / "fold_metrics.csv", P04 / "fold_metrics.csv"]) as run:
    a = pd.read_csv(P30 / "oof_predictions.csv").query("model == 'TabPFN_v2'")
    b = pd.read_csv(P36 / "oof_predictions.csv").query("model == 'TabPFN_morph'")
    m = a.merge(b, on=["seed", "fold", "subject_id"], suffixes=("_r", "_m"), validate="one_to_one")
    assert len(m) == len(a) == len(b) and (m.y_true_r == m.y_true_m).all()
    m["y_prob"] = (m.y_prob_r + m.y_prob_m) / 2
    rows = []
    for (s, f), g in m.groupby(["seed", "fold"]):
        y, p = g.y_true_r.to_numpy(), g.y_prob.to_numpy()
        rows.append({**binary_metrics(y, (p >= config.DECISION_THRESHOLD).astype(int), p), "group": "v13", "model": "v13_multiview",
                     "seed": s, "fold": f})
    v13 = pd.DataFrame(rows)
    run.save_csv(v13, "fold_metrics.csv")
    run.save_csv(m[["seed", "fold", "subject_id", "y_true_r", "y_prob_r", "y_prob_m", "y_prob"]], "oof_predictions.csv")
    summ = summarize(v13); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "mcc", "roc_auc", "brier"]].to_string(index=False), flush=True)

    f30, f36, f04 = pd.read_csv(P30 / "fold_metrics.csv"), pd.read_csv(P36 / "fold_metrics.csv"), pd.read_csv(P04 / "fold_metrics.csv")
    clin = f04[f04.group == "C5_clinical_full"]
    primary = paired_table(v13, "v13_multiview", {
        "Fusion_PCA_RF": f30[f30.model == "Fusion_PCA_RF"], "Fusion_PCA_LR": f30[f30.model == "Fusion_PCA_LR"],
        "Fusion_PCA_XGBoost": f30[f30.model == "Fusion_PCA_XGBoost"], "Clinical_C5_LR": clin[clin.model == "LR"],
        "Clinical_C5_XGBoost": clin[clin.model == "XGBoost"], "MRI_only_LR": f30[f30.model == "MRI_only_LR"]})
    secondary = paired_table(v13, "v13_multiview", {"TabPFN_v2 (ResNet)": f30[f30.model == "TabPFN_v2"],
                                                    "TabPFN_morph": f36[f36.model == "TabPFN_morph"]})
    primary["superior"] = primary.p_holm < 0.05
    primary["robust"] = primary.superior & (primary.p_nb_holm < 0.05)
    run.save_csv(primary, "v13_vs_baselines_primary.csv"); run.save_csv(secondary, "v13_vs_components_secondary.csv")
    cols = ["comparator", "metric", "mean_ref", "mean_comp", "delta", "ci95_low", "ci95_high", "p_wilcoxon", "p_holm", "p_nb_holm"]
    print(primary[cols].round(4).to_string(index=False))
    print(secondary[cols].round(4).to_string(index=False))
    p_rf = primary.query("comparator == 'Fusion_PCA_RF' and metric == 'mcc'").p_wilcoxon.iloc[0]
    print(f"conservative version check: unadjusted MCC p vs fusion RF = {p_rf:.4f} (threshold 0.05/13 = 0.0038)")
