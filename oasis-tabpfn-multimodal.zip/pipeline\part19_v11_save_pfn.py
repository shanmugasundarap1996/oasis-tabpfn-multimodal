"""Part 19 v11 - SAVE-PFN: Severity-Aware multi-View Ensemble in-context learning (amendment 4).

For each of 8 views (feature set x MRI PCA k), TabPFN v2 is conditioned on the training subjects with
their 3-level CDR label (0 / 0.5 / >=1) and returns P(CDR > 0) = 1 - P(level 0) for the test subjects;
the 8 probabilities are averaged; threshold 0.5. No parameter is tuned. CDR is never an input.

Tested against the rule: SAVE-PFN. Descriptive component analysis: the same 8 views with binary
context (multi-view only), and single-view severity-aware context (severity only).
"""
import numpy as np
import pandas as pd

import config
from cache import get
from common import PhaseRun, binary_metrics, iter_outer_folds, load_cohort, summarize
from newmethods import BASELINE_FILE, PROTOCOL_FILE, compare, run_cached_version

SETS = ["transport", "mri_mmse_age"]
KS = [8, 16, 32, 64]
SEV_KEYS = [f"tabpfn|{s}|{k}|sev" for s in SETS for k in KS]
BIN_KEYS = [f"tabpfn|{s}|{k}" for s in SETS for k in KS]


def mean_test(P, keys):
    t = np.mean([P[k]["test"] for k in keys], axis=0)
    return t, t, None


with PhaseRun("part19_v11_save_pfn", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"views": SEV_KEYS, "context_label": "target_3class", "threshold": 0.5,
                      "ablation_binary_views": BIN_KEYS}) as run:
    # ---------------- tested method
    verdict = run_cached_version(run, "v11_save_pfn", SEV_KEYS, lambda P, y: mean_test(P, SEV_KEYS),
                                 tune=False, need_oof=False)

    # ---------------- component analysis (descriptive, not tested against the rule)
    df = load_cohort()
    y = df[config.TARGET_COL].to_numpy()
    comp = {"SAVE-PFN (severity + multi-view)": SEV_KEYS,
            "multi-view only (binary context)": BIN_KEYS,
            "severity only (single view: transport, k=16)": ["tabpfn|transport|16|sev"],
            "neither (single view: transport, k=16, binary)": ["tabpfn|transport|16"]}
    rows = []
    for seed, fold, tr, te in iter_outer_folds(df):
        for name, keys in comp.items():
            p = np.mean([get(k, df, seed, fold, tr, te, y, need_oof=False)["test"] for k in keys], axis=0)
            m = binary_metrics(y[te], (p >= 0.5).astype(int), p)
            m.update({"group": "v11_components", "model": name, "seed": seed, "fold": fold})
            rows.append(m)
    comp_folds = pd.DataFrame(rows)
    run.save_csv(comp_folds, "component_fold_metrics.csv")
    comp_sum = summarize(comp_folds)
    run.save_csv(comp_sum, "component_summary.csv")
    tables = [compare(comp_folds[comp_folds.model == n], n)[0] for n in comp]
    run.save_csv(pd.concat(tables), "component_vs_baseline.csv")
    pd.set_option("display.width", 250)
    print("\nComponent analysis (descriptive):\n",
          comp_sum[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))
