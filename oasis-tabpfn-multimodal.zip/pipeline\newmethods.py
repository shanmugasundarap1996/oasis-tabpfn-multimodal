"""Shared helpers for Part 19 (new learning paradigms): baseline comparison with the
pre-registered success rule from NEW_METHODS_PROTOCOL.md."""
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.base import BaseEstimator, ClassifierMixin

import config

PROTOCOL_FILE = config.PIPELINE_DIR / "NEW_METHODS_PROTOCOL.md"
BASELINE_FILE = config.OUTPUT_DIR / "part07_fusion" / "fold_metrics.csv"
ALPHA = 0.05 / 11          # amendment 4: 11 planned versions (v1-v11), Bonferroni
AUC_MARGIN = 0.005
N_TRAIN, N_TEST = 133, 33


class GatedFusionNet(ClassifierMixin, BaseEstimator):
    """v3 - Gated multimodal network (sklearn-compatible).
    Columns: first n_mri = MRI embedding, rest = clinical. Per block: median impute + standardise
    (+ PCA-k on MRI), all fitted on the training data passed to fit().
    h_m = ReLU(W_m x_m), h_c = ReLU(W_c x_c), g = sigmoid(W_g [h_m, h_c]),
    z = g * h_m + (1 - g) * h_c, logits = W_o dropout(z).
    Modality dropout: during training each subject's h_m (or h_c) is zeroed with probability p
    (never both). Class-balanced cross-entropy; ensemble of n_seeds networks."""

    def __init__(self, n_mri=512, pca_k=16, hidden=16, weight_decay=1e-2, modality_dropout=0.3,
                 dropout=0.3, epochs=300, lr=0.01, n_seeds=3, random_state=0):
        self.n_mri, self.pca_k, self.hidden, self.weight_decay = n_mri, pca_k, hidden, weight_decay
        self.modality_dropout, self.dropout, self.epochs, self.lr = modality_dropout, dropout, epochs, lr
        self.n_seeds, self.random_state = n_seeds, random_state

    def _prep_fit(self, X):
        from sklearn.impute import SimpleImputer
        from sklearn.preprocessing import StandardScaler
        from models import CappedPCA
        X = np.asarray(X, dtype=float)
        self.mi_, self.ms_ = SimpleImputer(strategy="median"), StandardScaler()
        self.ci_, self.cs_ = SimpleImputer(strategy="median"), StandardScaler()
        self.pca_ = CappedPCA(n_components=self.pca_k, random_state=self.random_state)
        M = self.pca_.fit_transform(self.ms_.fit_transform(self.mi_.fit_transform(X[:, :self.n_mri])))
        C = self.cs_.fit_transform(self.ci_.fit_transform(X[:, self.n_mri:]))
        return M, C

    def _prep(self, X):
        X = np.asarray(X, dtype=float)
        M = self.pca_.transform(self.ms_.transform(self.mi_.transform(X[:, :self.n_mri])))
        C = self.cs_.transform(self.ci_.transform(X[:, self.n_mri:]))
        return M, C

    def _net(self, dm, dc):
        import torch
        from torch import nn

        class Net(nn.Module):
            def __init__(s):
                super().__init__()
                s.em, s.ec = nn.Linear(dm, self.hidden), nn.Linear(dc, self.hidden)
                s.g = nn.Linear(2 * self.hidden, self.hidden)
                s.out = nn.Linear(self.hidden, 2)
                s.drop = nn.Dropout(self.dropout)

            def forward(s, m, c, mask_m=None, mask_c=None):
                hm, hc = torch.relu(s.em(m)), torch.relu(s.ec(c))
                if mask_m is not None:
                    hm, hc = hm * mask_m, hc * mask_c
                g = torch.sigmoid(s.g(torch.cat([hm, hc], 1)))
                return s.out(s.drop(g * hm + (1 - g) * hc)), g
        return Net()

    def fit(self, X, y):
        import torch
        import torch.nn.functional as F
        torch.set_num_threads(1)
        y = np.asarray(y).astype(int)
        self.classes_ = np.array([0, 1])
        M, C = self._prep_fit(X)
        m, c = torch.tensor(M, dtype=torch.float32), torch.tensor(C, dtype=torch.float32)
        yt = torch.tensor(y)
        w = torch.tensor(len(y) / (2 * np.bincount(y, minlength=2)), dtype=torch.float32)
        self.nets_ = []
        for s in range(self.n_seeds):
            torch.manual_seed(self.random_state * 100 + s)
            gen = torch.Generator().manual_seed(self.random_state * 100 + s)
            net = self._net(M.shape[1], C.shape[1])
            opt = torch.optim.Adam(net.parameters(), lr=self.lr, weight_decay=self.weight_decay)
            for _ in range(self.epochs):
                net.train(); opt.zero_grad()
                drop = torch.rand(len(y), generator=gen) < self.modality_dropout
                which = torch.rand(len(y), generator=gen) < 0.5
                mask_m = (~(drop & which)).float()[:, None]
                mask_c = (~(drop & ~which)).float()[:, None]
                logits, _ = net(m, c, mask_m, mask_c)
                F.cross_entropy(logits, yt, weight=w).backward(); opt.step()
            net.eval()
            self.nets_.append(net)
        return self

    def predict_proba(self, X):
        import torch
        M, C = self._prep(X)
        m, c = torch.tensor(M, dtype=torch.float32), torch.tensor(C, dtype=torch.float32)
        with torch.no_grad():
            p = np.mean([torch.softmax(n(m, c)[0], 1)[:, 1].numpy() for n in self.nets_], axis=0)
        return np.c_[1 - p, p]

    def gate_values(self, X):
        import torch
        M, C = self._prep(X)
        m, c = torch.tensor(M, dtype=torch.float32), torch.tensor(C, dtype=torch.float32)
        with torch.no_grad():
            return np.mean([n(m, c)[1].mean(1).numpy() for n in self.nets_], axis=0)

    def predict(self, X):
        return (self.predict_proba(X)[:, 1] >= 0.5).astype(int)


THRESHOLDS = np.round(np.arange(0.05, 0.951, 0.01), 2)


def tune_threshold(y, p):
    """Threshold maximising MCC on (inner out-of-fold) predictions; ties -> closest to 0.5."""
    from sklearn.metrics import matthews_corrcoef
    scores = np.array([matthews_corrcoef(y, (p >= t).astype(int)) for t in THRESHOLDS])
    best = np.flatnonzero(scores >= scores.max() - 1e-12)
    return float(THRESHOLDS[best[np.argmin(np.abs(THRESHOLDS[best] - 0.5))]])


def run_cached_version(run, label, keys, combine, tune=True, need_oof=None):
    """Evaluate a version built from cached per-fold predictions.
    combine(preds, y_train) -> (oof_prob, test_prob, info) where preds[key] = {'oof', 'test'}.
    The decision threshold is tuned on oof_prob (outer-training subjects only) when tune=True."""
    import json
    from cache import get
    from common import binary_metrics, check_oof_integrity, iter_outer_folds, load_cohort, summarize
    df = load_cohort()
    y = df[config.TARGET_COL].to_numpy()
    rows, preds_rows, info_rows = [], [], []
    for seed, fold, tr, te in iter_outer_folds(df):
        P = {k: get(k, df, seed, fold, tr, te, y, need_oof=tune if need_oof is None else need_oof) for k in keys}
        oof_p, test_p, info = combine(P, y[tr])
        thr = tune_threshold(y[tr], oof_p) if tune else 0.5
        pred = (test_p >= thr).astype(int)
        m = binary_metrics(y[te], pred, test_p)
        m.update({"group": label, "model": label, "seed": seed, "fold": fold, "threshold": thr})
        rows.append(m)
        info_rows.append({"seed": seed, "fold": fold, "threshold": thr, **(info or {})})
        preds_rows += [{"group": label, "model": label, "seed": seed, "fold": fold,
                        "subject_id": df.subject_id.iloc[i], "y_true": int(y[i]), "y_prob": float(p),
                        "y_pred": int(q)} for i, p, q in zip(te, test_p, pred)]
        print(f"  seed {seed} fold {fold} done (thr={thr:.2f})", flush=True)
    folds, preds = pd.DataFrame(rows), pd.DataFrame(preds_rows)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(pd.DataFrame(info_rows), "per_fold_choices.csv")
    summary = summarize(folds)
    run.save_csv(summary, "summary.csv")
    print(summary[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))
    table, verdict = compare(folds, label)
    run.save_csv(table, "comparison_vs_baseline.csv")
    run.save_json(verdict, "verdict.json")
    print("\n", table[table.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))
    print("\nVERDICT:", json.dumps(verdict, indent=2, default=str))
    assert check_oof_integrity(preds, df)
    return verdict


def load_reference(group, model):
    t = pd.read_csv(BASELINE_FILE)
    t = t[(t.group == group) & (t.model == model)].set_index(["seed", "fold"]).sort_index()
    assert len(t) == 25
    return t


def _nb(d):
    v = np.var(d, ddof=1)
    if v == 0:
        return np.nan
    t = d.mean() / np.sqrt((1 / len(d) + N_TEST / N_TRAIN) * v)
    return float(2 * stats.t.sf(abs(t), len(d) - 1))


def compare(folds_new, label):
    """folds_new: 25 rows for one model (seed, fold, metrics). Returns (table, verdict dict)."""
    new = folds_new.set_index(["seed", "fold"]).sort_index()
    rows, verdict = [], {}
    for ref_name, (g, m) in {"Fusion_PCA_RF (baseline)": ("Fusion_PCA_nested", "RF"),
                             "Fusion_PCA_LR": ("Fusion_PCA_nested", "LR")}.items():
        ref = load_reference(g, m)
        assert (ref.index == new.index).all()
        for metric in ["mcc", "macro_f1", "balanced_accuracy", "roc_auc", "brier"]:
            d = (new[metric] - ref[metric]).to_numpy()
            boot = np.random.default_rng(0).choice(d, (10000, len(d))).mean(1)
            p = stats.wilcoxon(d).pvalue if np.any(d != 0) else 1.0
            rows.append({"new_model": label, "reference": ref_name, "metric": metric,
                         "mean_new": new[metric].mean(), "mean_ref": ref[metric].mean(),
                         "mean_diff": d.mean(), "ci95_low": np.percentile(boot, 2.5),
                         "ci95_high": np.percentile(boot, 97.5), "wins_new": int((d > 0).sum()),
                         "wins_ref": int((d < 0).sum()), "p_wilcoxon": p, "p_nadeau_bengio": _nb(d)})
        if ref_name.endswith("(baseline)"):
            t = pd.DataFrame(rows)
            mcc = t[(t.reference == ref_name) & (t.metric == "mcc")].iloc[0]
            auc = t[(t.reference == ref_name) & (t.metric == "roc_auc")].iloc[0]
            c1 = bool(mcc.mean_new > mcc.mean_ref)
            c2 = bool(mcc.p_wilcoxon < ALPHA)
            c3 = bool(auc.mean_new >= auc.mean_ref - AUC_MARGIN)
            verdict = {"model": label, "mean_mcc_new": mcc.mean_new, "mean_mcc_baseline": mcc.mean_ref,
                       "delta_mcc": mcc.mean_diff, "p_wilcoxon_mcc": mcc.p_wilcoxon, "alpha": ALPHA,
                       "mean_auc_new": auc.mean_new, "mean_auc_baseline": auc.mean_ref,
                       "rule_1_higher_mcc": c1, "rule_2_significant": c2, "rule_3_auc_not_worse": c3,
                       "SIGNIFICANTLY_BETTER": c1 and c2 and c3}
    return pd.DataFrame(rows), verdict
