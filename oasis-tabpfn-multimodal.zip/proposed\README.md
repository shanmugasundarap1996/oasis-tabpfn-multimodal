# Proposed framework: multimodal Alzheimer's disease classification with TabPFN in-context learning

This is a minimal implementation of the proposed algorithm in the paper *"Leakage-Aware Multimodal Alzheimer's Disease Classification with
Tabular Foundation-Model In-Context Learning from Structural MRI and Clinical Data"*.

## Algorithm
1. **Label-free MRI representation** (`extract_mri_features.py`). Nine fixed slices are taken from each subject's OASIS-1
   atlas-registered T1 volume: 5 axial and 4 coronal. Each slice passes through a frozen ImageNet ResNet18, and the
   512-D slice embeddings are averaged into the MRI vector `z`. No label is used.
2. **Inputs**: `z` plus 8 clinical variables (age, sex, education, SES, eTIV, nWBV, ASF, MMSE). The target is
   CDR = 0 vs CDR > 0; CDR itself is never an input.
3. **Leakage-safe representation**, fitted on training subjects only:
   - median imputation and standardisation of each block;
   - PCA of the MRI block to `k` components, with `k ∈ {8, 16, 24, 32, 64}` chosen by inner cross-validation (ROC-AUC);
   - early fusion `x = [PCA_k(z) || x_clin]`.
4. **In-context learning**: TabPFN v2 is a pre-trained transformer whose weights stay frozen. It receives the training
   subjects as context and returns `P(CDR > 0 | x, D_train)` for each test subject, classified at threshold 0.5.

## Files
| File | Purpose |
|---|---|
| `config.py` | paths, variables, `k` grid, seeds |
| `extract_mri_features.py` | label-free 512-D MRI features from the OASIS-1 T88 volumes (resumable) |
| `data_prep.py` | cohort (age ≥ 60, CDR available, one session per subject, published 166 IDs) and frozen 5×5 outer / 3-fold inner subject-level folds |
| `model.py` | the proposed model (`build_model`) and inner-CV selection of `k` (`fit_with_inner_cv`) |
| `metrics.py` | MCC, balanced accuracy, macro-F1, sensitivity, specificity, ROC-AUC, PR-AUC, Brier, ECE, log-loss |
| `run_proposed.py` | repeated nested cross-validation (25 outer folds), resumable |
| `predict_new.py` | fits on the whole cohort and predicts new subjects |

## Setup
```
pip install -r requirements.txt
```
The data are not redistributed; put them in `data/`:
- `oasis_cross-sectional.csv`: the OASIS-1 clinical table (https://sites.wustl.edu/oasisbrains/home/oasis-1/; Kaggle copy
  https://www.kaggle.com/datasets/jboysen/mri-and-alzheimers).
- `mri_embeddings_own.csv`: created by
  `python extract_mri_features.py <folder with extracted oasis_cross-sectional_disc1..12>`, which takes about 7 min on a CPU.
- `cohort_ids.csv`: the 166 analysed subject IDs (provided). These are the subjects that also had the third-party
  embedding used in the paper's leakage audit.

TabPFN downloads the openly available version-2 weights on first use. On some Anaconda installs on Windows, set
`KMP_DUPLICATE_LIB_OK=TRUE`.

## Run
```
python run_proposed.py --quick     # one outer fold (smoke test, ~2 min)
python run_proposed.py             # full evaluation, 25 outer folds (~45-60 min CPU)
python predict_new.py new.csv      # predictions for new subjects
```

## Expected result (25 outer folds, N = 166: 85 CDR = 0, 81 CDR > 0)
| Metric | Mean ± SD |
|---|---|
| MCC | 0.635 ± 0.103 |
| Balanced accuracy | 0.812 ± 0.050 |
| Macro-F1 | 0.812 ± 0.050 |
| ROC-AUC | 0.887 ± 0.053 |
| PR-AUC | 0.905 ± 0.044 |
| Brier | 0.135 |

The quick run (seed 42, fold 1) gives MCC 0.652, AUC 0.924 and k = 8.

Replacing `mri_embeddings_own.csv` with the third-party Kaggle embeddings reproduces the leakage audit, giving MCC 0.868
and AUC 0.984. Those inflated values should not be used as evidence.
