"""Part 09 - GCN / GAT on population graphs (transductive: test nodes present in the graph,
test labels never used). Graph type, K and weight decay are tuned per outer fold by inner CV.
Key comparison: GNN vs classical PCA fusion (Part 07) on the identical 25 folds."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch

import config
from common import (PhaseRun, binary_metrics, check_oof_integrity, embedding_cols, inner_splits,
                    iter_outer_folds, load_cohort, summarize)
from gnn import FIXED, GNN_GRID, evaluate_split, tune

PART07 = config.OUTPUT_DIR / "part07_fusion" / "fold_metrics.csv"
ARCHS = ["GCN", "GAT"]

with PhaseRun("part09_gnn", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PART07],
              params={"grid": GNN_GRID, "fixed": FIXED, "mode": "transductive",
                      "torch": torch.__version__}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    y = df[config.TARGET_COL].to_numpy()
    metric_rows, pred_rows, sel_rows, inner_rows = [], [], [], []
    curve = None
    for seed, fold, tr, te in iter_outer_folds(df):
        inner = inner_splits(df, seed, fold, tr)
        for arch in ARCHS:
            best, table = tune(arch, df, emb, y, tr, inner, seed)
            inner_rows += [{**r, "arch": arch, "seed": seed, "fold": fold} for r in table]
            if seed == 42 and fold == 1 and arch == "GCN":
                prob, curve = evaluate_split(arch, df, emb, y, tr, te, best, seed * 10 + fold, return_curve=True)
            else:
                prob = evaluate_split(arch, df, emb, y, tr, te, best, seed * 10 + fold)
            pred = (prob >= config.DECISION_THRESHOLD).astype(int)
            m = binary_metrics(y[te], pred, prob)
            m.update({"group": "GNN_transductive", "model": arch, "seed": seed, "fold": fold,
                      "graph": best["graph"], "k": best["k"], "weight_decay": best["weight_decay"],
                      "inner_cv_score": max(r["inner_auc"] for r in table)})
            metric_rows.append(m)
            sel_rows.append({"arch": arch, "seed": seed, "fold": fold, **best})
            pred_rows += [{"group": "GNN_transductive", "model": arch, "seed": seed, "fold": fold,
                           "subject_id": df.subject_id.iloc[i], "y_true": int(y[i]),
                           "y_prob": float(p), "y_pred": int(q)} for i, p, q in zip(te, prob, pred)]
        print(f"  seed {seed} fold {fold} done")

    folds = pd.DataFrame(metric_rows)
    preds = pd.DataFrame(pred_rows)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(pd.DataFrame(sel_rows), "selected_configs.csv")
    run.save_csv(pd.DataFrame(inner_rows), "inner_cv_scores.csv")
    summary = summarize(folds)
    run.save_csv(summary, "summary.csv")
    print("\nGNN transductive (mean ± SD, 25 folds):\n",
          summary[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))
    freq = pd.DataFrame(sel_rows).groupby(["arch", "graph", "k"]).size().rename("n_folds").reset_index()
    run.save_csv(freq, "selected_config_frequency.csv")
    print("\nSelected graph/K frequency:\n", freq.to_string(index=False))

    # ---------------- paired comparison with classical PCA fusion (Part 07)
    p7 = pd.read_csv(PART07)
    fus = p7[p7.group == "Fusion_PCA_nested"]
    best_classical = fus.groupby("model").mcc.mean().idxmax()
    rows = []
    for arch in ARCHS:
        G = folds[folds.model == arch].set_index(["seed", "fold"])
        for cname in sorted({best_classical, "LR"}):
            C = fus[fus.model == cname].set_index(["seed", "fold"])
            for m in ["balanced_accuracy", "macro_f1", "mcc", "roc_auc", "pr_auc", "brier"]:
                d = (G[m] - C[m]).to_numpy()
                boot = np.random.default_rng(0).choice(d, (5000, len(d))).mean(1)
                rows.append({"comparison": f"{arch} - Fusion_PCA_{cname}", "metric": m,
                             "mean_gnn": G[m].mean(), "mean_classical": C[m].mean(), "mean_delta": d.mean(),
                             "ci95_low": np.percentile(boot, 2.5), "ci95_high": np.percentile(boot, 97.5),
                             "folds_gnn_better": int((d > 0).sum()), "n_folds": len(d)})
    comp = pd.DataFrame(rows)
    run.save_csv(comp, "gnn_vs_classical_fusion.csv")
    print(f"\nGNN vs classical PCA fusion (best classical by mean MCC = {best_classical}):")
    print(comp[comp.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))

    checks = pd.DataFrame([
        ("25 outer folds per architecture", bool((folds.groupby("model").size() == 25).all())),
        ("each subject predicted once per seed", check_oof_integrity(preds, df)),
        ("configs chosen by inner CV only (18 configs x 3 inner folds per outer fold)",
         len(inner_rows) == 25 * len(ARCHS) * 18),
    ], columns=["check", "passed"])
    print("\n", checks.to_string(index=False))
    run.save_csv(checks, "integrity_checks.csv")

    fig, ax = plt.subplots(figsize=(6, 3.6))
    ax.plot(curve)
    ax.set_xlabel("epoch"); ax.set_ylabel("training cross-entropy")
    ax.set_title("GCN training curve (seed 42, fold 1)")
    fig.tight_layout()
    run.save_fig(fig, "fig_gcn_training_curve.png")
    plt.close(fig)
