"""Part 52 - Amendment 11: v14 = v13 multi-view TabPFN probabilities with a decision threshold chosen per outer fold
by maximising MCC on inner out-of-fold predictions (frozen inner folds; components refitted on inner training
folds with the outer fold's k from Parts 30/36). Outer test data never influence the threshold. Resumable per fold."""
import re

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.decomposition import PCA
from sklearn.metrics import matthews_corrcoef
from threadpoolctl import threadpool_limits

import config
import tabpfn_retry  # noqa: F401
from common import PhaseRun, binary_metrics, embedding_cols, inner_splits, iter_outer_folds, load_cohort, summarize
from compare_tools import paired_table, tabpfn_spec

threadpool_limits(1, user_api="blas")          # morphometry PCA (5661 columns), as in Part 36
O = config.OUTPUT_DIR
P30, P36, P04, P51 = (O / "part30_own_mri_benchmark", O / "part36_morph_benchmark", O / "part04_clinical",
                      O / "part51_v13_multiview")
GRID = np.round(np.arange(0.30, 0.7001, 0.025), 3)
C5 = config.CLINICAL_FULL


def k_of(bp, model, seed, fold):
    v = bp[(bp.model == model) & (bp.seed == seed) & (bp.fold == fold)].prep__mri__pca.iloc[0]
    return int(re.search(r"n_components=(\d+)", v).group(1))


def best_threshold(y, p):
    scores = [(matthews_corrcoef(y, (p >= t).astype(int)), -abs(t - 0.5), t) for t in GRID]
    return max(scores)[2]


with PhaseRun("part52_v14_threshold", __file__,
              inputs=[config.COHORT_FILE, config.RAW_DIR / "mri_embeddings_own.csv", config.RAW_DIR / "mri_morph_own.csv",
                      config.FOLDS_FILE, config.INNER_FOLDS_FILE, P30 / "best_params.csv", P36 / "best_params.csv",
                      P51 / "oof_predictions.csv"], params={"threshold_grid": GRID.tolist()}) as run:
    base = load_cohort()
    own, morph = pd.read_csv(config.RAW_DIR / "mri_embeddings_own.csv"), pd.read_csv(config.RAW_DIR / "mri_morph_own.csv")
    df = base.drop(columns=embedding_cols(base)).merge(own, on="subject_id").merge(morph, on="subject_id")
    df = df.set_index("subject_id").loc[base.subject_id].reset_index()
    emb, mri_m = embedding_cols(df), [c for c in morph.columns if c != "subject_id"]
    y = df[config.TARGET_COL].to_numpy()
    bp30, bp36 = pd.read_csv(P30 / "best_params.csv"), pd.read_csv(P36 / "best_params.csv")
    spec_r = tabpfn_spec("v14", emb, C5)["pipeline"]
    spec_m = tabpfn_spec("v14", mri_m, C5)["pipeline"]
    v13 = pd.read_csv(P51 / "oof_predictions.csv")
    ck = run.dir / "_ckpt"; ck.mkdir(exist_ok=True)
    rows, thr = [], []
    for seed, fold, tr, te in iter_outer_folds(df):
        f = ck / f"s{seed}_f{fold}.npy"
        if f.exists():
            t = float(np.load(f))
        else:
            pipes = [(clone(spec_r).set_params(prep__mri__pca=PCA(n_components=k_of(bp30, "TabPFN_v2", seed, fold), random_state=42)), emb + C5),
                     (clone(spec_m).set_params(prep__mri__pca=PCA(n_components=k_of(bp36, "TabPFN_morph", seed, fold), random_state=42)), mri_m + C5)]
            oof = np.zeros(len(tr))
            for itr, iva in inner_splits(df, seed, fold, tr):
                ps = [clone(p).fit(df.iloc[tr[itr]][cols], y[tr[itr]]).predict_proba(df.iloc[tr[iva]][cols])[:, 1] for p, cols in pipes]
                oof[iva] = np.mean(ps, axis=0)
            t = best_threshold(y[tr], oof)
            np.save(f, t)
        g = v13[(v13.seed == seed) & (v13.fold == fold)]
        p, yt = g.y_prob.to_numpy(), g.y_true_r.to_numpy()
        rows.append({**binary_metrics(yt, (p >= t).astype(int), p), "group": "v14", "model": "v14_multiview_thr",
                     "seed": seed, "fold": fold})
        thr.append({"seed": seed, "fold": fold, "threshold": t})
        print(f"  seed {seed} fold {fold}: threshold {t:.3f}", flush=True)
    v14 = pd.DataFrame(rows)
    run.save_csv(v14, "fold_metrics.csv"); run.save_csv(pd.DataFrame(thr), "thresholds.csv")
    summ = summarize(v14); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "mcc", "roc_auc", "brier", "sensitivity", "specificity"]].to_string(index=False), flush=True)

    f30, f04 = pd.read_csv(P30 / "fold_metrics.csv"), pd.read_csv(P04 / "fold_metrics.csv")
    clin = f04[f04.group == "C5_clinical_full"]
    primary = paired_table(v14, "v14", {
        "Fusion_PCA_RF": f30[f30.model == "Fusion_PCA_RF"], "Fusion_PCA_LR": f30[f30.model == "Fusion_PCA_LR"],
        "Fusion_PCA_XGBoost": f30[f30.model == "Fusion_PCA_XGBoost"], "Clinical_C5_LR": clin[clin.model == "LR"],
        "Clinical_C5_XGBoost": clin[clin.model == "XGBoost"], "MRI_only_LR": f30[f30.model == "MRI_only_LR"]})
    secondary = paired_table(v14, "v14", {"v13_multiview": pd.read_csv(P51 / "fold_metrics.csv"),
                                          "TabPFN_v2": f30[f30.model == "TabPFN_v2"]})
    run.save_csv(primary, "v14_vs_baselines_primary.csv"); run.save_csv(secondary, "v14_vs_v13_secondary.csv")
    cols = ["comparator", "metric", "mean_ref", "mean_comp", "delta", "p_wilcoxon", "p_holm", "p_nb_holm"]
    print(primary[cols].round(4).to_string(index=False)); print(secondary[cols].round(4).to_string(index=False))
    mcc = primary[(primary.metric == "mcc") & (primary.comparator != "MRI_only_LR")]
    positive = bool((mcc.p_holm < 0.05).all())
    p_rf = primary.query("comparator == 'Fusion_PCA_RF' and metric == 'mcc'").p_wilcoxon.iloc[0]
    print(f"PRE-REGISTERED RULE (MCC p_Holm < 0.05 vs every fusion and clinical baseline): {'POSITIVE' if positive else 'NOT POSITIVE'}")
    print(f"version check: unadjusted MCC p vs fusion RF = {p_rf:.4f} (threshold 0.05/14 = 0.0036)")
