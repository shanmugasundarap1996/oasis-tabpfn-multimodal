"""Part 19 v1 - Stacked late fusion (modality experts + meta-learner).

Experts (each sees only its own modality / representation):
  E1 MRI expert       : MRI PCA-8  -> logistic regression
  E2 clinical expert  : C5 clinical -> XGBoost
  E3 fusion expert    : MRI PCA-16 + C5 -> random forest
Meta-learner: logistic regression on the experts' cross-fitted probabilities
(StackingClassifier, internal 5-fold CV inside the outer training set, so the meta-learner
never sees an expert's in-sample predictions). Meta C and passthrough tuned on inner folds.
"""
import json

import pandas as pd
from sklearn.ensemble import StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from models import build
from newmethods import BASELINE_FILE, PROTOCOL_FILE, compare

with PhaseRun("part19_v1_stacking", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"experts": ["MRI PCA-8 LR", "C5 XGBoost", "PCA-16 fusion RF"],
                      "meta": "LR", "stack_cv": "StratifiedKFold(5) inside outer training set"}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    feats = emb + config.CLINICAL_FULL

    e_mri, _ = build("LR", mri_cols=emb, pca_dim=8)
    e_mri.set_params(clf__C=0.1)
    e_clin, _ = build("XGBoost", tab_cols=config.CLINICAL_FULL)
    e_clin.set_params(clf__max_depth=2, clf__n_estimators=300, clf__learning_rate=0.03)
    e_fus, _ = build("RF", mri_cols=emb, tab_cols=config.CLINICAL_FULL, pca_dim=16)
    e_fus.set_params(clf__max_depth=5, clf__min_samples_leaf=3)

    stack = StackingClassifier(
        estimators=[("mri", e_mri), ("clin", e_clin), ("fusion", e_fus)],
        final_estimator=LogisticRegression(max_iter=5000, class_weight="balanced"),
        cv=StratifiedKFold(5, shuffle=True, random_state=0), stack_method="predict_proba", n_jobs=1)
    spec = [{"group": "v1_stacking", "name": "Stack_LR_meta", "features": feats, "pipeline": stack,
             "grid": {"final_estimator__C": [0.1, 1, 10]}}]

    folds, preds, params = run_nested_cv(df, spec)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summary = summarize(folds)
    run.save_csv(summary, "summary.csv")
    print(summary[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))

    table, verdict = compare(folds, "v1_stacking")
    run.save_csv(table, "comparison_vs_baseline.csv")
    run.save_json(verdict, "verdict.json")
    print("\n", table[table.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))
    print("\nVERDICT:", json.dumps(verdict, indent=2, default=str))
    assert check_oof_integrity(preds, df)
