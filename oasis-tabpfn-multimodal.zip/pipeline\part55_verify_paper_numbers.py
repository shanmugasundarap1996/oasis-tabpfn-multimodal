"""Part 55 - verify every reported number in the final manuscript (main9.tex, MIND-AD) against the saved result files.
For each claim the value is recomputed/read from its source file, formatted as printed, and searched for in the LaTeX
source. Table I is recomputed from the raw cohort file. Output: outputs/part55_verify_paper_numbers/verification.csv
(claim, source, expected text, found) and a summary. Read-only: no model is run."""
import re
import sys

import numpy as np
import pandas as pd
from scipy import stats

import config
from common import PhaseRun

O = config.OUTPUT_DIR
TEX = config.BASE_DIR / "jbhi_multimodel_fussion" / (sys.argv[1] if len(sys.argv) > 1 else "main9_jbhi") / \
    (sys.argv[2] if len(sys.argv) > 2 else "main9.tex")
tex = TEX.read_text(encoding="utf-8")
flat = re.sub(r"\s+", " ", tex)
rows = []


def f3(x):
    return f"{x:.3f}"


def check(claim, source, expected, value=None):
    rows.append({"claim": claim, "source": source, "expected_text": expected, "value": value,
                 "found_in_paper": expected in flat})


def S(path, model, group=None):
    d = pd.read_csv(O / path)
    if group:
        d = d[d.group == group]
    return d[d.model == model].iloc[0]


def P(path, comp, metric, col="p_holm", ref=None):
    d = pd.read_csv(O / path)
    d = d[(d.comparator == comp) & (d.metric == metric)]
    return float(d[col].iloc[0]) if ref is None else float(d[d.reference == ref][col].iloc[0])


def pm(r, m):
    return f"{r[m + '_mean']:.3f} $\\pm$ {r[m + '_sd']:.3f}"


with PhaseRun("part55_verify_paper_numbers", __file__, inputs=[TEX]) as run:
    # ---------------- Table I recomputed from the raw cohort
    c = pd.read_csv(O / "phase02_cohort" / "cohort_primary_age60.csv")
    g0, g1 = c[c.target_binary == 0], c[c.target_binary == 1]
    check("Table I N", "cohort_primary_age60.csv", f"N & {len(g0)} & {len(g1)} &")
    for var, lab, d in [("Age", "Age (years)", 1), ("Educ", "Education (1--5)", 2), ("SES", "SES (1--5)", 2),
                        ("MMSE", "MMSE", 1), ("eTIV", "eTIV (cm$^3$)", 0), ("nWBV", "nWBV", 2), ("ASF", "ASF", 2)]:
        a, b = g0[var].dropna(), g1[var].dropna()
        p = stats.mannwhitneyu(a, b).pvalue
        ps = "$<$0.001" if p < 0.001 else f"{p:.3f}"
        fmt = (lambda v: f"{v:.{d}f}")
        check(f"Table I {var}", "cohort_primary_age60.csv",
              f"{lab} & {fmt(a.mean())} $\\pm$ {fmt(a.std())} & {fmt(b.mean())} $\\pm$ {fmt(b.std())} & {ps}")
    fem0, fem1 = (g0["M/F"] == "F").sum(), (g1["M/F"] == "F").sum()
    chi = stats.chi2_contingency(pd.crosstab(c.target_binary, c["M/F"]))[1]
    check("Table I female", "cohort_primary_age60.csv",
          f"Female, n (\\%) & {fem0} ({100 * fem0 / len(g0):.1f}) & {fem1} ({100 * fem1 / len(g1):.1f}) & {chi:.3f}")
    check("Table I SES missing", "cohort_primary_age60.csv",
          f"SES missing for {c.SES.isna().sum()} subjects ({g1.SES.isna().sum()} with CDR $>0$)")
    check("cohort CDR 0.5 / >=1", "cohort_primary_age60.csv",
          f"{(c.CDR == 0.5).sum()} with CDR 0.5, {(c.CDR >= 1).sum()} with CDR $\\geq 1$")

    # ---------------- Table II (mean +- SD over 25 folds)
    t2 = [("C4 (no MMSE) -- LR", "part04_clinical/summary.csv", "LR", "C4_clinical_no_MMSE"),
          ("C5 (full) -- LR", "part04_clinical/summary.csv", "LR", "C5_clinical_full"),
          ("C5 (full) -- XGBoost", "part04_clinical/summary.csv", "XGBoost", "C5_clinical_full"),
          ("C5 (full) -- TabPFN", "part31_own_mri_extended/ablation_summary.csv", "TabPFN_clinical_only", None),
          ("Study-label-free -- LR", "part30_own_mri_benchmark/summary.csv", "MRI_only_LR", None),
          ("Study-label-free -- TabPFN", "part31_own_mri_extended/ablation_summary.csv", "TabPFN_MRI_only", None),
          ("PCA -- LR", "part30_own_mri_benchmark/summary.csv", "Fusion_PCA_LR", None),
          ("PCA -- RF", "part30_own_mri_benchmark/summary.csv", "Fusion_PCA_RF", None),
          ("PCA -- RF (isotonic)", "part33_own_modern_and_recal/summary.csv", "Fusion_PCA_RF_isotonic", None),
          ("PCA -- XGBoost", "part30_own_mri_benchmark/summary.csv", "Fusion_PCA_XGBoost", None),
          ("PCA -- CatBoost", "part33_own_modern_and_recal/summary.csv", "Fusion_PCA_CatBoost", None),
          ("PCA -- LightGBM", "part33_own_modern_and_recal/summary.csv", "Fusion_PCA_LightGBM", None),
          ("Transportable", "part30_own_mri_benchmark/summary.csv", "TabPFN_transportable", None),
          ("Full (8 clinical + MRI)", "part30_own_mri_benchmark/summary.csv", "TabPFN_v2", None),
          ("Multi-view", "part51_v13_multiview/summary.csv", "v13_multiview", None)]
    for lab, path, model, group in t2:
        r = S(path, model, group)
        cells = [pm(r, m) for m in ("balanced_accuracy", "macro_f1", "mcc", "roc_auc", "pr_auc")] + [f3(r["brier_mean"])]
        line = next((l for l in tex.splitlines() if re.search(r"[ {]" + re.escape(lab) + r"(\}|\$\^| &)", l) and "$\\pm$" in l), "")
        plain = re.sub(r"\\textbf\{([^}]*)\}", r"\1", line)
        for m, cell in zip(("BA", "F1", "MCC", "AUC", "PR-AUC", "Brier"), cells):
            rows.append({"claim": f"Table II {lab} {m}", "source": path, "expected_text": cell, "value": None,
                         "found_in_paper": cell in plain})
    v2 = S("part30_own_mri_benchmark/summary.csv", "TabPFN_v2")
    check("Table II note sens/spec/ECE", "part30 summary",
          f"sensitivity {f3(v2.sensitivity_mean)}, specificity {f3(v2.specificity_mean)}, ECE {f3(v2.ece_mean)}")

    # ---------------- Table III (MIND-AD vs baselines, primary analysis)
    T3 = "part30_own_mri_benchmark/tabpfn_vs_baselines_own.csv"
    lab3 = {"Fusion_PCA_LR": "Fusion -- LR", "Fusion_PCA_RF": "Fusion -- RF", "Fusion_PCA_XGBoost": "Fusion -- XGBoost",
            "Clinical_C5_LR": "Clinical -- LR", "Clinical_C5_XGBoost": "Clinical -- XGBoost",
            "MRI_only_LR": "MRI only -- LR", "TabPFN_transportable": "MIND-AD transportable"}

    def pf(p, dig=3):
        return "$<$0.001" if p < 0.001 else f"{p:.{dig}f}"

    def ph(p):
        return "$<$0.001" if p < 0.001 else f"{p:.2f}"

    def sd(d):
        return f"+{d:.3f}" if d >= 0 else f"$-${abs(d):.3f}"

    for comp, lab in lab3.items():
        cells = []
        for m in ("mcc", "roc_auc"):
            cells += [sd(P(T3, comp, m, "delta")), pf(P(T3, comp, m, "p_wilcoxon")), ph(P(T3, comp, m))]
        check(f"Table III {lab}", T3, f"{lab} & " + " & ".join(cells) + " \\\\")

    # ---------------- Table IV
    for lab, model, path, group in [("TabPFN, MRI $+$ NI", "TabPFN_MRI_NI", "part39_clinical_sensitivity/summary.csv", None),
                                    ("TabPFN, NI", "TabPFN_NI", "part39_clinical_sensitivity/summary.csv", None),
                                    ("LR, NI", "LR_NI", "part39_clinical_sensitivity/summary.csv", None),
                                    ("XGBoost, NI", "XGBoost_NI", "part39_clinical_sensitivity/summary.csv", None),
                                    ("TabPFN, MRI $+$ demographics", "TabPFN_MRI_DEMO", "part39_clinical_sensitivity/summary.csv", None),
                                    ("TabPFN, demographics", "TabPFN_DEMO", "part39_clinical_sensitivity/summary.csv", None),
                                    ("MIND-AD", "TabPFN_v2", "part40_full_cohort/summary.csv", None),
                                    ("TabPFN, clinical only", "TabPFN_clinical_only", "part40_full_cohort/summary.csv", None),
                                    ("Clinical -- LR", "Clinical_C5_LR", "part40_full_cohort/summary.csv", None),
                                    ("Fusion -- LR", "Fusion_PCA_LR", "part40_full_cohort/summary.csv", None),
                                    ("Fusion -- XGBoost", "Fusion_PCA_XGBoost", "part40_full_cohort/summary.csv", None)]:
        r = S(path, model, group)
        vals = [f3(r.mcc_mean), f3(r.roc_auc_mean), f3(r.brier_mean)]
        tline = [l for l in tex.splitlines() if l.strip().startswith(lab + " &")]
        plain = re.sub(r"\\textbf\{([^}]*)\}|\$\^\{\\ast\}\$", lambda mm: mm.group(1) or "", " ".join(tline))
        for m, v in zip(("MCC", "AUC", "Brier"), vals):
            rows.append({"claim": f"Table IV {lab} {m}", "source": path, "expected_text": v, "value": None,
                         "found_in_paper": v in plain})
    ext = pd.read_csv(O / "part48_external_oasis2/metrics_label_cdr_overlap-screened.csv").set_index("model")
    for lab, model in [("MIND-AD, transportable", "multimodal_transportable_TabPFN"),
                       ("TabPFN, same clinical inputs only", "clinical_transportable_TabPFN"),
                       ("Fusion -- LR", "fusion_transportable_LR"), ("Fusion -- XGBoost", "fusion_transportable_XGBoost"),
                       ("MRI only -- TabPFN", "mri_only_TabPFN")]:
        r = ext.loc[model]
        tline = " ".join(l for l in tex.splitlines() if lab + "}" in l or l.strip().startswith(lab + " &") or ("{" + lab) in l)
        plain = re.sub(r"\\textbf\{([^}]*)\}", r"\1", tline)
        for m, v in zip(("MCC", "AUC", "Brier"), [f3(r.mcc), f3(r.roc_auc), f3(r.brier)]):
            rows.append({"claim": f"Table IV external {lab} {m}", "source": "part48 metrics", "expected_text": v,
                         "value": None, "found_in_paper": v in plain})

    # ---------------- text claims
    t = ext.loc["multimodal_transportable_TabPFN"]
    check("external AUC CI", "part48", f"AUC 0.862 [{t.roc_auc_lo:.2f}, {t.roc_auc_hi:.2f}]")
    check("external abstract AUC", "part48", f"AUC {t.roc_auc:.2f} [{t.roc_auc_lo:.2f}, {t.roc_auc_hi:.2f}]")
    for name, v in [("MCC", t.mcc), ("balanced accuracy", t.balanced_accuracy), ("Brier", t.brier),
                    ("specificity", t.specificity), ("sensitivity", t.sensitivity)]:
        check(f"external {name}", "part48", f"{name} {f3(v)}")
    check("external slope", "part48", f"calibration slope {t.cal_slope:.2f}")
    w = pd.read_csv(O / "part53b_external_without_flagged/metrics_without_flagged.csv").set_index("model").loc["multimodal_transportable_TabPFN"]
    check("external without flagged", "part53b",
          f"AUC {f3(w.roc_auc)} [{w.roc_auc_lo:.2f}, {w.roc_auc_hi:.2f}], Brier {f3(w.brier)}, slope {w.cal_slope:.2f}")
    a = pd.read_csv(O / "part53_overlap_image_audit_full/summary.csv").iloc[0]
    au = pd.read_csv(O / "part53_overlap_image_audit_full/external_image_audit.csv")
    check("image audit threshold", "part53", f"threshold {a.threshold:.3f}")
    check("image audit flagged r", "part53", f"$r={au.max_corr.max():.3f}$; second best {au.sort_values('max_corr').iloc[-1].second_corr:.3f}")
    nf = au[~au.image_flagged]
    check("image audit unflagged range", "part53", f"maximum $r$ {nf.max_corr.min():.2f}--{nf.max_corr.max():.2f}")
    h = pd.read_csv(O / "part50_h_fidelity/summary.csv").set_index("model")
    check("harmonized internal AUC", "part50", f"AUC {f3(h.loc['TabPFN_transportable_H'].roc_auc_mean)} vs {f3(S('part30_own_mri_benchmark/summary.csv', 'TabPFN_transportable').roc_auc_mean)}")
    check("harmonized MRI-only AUC (limitations)", "part50",
          f"MRI-only AUC {h.loc['MRI_only_LR_H'].roc_auc_mean:.2f} vs {S('part30_own_mri_benchmark/summary.csv', 'MRI_only_LR').roc_auc_mean:.2f}")
    sub = pd.read_csv(O / "part48_external_oasis2/subgroups_label_cdr_overlap-screened.csv").set_index("subgroup")
    check("external sex AUC", "part48 subgroups", f"AUC {f3(sub.loc['female'].roc_auc)} in women vs {f3(sub.loc['male'].roc_auc)} in men")
    cs = pd.read_csv(O / "part41_importance_calibration/calibration_slope.csv").set_index("model")
    check("calibration slope", "part41", f"{cs.loc['TabPFN_v2'].calibration_slope:.2f} (SD {cs.loc['TabPFN_v2'].slope_sd_over_seeds:.2f}; calibration-in-the-large {cs.loc['TabPFN_v2'].calibration_in_the_large:.3f})")
    for lab, m in [("fusion LR", "Fusion_PCA_LR"), ("CatBoost", "Fusion_PCA_CatBoost"), ("LightGBM", "Fusion_PCA_LightGBM"),
                   ("isotonic RF", "Fusion_PCA_RF_isotonic"), ("fusion RF", "Fusion_PCA_RF"), ("fusion XGBoost", "Fusion_PCA_XGBoost")]:
        check(f"slope {lab}", "part41", (f"{lab} ({cs.loc[m].calibration_slope:.2f})" if m == "Fusion_PCA_XGBoost" else f"{lab} {cs.loc[m].calibration_slope:.2f}"))
    gap = pd.read_csv(O / "part34_sex_gap_bootstrap/subgroup_gap_bootstrap.csv")
    gs = gap[(gap.model == "TabPFN_v2") & (gap.variable == "sex") & (gap.metric == "roc_auc")].iloc[0]
    check("sex gap", "part34", f"difference {f3(gs.delta)}, 95\\% CI [{f3(gs.ci95_low)}, {f3(gs.ci95_high)}]")
    gr = gap[(gap.model == "Fusion_PCA_RF") & (gap.variable == "sex") & (gap.metric == "roc_auc")].iloc[0]
    check("sex gap RF", "part34", f"{f3(gr.delta)} [{f3(gr.ci95_low)}, {f3(gr.ci95_high)}]")
    sg = pd.read_csv(O / "part41_importance_calibration/subgroup_calibration.csv")
    row = sg[sg.sex.str.contains("gap")].iloc[0]
    check("sex gap CDR 0 vs 0.5", "part41", f"difference {f3(row.calibration_slope)} [{f3(row.gap_ci_low)}, {f3(row.gap_ci_high)}]")
    check("men slope", "part41", f"calibration slope {sg[sg.sex == 'male'].iloc[0].calibration_slope:.2f}")
    imp = pd.read_csv(O / "part41_importance_calibration/permutation_importance.csv").set_index("block")
    check("importance MMSE", "part41", f"AUC drop {f3(imp.loc['MMSE'].delta_auc_mean)}")
    check("importance MRI", "part41", f"({f3(imp.loc['MRI (512-D, PCA)'].delta_auc_mean)}; drop in {int(imp.loc['MRI (512-D, PCA)'].folds_auc_drop_gt0)} of 10 folds)")
    ab = "part31_own_mri_extended/ablation_vs_full.csv"
    check("MRI over clinical MCC", ab, f"$+{P(ab, 'TabPFN_clinical_only', 'mcc', 'delta'):.3f}$, 95\\% CI [{P(ab, 'TabPFN_clinical_only', 'mcc', 'ci95_low'):.3f}, {P(ab, 'TabPFN_clinical_only', 'mcc', 'ci95_high'):.3f}], within-family $p_{{\\mathrm{{Holm}}}}={P(ab, 'TabPFN_clinical_only', 'mcc'):.3f}$")
    am = pd.read_csv(O / "part31_own_mri_extended/ablation_summary.csv").set_index("model")
    check("MRI+MMSE MCC", "part31", f"(MCC {f3(am.loc['TabPFN_MRI_MMSE'].mcc_mean)})")
    m1 = "part39_clinical_sensitivity/M1_mri_beyond_nonimaging.csv"
    check("NI vs LR MCC", m1, f"MCC $+{P(m1, 'LR_NI', 'mcc', 'delta'):.3f}$ [{P(m1, 'LR_NI', 'mcc', 'ci95_low'):.3f}, {P(m1, 'LR_NI', 'mcc', 'ci95_high'):.3f}], $p_{{\\mathrm{{Holm}}}}={P(m1, 'LR_NI', 'mcc'):.3f}$")
    check("NI vs XGB MCC", m1, f"MCC $+{P(m1, 'XGBoost_NI', 'mcc', 'delta'):.3f}$ [{P(m1, 'XGBoost_NI', 'mcc', 'ci95_low'):.3f}, {P(m1, 'XGBoost_NI', 'mcc', 'ci95_high'):.3f}], $p_{{\\mathrm{{Holm}}}}={P(m1, 'XGBoost_NI', 'mcc'):.3f}$")
    check("NI Brier vs TabPFN NI", m1, f"$p_{{\\mathrm{{Holm}}}}={P(m1, 'TabPFN_NI', 'brier'):.3f}$")
    cd = pd.read_csv(O / "part31_own_mri_extended/cdr05_summary.csv").set_index("model")
    check("CDR0.5 MIND-AD", "part31 cdr05", f"MCC {f3(cd.loc['TabPFN_v2'].mcc_mean)}, balanced accuracy {f3(cd.loc['TabPFN_v2'].balanced_accuracy_mean)} and AUC {f3(cd.loc['TabPFN_v2'].roc_auc_mean)}")
    check("CDR0.5 p", "part31", f"$p_{{\\mathrm{{Holm}}}}={P('part31_own_mri_extended/cdr05_tabpfn_vs_baselines.csv', 'Fusion_PCA_RF', 'roc_auc'):.3f}$")
    mo = pd.read_csv(O / "part36_morph_benchmark/summary.csv").set_index("model")
    check("morph MIND-AD", "part36", f"MCC {f3(mo.loc['TabPFN_morph'].mcc_mean)}, AUC {f3(mo.loc['TabPFN_morph'].roc_auc_mean)} and Brier {f3(mo.loc['TabPFN_morph'].brier_mean)}")
    check("morph fusion RF", "part36", f"(MCC {f3(mo.loc['Fusion_PCA_RF_morph'].mcc_mean)}, AUC {f3(mo.loc['Fusion_PCA_RF_morph'].roc_auc_mean)}, Brier {f3(mo.loc['Fusion_PCA_RF_morph'].brier_mean)})")
    v13 = "part51_v13_multiview/v13_vs_baselines_primary.csv"
    check("multi-view AUC vs RF", v13, f"$p_{{\\mathrm{{Holm}}}}={P(v13, 'Fusion_PCA_RF', 'roc_auc'):.3f}$")
    check("multi-view AUC vs LR", v13, f"$p_{{\\mathrm{{Holm}}}}={P(v13, 'Fusion_PCA_LR', 'roc_auc'):.3f}$")
    check("multi-view AUC vs XGB", v13, f"$p_{{\\mathrm{{Holm}}}}={P(v13, 'Fusion_PCA_XGBoost', 'roc_auc'):.3f}$")
    m33 = "part33_own_modern_and_recal/tabpfn_vs_modern_recal_own.csv"
    check("AUC vs LightGBM", m33, f"$+{P(m33, 'Fusion_PCA_LightGBM', 'roc_auc', 'delta'):.3f}$, $p_{{\\mathrm{{Holm}}}}={P(m33, 'Fusion_PCA_LightGBM', 'roc_auc'):.3f}$")
    f40 = "part40_full_cohort/tabpfn_vs_baselines_full.csv"
    check("N198 AUC vs LR", f40, f"$+{P(f40, 'Fusion_PCA_LR', 'roc_auc', 'delta'):.3f}$, $p_{{\\mathrm{{Holm}}}}={P(f40, 'Fusion_PCA_LR', 'roc_auc'):.3f}$")
    check("N198 AUC vs XGB", f40, f"$+{P(f40, 'Fusion_PCA_XGBoost', 'roc_auc', 'delta'):.3f}$, $p_{{\\mathrm{{Holm}}}}={P(f40, 'Fusion_PCA_XGBoost', 'roc_auc'):.3f}$")
    sb = pd.read_csv(O / "part45_subject_bootstrap/subject_bootstrap.csv")
    lg = sb[(sb.comparator == "Fusion_PCA_LightGBM") & (sb.metric == "brier")].iloc[0]
    check("subject bootstrap LightGBM", "part45", f"$p_{{\\mathrm{{Holm}}}}={lg.p_holm:.3f}$")
    kg = pd.read_csv(O / "part30_own_mri_benchmark/own_vs_kaggle.csv")
    mk = kg[(kg.comparator == "TabPFN_v2 Kaggle")]
    check("audit MCC +0.23", "part30 own_vs_kaggle", f"MCC {abs(mk[mk.metric == 'mcc'].delta.iloc[0]):.2f}")
    ea = pd.read_csv(O / "part30_own_mri_benchmark/embedding_audit.csv").iloc[0]
    check("nWBV R2 own", "part30 embedding_audit", f"R^2=0.71$ versus {ea.nWBV_cv_r2:.2f}")
    ov = pd.read_csv(O / "part44_overlap_image_verification/overlap_summary.csv").set_index("item").n
    check("overlap counts", "part44", f"identical age in {ov['eTIV<0.5%: identical age']}, MMSE in {ov['eTIV<0.5%: identical MMSE']}, CDR in {ov['eTIV<0.5%: identical CDR']}")
    check("overlap categories", "part44", f"We classify {ov['probable (record linkage)']} as probable and {ov['possible (broad rule)']} as possible overlap")

    # ---------------- second batch: abstract, ranges, audit and remaining text values
    v13s = S("part51_v13_multiview/summary.csv", "v13_multiview")
    check("abstract metrics", "part30", f"balanced accuracy {f3(v2.balanced_accuracy_mean)}, macro-F1 {f3(v2.macro_f1_mean)}, Matthews correlation coefficient {f3(v2.mcc_mean)}, area under the receiver operating characteristic curve {f3(v2.roc_auc_mean)}, and Brier score {f3(v2.brier_mean)}")
    check("abstract external AUC", "part48", f"area under the curve {t.roc_auc:.3f} (95\\% confidence interval {t.roc_auc_lo:.2f}--{t.roc_auc_hi:.2f})")
    check("abstract overlap 83/150", "part44", f"overlap for {ov['probable (record linkage)']} of 150 OASIS-2 participants")
    check("multi-view BA/PR-AUC/Brier in text", "part51", f"balanced accuracy ({f3(v13s.balanced_accuracy_mean)}) and PR-AUC ({f3(v13s.pr_auc_mean)}) and, with the transportable configuration, the lowest Brier score ({f3(v13s.brier_mean)})")
    fus = [S("part30_own_mri_benchmark/summary.csv", m) for m in ("Fusion_PCA_LR", "Fusion_PCA_RF", "Fusion_PCA_XGBoost")] + \
          [S("part33_own_modern_and_recal/summary.csv", m) for m in ("Fusion_PCA_CatBoost", "Fusion_PCA_LightGBM", "Fusion_PCA_RF_isotonic")]
    check("fusion MCC/AUC ranges", "part30/33", f"fusion MCC {min(r.mcc_mean for r in fus):.2f}--{max(r.mcc_mean for r in fus):.2f}, AUC {min(r.roc_auc_mean for r in fus):.2f}--{max(r.roc_auc_mean for r in fus):.2f}")
    cl = [S("part04_clinical/summary.csv", m, "C5_clinical_full") for m in ("LR", "XGBoost")] + [S("part31_own_mri_extended/ablation_summary.csv", "TabPFN_clinical_only")]
    check("clinical MCC/AUC ranges", "part04/31", f"Clinical variables alone reached MCC {min(r.mcc_mean for r in cl):.2f}--{max(r.mcc_mean for r in cl):.2f} and AUC {min(r.roc_auc_mean for r in cl):.2f}--{max(r.roc_auc_mean for r in cl):.2f}")
    check("without MMSE MCC", "part04", f"without MMSE, MCC fell to {S('part04_clinical/summary.csv', 'LR', 'C4_clinical_no_MMSE').mcc_mean:.2f}")
    check("MRI-only AUC / nWBV R2 / perm p", "part30", f"alone reached AUC {S('part30_own_mri_benchmark/summary.csv', 'MRI_only_LR').roc_auc_mean:.2f} (LR) and encoded atrophy strongly (cross-validated nWBV prediction $R^2={ea.nWBV_cv_r2:.2f}$; label-permutation $p={ea.p_value:.3f}$)")
    check("MRI-only TabPFN MCC", "part31", f"(MCC {f3(am.loc['TabPFN_MRI_only'].mcc_mean)}, $p_{{\\mathrm{{Holm}}}}<0.001$)")
    bri = {c_: P(T3, c_, "brier", "delta") for c_ in ("Fusion_PCA_RF", "Fusion_PCA_LR", "Fusion_PCA_XGBoost")}
    bri.update({c_: P(m33, c_, "brier", "delta") for c_ in ("Fusion_PCA_CatBoost", "Fusion_PCA_LightGBM", "Fusion_PCA_RF_isotonic")})
    check("Brier delta range", "part30/33", f"($-{abs(max(bri.values())):.3f}$ to $-{abs(min(bri.values())):.3f}$)")
    check("Brier p_Holm RF/LR/XGB", T3, f"$p_{{\\mathrm{{Holm}}}}\\le {math_ceil(max(P(T3, c_, 'brier') for c_ in ('Fusion_PCA_RF', 'Fusion_PCA_LR', 'Fusion_PCA_XGBoost'))):.3f}$" if False else
          f"$p_{{\\mathrm{{Holm}}}}\\le 0.01$")
    rows[-1]["value"] = max(P(T3, c_, "brier") for c_ in ("Fusion_PCA_RF", "Fusion_PCA_LR", "Fusion_PCA_XGBoost"))
    check("Brier p_Holm CatBoost/LightGBM/iso", m33, "$p_{\\mathrm{Holm}}\\le 0.031$")
    rows[-1]["value"] = max(P(m33, c_, "brier") for c_ in ("Fusion_PCA_CatBoost", "Fusion_PCA_LightGBM", "Fusion_PCA_RF_isotonic"))
    gh = pd.read_csv(O / "part41_importance_calibration/global_holm.csv")
    gb = gh[(gh.metric == "brier") & gh.comparator.isin(["Fusion_PCA_RF", "Fusion_PCA_LR", "Fusion_PCA_XGBoost", "Fusion_PCA_CatBoost", "Fusion_PCA_LightGBM"]) & gh.family.isin(["part30_main", "part33_modern"])]
    check("global Holm Brier <= 0.028", "part41 global_holm", "($p\\le 0.028$)"); rows[-1]["value"] = gb.p_holm_global.max()
    mccd = [P(T3, c_, "mcc", "delta") for c_ in ("Fusion_PCA_RF", "Fusion_PCA_LR", "Fusion_PCA_XGBoost", "Clinical_C5_LR", "Clinical_C5_XGBoost")]
    mccp = [P(T3, c_, "mcc") for c_ in ("Fusion_PCA_RF", "Fusion_PCA_LR", "Fusion_PCA_XGBoost", "Clinical_C5_LR", "Clinical_C5_XGBoost")]
    check("MCC delta range and p_Holm range", T3, f"($+{min(mccd):.3f}$ to $+{max(mccd):.3f}$; 95\\% intervals excluding zero; Holm-adjusted $p={min(mccp):.2f}$--${max(mccp):.2f}$)")
    check("MRI-only deltas", T3, f"(MCC $+{P(T3, 'MRI_only_LR', 'mcc', 'delta'):.3f}$, AUC $+{P(T3, 'MRI_only_LR', 'roc_auc', 'delta'):.3f}$")
    v13r = [P(v13, c_, "roc_auc", "delta") for c_ in ("Fusion_PCA_RF", "Fusion_PCA_LR", "Fusion_PCA_XGBoost")]
    check("multi-view AUC deltas", v13, f"fusion RF ($+{v13r[0]:.3f}$, $p_{{\\mathrm{{Holm}}}}={P(v13, 'Fusion_PCA_RF', 'roc_auc'):.3f}$), LR ($+{v13r[1]:.3f}$")
    check("multi-view Brier p", v13, "together with a lower Brier score ($p_{\\mathrm{Holm}}\\le 0.013$)"); rows[-1]["value"] = max(P(v13, c_, "brier") for c_ in ("Fusion_PCA_RF", "Fusion_PCA_LR", "Fusion_PCA_XGBoost"))
    kd = {m_: kg[(kg.comparator == f"{m_} Kaggle")] for m_ in ("MRI_only_LR", "TabPFN_v2")}
    check("audit MRI-only", "part30 own_vs_kaggle", f"MRI-only LR from {f3(kd['MRI_only_LR'][kd['MRI_only_LR'].metric == 'mcc'].mean_ref.iloc[0])}/{f3(kd['MRI_only_LR'][kd['MRI_only_LR'].metric == 'roc_auc'].mean_ref.iloc[0])} to {f3(kd['MRI_only_LR'][kd['MRI_only_LR'].metric == 'mcc'].mean_comp.iloc[0])}/{f3(kd['MRI_only_LR'][kd['MRI_only_LR'].metric == 'roc_auc'].mean_comp.iloc[0])}")
    check("audit MIND-AD", "part30 own_vs_kaggle", f"MIND-AD from {f3(kd['TabPFN_v2'][kd['TabPFN_v2'].metric == 'mcc'].mean_ref.iloc[0])}/{f3(kd['TabPFN_v2'][kd['TabPFN_v2'].metric == 'roc_auc'].mean_ref.iloc[0])} to {f3(kd['TabPFN_v2'][kd['TabPFN_v2'].metric == 'mcc'].mean_comp.iloc[0])}/{f3(kd['TabPFN_v2'][kd['TabPFN_v2'].metric == 'roc_auc'].mean_comp.iloc[0])}")
    check("audit NB p max", "part30 own_vs_kaggle", "Nadeau--Bengio $p\\le 0.012$)"); rows[-1]["value"] = kg.p_nb_holm.max()
    check("audit AUC delta 0.10", "part30 own_vs_kaggle", f"AUC {abs(mk[mk.metric == 'roc_auc'].delta.iloc[0]):.2f} higher")
    check("morph p range", "part36", f"$p_{{\\mathrm{{Holm}}}}={min(P('part36_morph_benchmark/v12_vs_baselines.csv', c_, 'roc_auc') for c_ in ('Fusion_PCA_RF_morph', 'Fusion_PCA_LR_morph', 'Fusion_PCA_XGBoost_morph')):.3f}$--${max(P('part36_morph_benchmark/v12_vs_baselines.csv', c_, 'roc_auc') for c_ in ('Fusion_PCA_RF_morph', 'Fusion_PCA_LR_morph', 'Fusion_PCA_XGBoost_morph')):.3f}$")
    check("N198 Brier vs XGB", f40, f"lower Brier than XGBoost ($p_{{\\mathrm{{Holm}}}}={P(f40, 'Fusion_PCA_XGBoost', 'brier'):.3f}$)")
    check("overlap 70 in training", "part42b pairs", "70 of them in our training cohort")
    pairs = pd.read_csv(O / "part42_external_clinical/overlap_diagnostic_pairs.csv")
    rows[-1]["value"] = int(pairs[pairs.d_etiv_pct < 0.5].in_train_cohort.sum())
    check("external clinical-only AUC", "part48", f"locked clinical-only TabPFN (AUC {f3(ext.loc['clinical_transportable_TabPFN'].roc_auc)})")
    check("external MRI-only range", "part48", f"(AUC {min(ext.loc['mri_only_TabPFN'].roc_auc, ext.loc['mri_only_LR'].roc_auc):.2f}--{max(ext.loc['mri_only_TabPFN'].roc_auc, ext.loc['mri_only_LR'].roc_auc):.2f})")
    check("CDR0.5 fusion AUCs", "part31 cdr05", f"fusion RF ({f3(cd.loc['Fusion_PCA_RF'].roc_auc_mean)}) and LR ({f3(cd.loc['Fusion_PCA_LR'].roc_auc_mean)}")
    bp = pd.read_csv(O / "part30_own_mri_benchmark/best_params.csv"); bp = bp[bp.model == "TabPFN_v2"].prep__mri__pca.str.extract(r"n_components=(\d+)")[0].value_counts()
    check("selected k counts", "part30 best_params", f"selected $k$: 8 in {bp['8']} folds, 24, 32 and 64 in {bp['24']} each, 16 in {bp['16']}")
    rows[-1]["value"] = bp.to_dict()

    bounds = {"Brier p_Holm RF/LR/XGB": 0.01, "Brier p_Holm CatBoost/LightGBM/iso": 0.031, "global Holm Brier <= 0.028": 0.028, "multi-view Brier p": 0.013, "audit NB p max": 0.012}
    for r_ in rows:
        if r_["claim"] in bounds:
            r_["found_in_paper"] = r_["found_in_paper"] and float(r_["value"]) <= bounds[r_["claim"]]
    res = pd.DataFrame(rows)
    run.save_csv(res, "verification.csv")
    bad = res[~res.found_in_paper]
    summ = pd.DataFrame([{"paper": str(TEX.name), "n_checks": len(res), "n_verified": int(res.found_in_paper.sum()),
                          "n_not_found": len(bad)}])
    run.save_csv(summ, "summary.csv")
    print(summ.to_string(index=False))
    if len(bad):
        print("NOT FOUND (check):"); print(bad[["claim", "expected_text"]].to_string(index=False))
