"""Evaluate the proposed framework with repeated nested cross-validation (5-fold x 5 seeds).

Usage:  python run_proposed.py            (all 25 outer folds, ~45-60 min on CPU)
        python run_proposed.py --quick    (first outer fold only, smoke test)

Writes outputs/fold_metrics.csv, outputs/oof_predictions.csv, outputs/summary.csv.
Resumable: finished folds are stored in outputs/folds/ and skipped on restart.
"""
import json
import sys
import time

import pandas as pd

import config
from data_prep import build_cohort, embedding_cols, inner_folds, outer_folds
from metrics import binary_metrics
from model import fit_with_inner_cv, selected_k


def main(quick=False):
    config.OUTPUT_DIR.mkdir(exist_ok=True)
    fold_dir = config.OUTPUT_DIR / "folds"
    fold_dir.mkdir(exist_ok=True)
    df = build_cohort()
    emb = embedding_cols(df)
    feats = emb + config.CLINICAL
    y = df[config.TARGET].to_numpy()
    print(f"cohort: {len(df)} subjects ({int((y == 0).sum())} CDR=0, {int((y == 1).sum())} CDR>0)")

    rows, preds = [], []
    for seed, fold, tr, te in outer_folds(df):
        ck = fold_dir / f"s{seed}_f{fold}.json"
        if ck.exists():
            d = json.loads(ck.read_text())
        else:
            t0 = time.time()
            gs = fit_with_inner_cv(df.iloc[tr][feats], y[tr], emb, inner_folds(df, seed, fold, tr))
            prob = gs.predict_proba(df.iloc[te][feats])[:, 1]
            pred = (prob >= config.THRESHOLD).astype(int)
            d = {"metrics": {**binary_metrics(y[te], pred, prob), "seed": seed, "fold": fold,
                             "k": selected_k(gs), "inner_auc": gs.best_score_},
                 "preds": [{"seed": seed, "fold": fold, "subject_id": df.subject_id.iloc[i],
                            "y_true": int(y[i]), "y_prob": float(p), "y_pred": int(q)}
                           for i, p, q in zip(te, prob, pred)]}
            ck.write_text(json.dumps(d, default=float))
            print(f"seed {seed} fold {fold}: MCC {d['metrics']['mcc']:.3f}  AUC {d['metrics']['roc_auc']:.3f}"
                  f"  k={d['metrics']['k']}  ({time.time() - t0:.0f}s)", flush=True)
        rows.append(d["metrics"])
        preds += d["preds"]
        if quick:
            break

    folds = pd.DataFrame(rows)
    folds.to_csv(config.OUTPUT_DIR / "fold_metrics.csv", index=False)
    pd.DataFrame(preds).to_csv(config.OUTPUT_DIR / "oof_predictions.csv", index=False)
    metrics = ["balanced_accuracy", "macro_f1", "mcc", "sensitivity", "specificity", "roc_auc",
               "pr_auc", "brier", "ece"]
    summary = pd.DataFrame({"mean": folds[metrics].mean(), "sd": folds[metrics].std(ddof=1)})
    summary.to_csv(config.OUTPUT_DIR / "summary.csv")
    print(f"\n{len(folds)} outer folds  (mean +- SD)\n", summary.round(4).to_string())
    print("\nselected k:", folds.k.value_counts().to_dict())


if __name__ == "__main__":
    main(quick="--quick" in sys.argv)
