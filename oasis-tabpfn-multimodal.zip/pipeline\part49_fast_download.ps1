# Part 49 (fast): stream the open OASIS-2 raw archives with curl | tar and keep only the RAW folders of the
# overlap-screened first-visit sessions (Part 42 rule). Writes oasis2_raw\_SUBSET_DONE.txt when both parts are done.
Set-Location '.'
$dest = '..\oasis2_raw'
$log = 'outputs\_runner\part49_fast.log'
$need = & 'python' -c "import pandas as pd; f=pd.read_csv(r'outputs\part42_external_clinical\overlap_flags.csv'); print(' '.join(s+'_MR1' for s in f.subject_id[f.n_candidates==0]))"
$sessions = $need -split ' '
Add-Content $log "$(Get-Date -Format s) sessions needed: $($sessions.Count)"
foreach ($part in 1, 2) {
    $marker = "$dest\_fast_PART$part.txt"
    if (Test-Path $marker) { continue }
    $inc = ($sessions | ForEach-Object { "--include `"*/$_/RAW/*`"" }) -join ' '
    $t0 = Get-Date
    Add-Content $log "$(Get-Date -Format s) streaming PART$part"
    cmd /c "curl.exe -L -s --retry 5 https://download.nrg.wustl.edu/data/OAS2_RAW_PART$part.tar.gz | tar -xzf - -C `"$dest`" $inc"
    Add-Content $log ("{0} PART{1} finished (exit {2}) in {3:N0} min" -f (Get-Date -Format s), $part, $LASTEXITCODE, ((Get-Date) - $t0).TotalMinutes)
    'done' | Set-Content $marker
}
$have = @($sessions | Where-Object { Get-ChildItem "$dest\OAS2_RAW_PART*\$_\RAW\mpr-*.nifti.img" -ErrorAction SilentlyContinue })
Add-Content $log "$(Get-Date -Format s) screened sessions on disk: $($have.Count) / $($sessions.Count)"
'done' | Set-Content "$dest\_SUBSET_DONE.txt"
