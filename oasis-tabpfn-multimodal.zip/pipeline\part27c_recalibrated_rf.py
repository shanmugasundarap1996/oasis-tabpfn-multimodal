"""Part 27c - Fair calibration comparison: fusion-RF recalibrated (isotonic and Platt/sigmoid)
inside each outer training set (CalibratedClassifierCV, internal 3-fold), hyperparameters and PCA k
tuned on the frozen inner folds; compared with the proposed TabPFN. Resumable per fold."""
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import StratifiedKFold

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from compare_tools import paired_table, pca_grid
from models import build

V5 = config.OUTPUT_DIR / "part19_v5_tabpfn" / "fold_metrics.csv"

with PhaseRun("part27c_recalibrated_rf", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, V5]) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    C5 = config.CLINICAL_FULL
    specs = []
    for method in ["isotonic", "sigmoid"]:
        rf, grid = build("RF", mri_cols=emb, tab_cols=C5, pca_dim=8, extra_grid=pca_grid())
        cal = CalibratedClassifierCV(rf, method=method, cv=StratifiedKFold(3, shuffle=True, random_state=0))
        specs.append({"group": "Fusion_PCA_nested", "name": f"RF_{method}", "features": emb + C5,
                      "pipeline": cal, "grid": {f"estimator__{k}": v for k, v in grid.items()}})
    folds, preds, params = run_nested_cv(df, specs, ckpt_dir=str(run.dir / "_ckpt"))
    run.save_csv(folds, "fold_metrics.csv"); run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summ = summarize(folds); run.save_csv(summ, "summary.csv")
    print(summ[["model", "mcc", "roc_auc", "brier", "ece", "logloss"]].to_string(index=False))
    ref = pd.read_csv(V5)
    tab = paired_table(ref, "TabPFN_v2", {m: folds[folds.model == m] for m in folds.model.unique()},
                       metrics=("mcc", "roc_auc", "brier", "ece"))
    run.save_csv(tab, "tabpfn_vs_recalibrated_rf.csv")
    print(tab.round(4).to_string(index=False))
    assert check_oof_integrity(preds, df)
