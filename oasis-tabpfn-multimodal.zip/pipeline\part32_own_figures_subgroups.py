"""Part 32 - Figures and subgroup analysis for the leakage-free (own) MRI features.

fig5_kaggle_vs_own.pdf   : per model, MCC and AUC with third-party (Kaggle) vs own label-free embeddings
fig6_own_roc_sig.pdf     : ROC/PR (pooled OOF) + paired-difference forest (TabPFN - baseline) on own features
fig7_own_calibration.pdf : reliability diagram on own features
subgroups                : sex and age-band performance of TabPFN and fusion-RF on own features
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.calibration import calibration_curve
from sklearn.metrics import auc, precision_recall_curve, roc_curve

import config
from common import PhaseRun, binary_metrics, load_cohort

OUT = config.OUTPUT_DIR
FIG = config.BASE_DIR / "paper" / "figures"
P30 = OUT / "part30_own_mri_benchmark"
plt.rcParams.update({"font.size": 8, "axes.titlesize": 9, "pdf.fonttype": 42})


def save(fig, name, run):
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"{name}.{ext}", dpi=300, bbox_inches="tight")
    run.save_fig(fig, f"{name}.png")
    plt.close(fig)


with PhaseRun("part32_own_figures_subgroups", __file__,
              inputs=[P30 / "fold_metrics.csv", P30 / "oof_predictions.csv", P30 / "tabpfn_vs_baselines_own.csv",
                      P30 / "own_vs_kaggle.csv"]) as run:
    FIG.mkdir(parents=True, exist_ok=True)
    kv = pd.read_csv(P30 / "own_vs_kaggle.csv")
    # ---------------- Fig 5: Kaggle vs own (dumbbell)
    names = {"TabPFN_v2": "TabPFN (proposed)", "Fusion_PCA_RF": "Fusion RF", "Fusion_PCA_LR": "Fusion LR",
             "MRI_only_LR": "MRI only (LR)"}
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.6), sharey=True)
    for ax, m, lab in [(axes[0], "mcc", "MCC"), (axes[1], "roc_auc", "ROC-AUC")]:
        s = kv[kv.metric == m].reset_index(drop=True)
        for i, r in s.iterrows():
            key = r.reference.replace(" own", "")
            ax.plot([r.mean_ref, r.mean_comp], [i, i], color="#9aa5b1", lw=2, zorder=1)
            ax.scatter(r.mean_comp, i, color="#c8372d", s=30, zorder=2, label="third-party (Kaggle)" if i == 0 else None)
            ax.scatter(r.mean_ref, i, color="#2f6aa8", s=30, zorder=2, label="own, label-free" if i == 0 else None)
        ax.set_yticks(range(len(s))); ax.set_yticklabels([names[r.replace(" own", "")] for r in s.reference])
        ax.set_xlabel(lab); ax.grid(axis="x", alpha=0.3)
    axes[0].legend(fontsize=7, loc="lower left")
    fig.suptitle("Same models, same folds: third-party vs label-free MRI embeddings", fontsize=9)
    fig.tight_layout()
    save(fig, "fig5_kaggle_vs_own", run)

    # ---------------- Fig 6: ROC/PR + forest on own features
    oof = pd.read_csv(P30 / "oof_predictions.csv")
    clin = pd.read_csv(OUT / "part04_clinical" / "oof_predictions.csv")
    curves = {"Clinical (XGBoost)": clin[(clin.group == "C5_clinical_full") & (clin.model == "XGBoost")],
              "MRI only (LR)": oof[oof.model == "MRI_only_LR"], "Fusion (LR)": oof[oof.model == "Fusion_PCA_LR"],
              "Fusion (RF)": oof[oof.model == "Fusion_PCA_RF"], "TabPFN (proposed)": oof[oof.model == "TabPFN_v2"]}
    tab = pd.read_csv(P30 / "tabpfn_vs_baselines_own.csv")
    fig = plt.figure(figsize=(7.2, 2.7))
    a1, a2 = fig.add_subplot(1, 3, 1), fig.add_subplot(1, 3, 2)
    for nm, p in curves.items():
        lw = 2.2 if "proposed" in nm else 1.0
        f, t, _ = roc_curve(p.y_true, p.y_prob); a1.plot(f, t, lw=lw, label=f"{nm} ({auc(f, t):.3f})")
        pr, rc, _ = precision_recall_curve(p.y_true, p.y_prob); a2.plot(rc, pr, lw=lw)
    a1.plot([0, 1], [0, 1], ":", color="grey"); a1.set(xlabel="1 - specificity", ylabel="sensitivity", title="(a) ROC")
    a2.set(xlabel="recall", ylabel="precision", title="(b) Precision-recall", ylim=(0.4, 1.01))
    a1.legend(fontsize=5.5, loc="lower right")
    a3 = fig.add_subplot(1, 3, 3)
    s = tab[tab.metric == "mcc"].sort_values("delta").reset_index(drop=True)
    lab = {"TabPFN_transportable": "TabPFN transp.", "Fusion_PCA_RF": "Fusion RF", "Fusion_PCA_LR": "Fusion LR",
           "Fusion_PCA_XGBoost": "Fusion XGB", "MRI_only_LR": "MRI only", "Clinical_C5_LR": "Clinical LR",
           "Clinical_C5_XGBoost": "Clinical XGB"}
    for i, r in s.iterrows():
        col = "#c8372d" if r.p_holm < 0.05 else ("#d97a2b" if r.p_wilcoxon < 0.05 else "#7f8c8d")
        a3.errorbar(r.delta, i, xerr=[[r.delta - r.ci95_low], [r.ci95_high - r.delta]], fmt="o", color=col, capsize=2, ms=3)
    a3.axvline(0, color="k", lw=0.6); a3.set_yticks(range(len(s))); a3.set_yticklabels([lab[c] for c in s.comparator], fontsize=6)
    a3.set(xlabel=r"$\Delta$MCC (TabPFN $-$ baseline)", title="(c) Paired differences")
    a3.text(0.98, 0.02, "red: Holm p<0.05\norange: unadjusted p<0.05", transform=a3.transAxes, ha="right", fontsize=5)
    fig.tight_layout()
    save(fig, "fig6_own_roc_sig", run)

    # ---------------- Fig 7: calibration on own features
    fig, ax = plt.subplots(figsize=(3.4, 3.0))
    ax.plot([0, 1], [0, 1], ":", color="grey")
    for nm in ["Fusion (LR)", "Fusion (RF)", "TabPFN (proposed)"]:
        p = curves[nm]
        fr, mp = calibration_curve(p.y_true, p.y_prob, n_bins=10, strategy="quantile")
        ax.plot(mp, fr, marker="o", ms=3, lw=2.2 if "proposed" in nm else 1.0, label=nm)
    ax.set(xlabel="mean predicted probability", ylabel="observed fraction CDR > 0", title="Reliability (own features)")
    ax.legend(fontsize=7)
    fig.tight_layout()
    save(fig, "fig7_own_calibration", run)

    # ---------------- subgroups (own features)
    df = load_cohort()
    info = df[["subject_id", "sex_binary", "Age"]].assign(sex=lambda d: d.sex_binary.map({0: "female", 1: "male"}),
                                                          age_band=lambda d: np.where(d.Age >= 75, ">=75", "60-74"))
    rows = []
    for nm in ["TabPFN (proposed)", "Fusion (RF)"]:
        p = curves[nm].merge(info, on="subject_id")
        for var in ["sex", "age_band"]:
            for level, s_ in p.groupby(var):
                mets = [binary_metrics(g.y_true, g.y_pred, g.y_prob) for _, g in s_.groupby("seed")]
                rows.append({"model": nm, "variable": var, "level": level, "n": s_.subject_id.nunique(),
                             **{k: np.mean([m[k] for m in mets]) for k in ["balanced_accuracy", "mcc", "roc_auc"]}})
    sg = pd.DataFrame(rows)
    run.save_csv(sg, "own_subgroups.csv")
    print(sg.round(3).to_string(index=False))
