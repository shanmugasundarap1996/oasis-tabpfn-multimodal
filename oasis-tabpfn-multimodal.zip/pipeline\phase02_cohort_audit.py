"""Phase 02 - Dataset audit and cohort construction from the RAW files.

Outputs: cohort flow (table + figure), repeated-scan audit, label/CDR consistency,
missing-value table, Table I (cohort characteristics), frozen cohort CSV, and a
check that the rebuilt cohort matches the legacy data/analysis_cohort_primary_age60.csv.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

import config
from common import PhaseRun

LEGACY_COHORT = config.RAW_DIR / "analysis_cohort_primary_age60.csv"
TABLE1_CONT = ["Age", "Educ", "SES", "MMSE", "eTIV", "nWBV", "ASF"]


def fmt_mean_sd(x):
    x = x.dropna()
    return f"{x.mean():.2f} ± {x.std(ddof=1):.2f}"


def fmt_median_iqr(x):
    x = x.dropna()
    q1, q2, q3 = np.percentile(x, [25, 50, 75])
    return f"{q2:.2f} [{q1:.2f}-{q3:.2f}]"


with PhaseRun("phase02_cohort", __file__,
              inputs=[config.CLINICAL_FILE, config.EMBED_FILE, LEGACY_COHORT],
              params={"min_age": config.MIN_AGE}) as run:

    clinical = pd.read_csv(config.CLINICAL_FILE)
    emb = pd.read_csv(config.EMBED_FILE)
    clinical["subject_id"] = clinical["ID"].str.extract(r"(OAS1_\d{4})", expand=False)
    clinical["session"] = clinical["ID"].str.extract(r"_(MR\d)$", expand=False)
    emb_cols = [c for c in emb.columns if c.startswith(config.EMBED_PREFIX)]
    assert len(emb_cols) == config.N_EMBED

    # ---------------- repeated-scan / subject-level audit
    print("\n--- Subject-level audit")
    rescans = clinical[clinical.duplicated("subject_id", keep=False)].sort_values("ID")
    scan_audit = pd.DataFrame([
        ("clinical_rows (sessions)", len(clinical)),
        ("clinical_unique_subjects", clinical.subject_id.nunique()),
        ("subjects_with_repeat_session", rescans.subject_id.nunique()),
        ("repeat_session_rows (MR2+)", int((clinical.session != "MR1").sum())),
        ("embedding_rows", len(emb)),
        ("embedding_unique_subjects", emb.subject_id.nunique()),
        ("embedding_duplicate_subject_rows", int(emb.subject_id.duplicated().sum())),
        ("embedding_subjects_not_in_clinical", len(set(emb.subject_id) - set(clinical.subject_id))),
    ], columns=["item", "value"])
    print(scan_audit.to_string(index=False))
    run.save_csv(scan_audit, "subject_level_audit.csv")
    run.save_csv(rescans[["subject_id", "ID", "session", "Age", "MMSE", "CDR", "Delay"]],
                 "repeat_sessions_detail.csv")
    assert emb.subject_id.is_unique, "Embedding table has >1 row per subject"

    # one clinical row per subject: first session (MR1); MR2 rows are reliability rescans
    clin_subj = clinical.sort_values(["subject_id", "ID"]).drop_duplicates("subject_id")
    assert (clin_subj.session == "MR1").all()

    # ---------------- cohort flow
    print("\n--- Cohort flow")
    s0 = clinical
    s1 = clin_subj
    s2 = s1.merge(emb, on="subject_id", how="inner", validate="one_to_one")
    s3 = s2[s2.CDR.notna()]
    s4 = s3[s3.Age >= config.MIN_AGE].copy()
    complete = s4[["Age", "M/F", "Educ", "SES", "MMSE", "eTIV", "nWBV", "ASF"]].notna().all(axis=1)
    flow = pd.DataFrame([
        ("OASIS-1 MRI sessions (clinical table rows)", len(s0), "", ""),
        ("Unique subjects (first session only)", len(s1), len(s0) - len(s1), "reliability rescans (MR2) removed"),
        ("MRI embedding available", len(s2), len(s1) - len(s2), "no embedding row"),
        ("CDR available (target defined)", len(s3), len(s2) - len(s3), "CDR missing"),
        (f"Age >= {config.MIN_AGE}  [FINAL COHORT]", len(s4), len(s3) - len(s4), f"age < {config.MIN_AGE}"),
        ("  of which complete on all clinical variables", int(complete.sum()), int((~complete).sum()),
         "kept; missing values imputed inside training folds"),
    ], columns=["step", "n", "excluded", "reason"])
    print(flow.to_string(index=False))
    run.save_csv(flow, "cohort_flow.csv")

    # why age >= 60: CDR missingness by age in the matched set
    age_cdr = s2.assign(age_band=pd.cut(s2.Age, [0, 40, 60, 200], right=False,
                                        labels=["<40", "40-59", ">=60"]),
                        cdr_missing=s2.CDR.isna())
    age_cdr = age_cdr.groupby("age_band", observed=False).agg(
        n=("subject_id", "size"), cdr_missing=("cdr_missing", "sum")).reset_index()
    print("\nCDR availability by age band (matched subjects):\n", age_cdr.to_string(index=False))
    run.save_csv(age_cdr, "cdr_availability_by_age.csv")

    # ---------------- targets + label/CDR consistency
    s4["target_binary"] = (s4.CDR > 0).astype(int)
    s4["target_3class"] = np.select([s4.CDR.eq(0), s4.CDR.eq(0.5), s4.CDR.ge(1.0)], [0, 1, 2])
    s4["sex_binary"] = s4["M/F"].map({"F": 0, "M": 1})
    xt = pd.crosstab(s4["label"], s4["CDR"], margins=True)
    print("\nEmbedding-file label vs CDR (final cohort):\n", xt)
    run.save_csv(xt.reset_index(), "label_vs_cdr_crosstab.csv")
    label_ok = ((s4.label == "Non Demented") == (s4.CDR == 0)).all()
    print("Embedding label consistent with CDR==0 / CDR>0:", label_ok)

    counts = pd.DataFrame({
        "class": ["0: CDR=0 (normal)", "1: CDR>0 (dementia spectrum)",
                  "  CDR=0.5", "  CDR=1", "  CDR=2"],
        "n": [int((s4.target_binary == 0).sum()), int((s4.target_binary == 1).sum()),
              int((s4.CDR == 0.5).sum()), int((s4.CDR == 1).sum()), int((s4.CDR == 2).sum())],
    })
    print("\n", counts.to_string(index=False))
    run.save_csv(counts, "class_counts.csv")

    # ---------------- missing values (final cohort)
    miss_vars = ["Age", "M/F", "Educ", "SES", "MMSE", "eTIV", "nWBV", "ASF"]
    missing = pd.DataFrame({
        "variable": miss_vars,
        "missing_n": [int(s4[v].isna().sum()) for v in miss_vars],
    })
    missing["missing_pct"] = (100 * missing.missing_n / len(s4)).round(2)
    missing["missing_n_class0"] = [int(s4.loc[s4.target_binary == 0, v].isna().sum()) for v in miss_vars]
    missing["missing_n_class1"] = [int(s4.loc[s4.target_binary == 1, v].isna().sum()) for v in miss_vars]
    missing["strategy"] = ["none" if n == 0 else
                           ("most-frequent (train fold)" if v == "M/F" else "median (train fold)")
                           for v, n in zip(miss_vars, missing.missing_n)]
    missing.loc[len(missing)] = ["MRI embedding (512)", int(s4[emb_cols].isna().any(axis=1).sum()),
                                 round(100 * s4[emb_cols].isna().any(axis=1).mean(), 2), 0, 0, "none"]
    print("\nMissing values:\n", missing.to_string(index=False))
    run.save_csv(missing, "missing_values.csv")

    # ---------------- Table I
    g0, g1 = s4[s4.target_binary == 0], s4[s4.target_binary == 1]
    rows = [{"variable": "N", "overall": len(s4), "normal_CDR0": len(g0),
             "dementia_CDR_gt0": len(g1), "test": "", "p_value": np.nan}]
    for v in TABLE1_CONT:
        p = stats.mannwhitneyu(g0[v].dropna(), g1[v].dropna()).pvalue
        rows.append({"variable": f"{v}, mean ± SD", "overall": fmt_mean_sd(s4[v]),
                     "normal_CDR0": fmt_mean_sd(g0[v]), "dementia_CDR_gt0": fmt_mean_sd(g1[v]),
                     "test": "Mann-Whitney U", "p_value": p})
        rows.append({"variable": f"{v}, median [IQR]", "overall": fmt_median_iqr(s4[v]),
                     "normal_CDR0": fmt_median_iqr(g0[v]), "dementia_CDR_gt0": fmt_median_iqr(g1[v]),
                     "test": "", "p_value": np.nan})
    sex_tab = pd.crosstab(s4.target_binary, s4["M/F"])
    chi2, p_sex, _, _ = stats.chi2_contingency(sex_tab)
    for sx in ["F", "M"]:
        rows.append({"variable": f"Sex {sx}, n (%)",
                     "overall": f"{(s4['M/F'] == sx).sum()} ({100 * (s4['M/F'] == sx).mean():.1f}%)",
                     "normal_CDR0": f"{(g0['M/F'] == sx).sum()} ({100 * (g0['M/F'] == sx).mean():.1f}%)",
                     "dementia_CDR_gt0": f"{(g1['M/F'] == sx).sum()} ({100 * (g1['M/F'] == sx).mean():.1f}%)",
                     "test": "Chi-square" if sx == "F" else "", "p_value": p_sex if sx == "F" else np.nan})
    table1 = pd.DataFrame(rows)
    table1["p_value"] = table1.p_value.map(lambda p: "" if pd.isna(p) else (f"{p:.2e}" if p < 1e-3 else f"{p:.3f}"))
    print("\nTable I:\n", table1.to_string(index=False))
    run.save_csv(table1, "table1_cohort_characteristics.csv")

    # ---------------- frozen cohort
    keep = (["subject_id", "ID", "label", "CDR", "target_binary", "target_3class",
             "M/F", "sex_binary", "Hand", "Age", "Educ", "SES", "MMSE", "eTIV", "nWBV", "ASF"]
            + emb_cols)
    cohort = s4[keep].sort_values("subject_id").reset_index(drop=True)
    run.save_csv(cohort, "cohort_primary_age60.csv")

    # ---------------- consistency with legacy cohort used in results/ 02-16
    legacy = pd.read_csv(LEGACY_COHORT).sort_values("subject_id").reset_index(drop=True)
    same_ids = set(legacy.subject_id) == set(cohort.subject_id)
    same_target = same_ids and (legacy.target_binary.to_numpy() == cohort.target_binary.to_numpy()).all()
    same_emb = same_ids and np.allclose(legacy[emb_cols].to_numpy(), cohort[emb_cols].to_numpy())
    clin_cols = ["Age", "Educ", "SES", "MMSE", "eTIV", "nWBV", "ASF"]
    same_clin = same_ids and legacy[clin_cols].equals(cohort[clin_cols])
    check = pd.DataFrame([("same_subject_ids", same_ids), ("same_target", same_target),
                          ("same_embeddings", same_emb), ("same_clinical_values", same_clin),
                          ("label_consistent_with_CDR", label_ok)], columns=["check", "passed"])
    print("\nRebuilt vs legacy cohort:\n", check.to_string(index=False))
    run.save_csv(check, "legacy_consistency_check.csv")
    assert check.passed.all(), "Rebuilt cohort differs from legacy cohort - investigate before continuing"

    # ---------------- figures
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.axis("off")
    for i, r in flow.iloc[:5].iterrows():
        y = 1 - i * 0.2
        ax.text(0.5, y, f"{r.step}\nn = {r.n}", ha="center", va="center", fontsize=10,
                bbox=dict(boxstyle="round", fc="#eef3fb", ec="#3a6ea5"))
        if i < 4:
            ax.annotate("", xy=(0.5, y - 0.13), xytext=(0.5, y - 0.07),
                        arrowprops=dict(arrowstyle="->"))
            nxt = flow.iloc[i + 1]
            ax.text(0.93, y - 0.1, f"excluded {nxt.excluded}\n({nxt.reason})",
                    ha="right", va="center", fontsize=8, color="#7a3b3b")
    ax.set_ylim(0.1, 1.08)
    run.save_fig(fig, "fig_cohort_flow.png")
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(13, 3.6))
    for ax, v in zip(axes, ["Age", "MMSE", "nWBV"]):
        for cls, lab in [(0, "CDR = 0"), (1, "CDR > 0")]:
            ax.hist(s4.loc[s4.target_binary == cls, v].dropna(), bins=12, alpha=0.55, label=lab)
        ax.set_title(v); ax.set_xlabel(v); ax.set_ylabel("Subjects")
    axes[0].legend()
    fig.tight_layout()
    run.save_fig(fig, "fig_variable_distributions.png")
    plt.close(fig)
