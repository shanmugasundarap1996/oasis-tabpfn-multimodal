"""Part 17a - Lock final models for external validation.

Fits (1) the final model chosen by the Part 16 decision gate and (2) its transportable
counterpart (Age, Sex, Education, MMSE + MRI) on ALL 166 OASIS-1 subjects. Hyperparameters
(incl. MRI PCA k) are tuned by CV over the frozen seed-42 outer folds. Artifacts are written
once with SHA-256 hashes; external evaluation refuses to run if a hash does not match.
"""
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GridSearchCV

import config
from common import PhaseRun, embedding_cols, iter_outer_folds, load_cohort, sha256
from models import CLASSIFIERS, build

DECISION = config.OUTPUT_DIR / "part16_final" / "final_model_decision.json"
NESTED_K = [k for k in config.PCA_DIMS if k <= 64]

with PhaseRun("part17a_locked", __file__, inputs=[config.COHORT_FILE, config.FOLDS_FILE, DECISION]) as run:
    decision = json.loads(DECISION.read_text(encoding="utf-8"))
    family, group = decision["final_family"], decision["final_group"]
    if family not in CLASSIFIERS:
        raise NotImplementedError(
            f"Final model is a GNN ({family}); locking requires storing the training graph. "
            "Extend this script before external validation.")
    df = load_cohort()
    emb = embedding_cols(df)
    y = df[config.TARGET_COL].to_numpy()
    cv = [(tr, te) for s, f, tr, te in iter_outer_folds(df) if s == 42]
    use_pca = group != "Fusion_raw_520"
    extra = {"prep__mri__pca": [PCA(n_components=k, random_state=42) for k in NESTED_K + [128]]
             + ["passthrough"]} if use_pca else None

    locked = {}
    for name, tab in [("final_full", config.CLINICAL_FULL), ("final_transportable", config.TRANSPORTABLE_CLINICAL)]:
        feats = emb + tab
        pipe, grid = build(family, mri_cols=emb, tab_cols=tab, pca_dim=8 if use_pca else None, extra_grid=extra)
        gs = GridSearchCV(pipe, grid, cv=cv, scoring=config.TUNING_SCORING, n_jobs=-1).fit(df[feats], y)
        path = run.path(f"{name}.joblib")
        joblib.dump(gs.best_estimator_, path)
        run.outputs.append(path)
        ref = df[tab].describe().T[["mean", "std", "min", "max"]]
        meta = {
            "name": name, "family": family, "source_group": group, "features_in_order": feats,
            "clinical_features": tab, "n_train": int(len(df)), "class_counts": {"0": int((y == 0).sum()), "1": int((y == 1).sum())},
            "best_params": {k: str(v) for k, v in gs.best_params_.items()},
            "cv_auc_seed42_folds": float(gs.best_score_),
            "apparent_auc_training": float(roc_auc_score(y, gs.best_estimator_.predict_proba(df[feats])[:, 1])),
            "decision_threshold": config.DECISION_THRESHOLD,
            "training_cohort_sha256": sha256(config.COHORT_FILE),
            "artifact_sha256": sha256(path),
            "clinical_reference_distribution": ref.round(4).to_dict(orient="index"),
        }
        run.save_json(meta, f"{name}_metadata.json")
        locked[name] = meta
        print(f"{name}: {family}, params={meta['best_params']}, CV AUC={meta['cv_auc_seed42_folds']:.4f}")
    run.save_json({k: {"artifact": f"{k}.joblib", "sha256": v["artifact_sha256"]} for k, v in locked.items()},
                  "LOCKED_ARTIFACTS.json")
