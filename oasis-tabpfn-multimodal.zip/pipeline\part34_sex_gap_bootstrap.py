"""Part 34 - Subject-level bootstrap CI of subgroup performance gaps (female - male; 60-74 - >=75) for TabPFN and
fusion-RF on the label-free (own) MRI features. Uses Part 30 out-of-fold predictions; AUC/MCC averaged over seeds."""
import numpy as np
import pandas as pd
from sklearn.metrics import matthews_corrcoef, roc_auc_score

import config
from common import PhaseRun, load_cohort

P30 = config.OUTPUT_DIR / "part30_own_mri_benchmark" / "oof_predictions.csv"
B = 2000


def seed_mean(p, ids):
    auc, mcc = [], []
    for _, g in p[p.subject_id.isin(ids)].groupby("seed"):
        g = g.set_index("subject_id").loc[ids]  # bootstrap duplicates kept
        auc.append(roc_auc_score(g.y_true, g.y_prob)); mcc.append(matthews_corrcoef(g.y_true, g.y_pred))
    return np.mean(auc), np.mean(mcc)


with PhaseRun("part34_sex_gap_bootstrap", __file__, inputs=[config.COHORT_FILE, P30]) as run:
    df = load_cohort()
    oof = pd.read_csv(P30)
    groups = {"sex": (df.subject_id[df.sex_binary == 0].values, df.subject_id[df.sex_binary == 1].values,
                      "female - male"),
              "age_band": (df.subject_id[df.Age < 75].values, df.subject_id[df.Age >= 75].values, "60-74 - >=75")}
    rows = []
    for model in ["TabPFN_v2", "Fusion_PCA_RF"]:
        p = oof[oof.model == model]
        for var, (a, b, lab) in groups.items():
            rng = np.random.default_rng(42)
            (auc_a, mcc_a), (auc_b, mcc_b) = seed_mean(p, a), seed_mean(p, b)
            boot = []
            for _ in range(B):
                ra, rb = rng.choice(a, len(a)), rng.choice(b, len(b))
                (x1, y1), (x2, y2) = seed_mean(p, ra), seed_mean(p, rb)
                boot.append((x1 - x2, y1 - y2))
            boot = np.array(boot)
            for j, m, d in [(0, "roc_auc", auc_a - auc_b), (1, "mcc", mcc_a - mcc_b)]:
                lo, hi = np.percentile(boot[:, j], [2.5, 97.5])
                rows.append({"model": model, "variable": var, "contrast": lab, "metric": m, "n_a": len(a), "n_b": len(b),
                             "delta": d, "ci95_low": lo, "ci95_high": hi, "excludes_zero": bool(lo > 0 or hi < 0)})
    out = pd.DataFrame(rows)
    run.save_csv(out, "subgroup_gap_bootstrap.csv")
    print(out.round(3).to_string(index=False))
