"""Part 19 v2 - Severity-aware (ordinal) learning.

Training target = CDR level (0: CDR 0, 1: CDR 0.5, 2: CDR >= 1); CDR is never an input.
Prediction for the binary task: P(CDR > 0) = 1 - P(level 0). The extra severity structure
can sharpen the decision boundary between normal and very-mild subjects.
Tuning (incl. MRI PCA k) on the frozen inner folds with binary ROC-AUC of P(CDR > 0).
Primary model RF (tested against the rule); LR descriptive.
"""
import json

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GridSearchCV

import config
from common import (PhaseRun, binary_metrics, check_oof_integrity, embedding_cols, inner_splits,
                    iter_outer_folds, load_cohort, summarize)
from models import build
from newmethods import BASELINE_FILE, PROTOCOL_FILE, compare

NESTED_K = [k for k in config.PCA_DIMS if k <= 64]


def binary_auc_from_levels(est, X, y_level):
    return roc_auc_score(y_level > 0, 1 - est.predict_proba(X)[:, 0])


with PhaseRun("part19_v2_ordinal", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"target": "target_3class (CDR 0 / 0.5 / >=1), training only",
                      "primary": "RF", "descriptive": "LR"}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    feats = emb + config.CLINICAL_FULL
    y_bin = df[config.TARGET_COL].to_numpy()
    y_lvl = df["target_3class"].to_numpy()
    assert ((y_lvl > 0) == (y_bin == 1)).all()
    pca_grid = {"prep__mri__pca": [PCA(n_components=k, random_state=42) for k in NESTED_K] + ["passthrough"]}

    m_rows, p_rows, b_rows = [], [], []
    for seed, fold, tr, te in iter_outer_folds(df):
        cv_in = inner_splits(df, seed, fold, tr)
        for name in ["RF", "LR"]:
            pipe, grid = build(name, mri_cols=emb, tab_cols=config.CLINICAL_FULL, pca_dim=8, extra_grid=pca_grid)
            gs = GridSearchCV(pipe, grid, cv=cv_in, scoring=binary_auc_from_levels, n_jobs=-1)
            gs.fit(df.iloc[tr][feats], y_lvl[tr])
            prob = 1 - gs.predict_proba(df.iloc[te][feats])[:, 0]
            pred = (prob >= config.DECISION_THRESHOLD).astype(int)
            m = binary_metrics(y_bin[te], pred, prob)
            m.update({"group": "v2_ordinal", "model": f"Ordinal_{name}", "seed": seed, "fold": fold,
                      "inner_cv_score": gs.best_score_})
            m_rows.append(m)
            b_rows.append({"model": f"Ordinal_{name}", "seed": seed, "fold": fold,
                           **{k: str(v) for k, v in gs.best_params_.items()}})
            p_rows += [{"group": "v2_ordinal", "model": f"Ordinal_{name}", "seed": seed, "fold": fold,
                        "subject_id": df.subject_id.iloc[i], "y_true": int(y_bin[i]), "y_prob": float(p),
                        "y_pred": int(q)} for i, p, q in zip(te, prob, pred)]
        print(f"  seed {seed} fold {fold} done")

    folds, preds = pd.DataFrame(m_rows), pd.DataFrame(p_rows)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(pd.DataFrame(b_rows), "best_params.csv")
    summary = summarize(folds)
    run.save_csv(summary, "summary.csv")
    print(summary[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))

    tables = []
    for model in ["Ordinal_RF", "Ordinal_LR"]:
        t, v = compare(folds[folds.model == model], model)
        tables.append(t)
        if model == "Ordinal_RF":
            verdict = v
    table = pd.concat(tables)
    run.save_csv(table, "comparison_vs_baseline.csv")
    run.save_json(verdict, "verdict.json")
    print("\n", table[table.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))
    print("\nVERDICT (primary = Ordinal_RF):", json.dumps(verdict, indent=2, default=str))
    assert check_oof_integrity(preds, df)
