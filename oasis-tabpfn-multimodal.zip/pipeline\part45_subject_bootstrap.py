"""Part 45 - Amendment 8: subject-level uncertainty for the main comparisons.

The 25 outer folds re-use the same 166 subjects, so fold-level intervals may understate uncertainty. Here subjects
are resampled (2000 bootstrap samples); for each sample the metric is computed per seed on the pooled out-of-fold
predictions of that seed and averaged over the 5 seeds. Paired difference = proposed TabPFN - comparator;
two-sided bootstrap p; Holm over all comparators x metrics."""
import numpy as np
import pandas as pd
from sklearn.metrics import brier_score_loss, matthews_corrcoef, roc_auc_score

import config
from common import PhaseRun
from compare_tools import _holm

O = config.OUTPUT_DIR
FILES = {O / "part30_own_mri_benchmark" / "oof_predictions.csv": None,
         O / "part33_own_modern_and_recal" / "oof_predictions.csv": None,
         O / "part04_clinical" / "oof_predictions.csv": ("C5_clinical_full", {"LR": "Clinical_C5_LR",
                                                                            "XGBoost": "Clinical_C5_XGBoost"}),
         O / "part31_own_mri_extended" / "ablation_oof_predictions.csv": ("Ablation_own", {"TabPFN_clinical_only":
                                                                                      "TabPFN_clinical_only"})}
REF, N_BOOT = "TabPFN_v2", 2000
METRICS = {"roc_auc": lambda y, p: roc_auc_score(y, p), "brier": brier_score_loss,
           "mcc": lambda y, p: matthews_corrcoef(y, (p >= config.DECISION_THRESHOLD).astype(int))}

with PhaseRun("part45_subject_bootstrap", __file__, inputs=list(FILES), params={"n_boot": N_BOOT, "ref": REF}) as run:
    frames = []
    for f, sel in FILES.items():
        d = pd.read_csv(f)
        if sel:
            d = d[(d.group == sel[0]) & d.model.isin(sel[1])].assign(model=lambda x: x.model.map(sel[1]))
        frames.append(d[["model", "seed", "subject_id", "y_true", "y_prob"]])
    oof = pd.concat(frames)
    P = oof.pivot_table(index="subject_id", columns=["model", "seed"], values="y_prob")
    y = oof.drop_duplicates("subject_id").set_index("subject_id").loc[P.index, "y_true"].to_numpy()
    seeds = sorted(oof.seed.unique())
    models = sorted(oof.model.unique())
    assert P.notna().all().all() and len(P) == 166, "every model needs one OOF prediction per subject and seed"

    def score(idx, m, k):
        return np.mean([METRICS[k](y[idx], P[(m, s)].to_numpy()[idx]) for s in seeds])

    rng = np.random.default_rng(42)
    boots = [i for i in (rng.integers(0, len(y), len(y)) for _ in range(N_BOOT)) if len(np.unique(y[i])) == 2]
    full = np.arange(len(y))
    rows = []
    for m in models:
        if m == REF:
            continue
        for k in METRICS:
            d = np.array([score(i, REF, k) - score(i, m, k) for i in boots])
            p = min(1.0, 2 * min((d <= 0).mean(), (d >= 0).mean()))
            rows.append({"comparator": m, "metric": k, "proposed": score(full, REF, k), "comparator_value": score(full, m, k),
                         "delta": score(full, REF, k) - score(full, m, k), "ci95_low": np.percentile(d, 2.5),
                         "ci95_high": np.percentile(d, 97.5), "p_boot": max(p, 1 / len(boots))})
        print(f"  {m} done", flush=True)
    t = pd.DataFrame(rows)
    t["p_holm"] = _holm(t.p_boot)
    run.save_csv(t, "subject_bootstrap.csv")
    print(t.round(4).to_string(index=False))
