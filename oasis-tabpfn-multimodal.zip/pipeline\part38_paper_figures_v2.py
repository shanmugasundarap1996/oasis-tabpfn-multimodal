"""Part 38 - Result figures for draft v2 (main5), all from saved result files; written to main5_v2/figures.

fig6_own_roc_sig : (a) ROC, (b) PR of pooled OOF predictions; (c) paired MCC differences (TabPFN - baseline)
                   for all 11 baselines (Parts 30, 31, 33), coloured by Holm-adjusted / unadjusted Wilcoxon p.
fig7_own_calibration : reliability diagram incl. isotonic-recalibrated RF; Brier in legend.
fig5_kaggle_vs_own   : leakage audit, same models and folds (Part 30), with paired deltas annotated.
fig8_morph_robustness: ResNet vs morphometry MRI block for TabPFN and fusion learners (Parts 30, 36).
"""
import matplotlib
matplotlib.use("Agg")
import io

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.calibration import calibration_curve
from sklearn.metrics import auc, brier_score_loss, precision_recall_curve, roc_curve

import config
from common import PhaseRun

OUT = config.OUTPUT_DIR
import sys
# optional argument: paper folder (default main5_v2); labels use the paper's names (MIND-AD, study-label-free)
FIG = config.BASE_DIR / "jbhi_multimodel_fussion" / (sys.argv[1] if len(sys.argv) > 1 else "main5_v2") / "figures"
P30, P31, P33, P36 = (OUT / "part30_own_mri_benchmark", OUT / "part31_own_mri_extended",
                      OUT / "part33_own_modern_and_recal", OUT / "part36_morph_benchmark")
PROP = "#6b4c9a"
plt.rcParams.update({"font.size": 8, "axes.titlesize": 8.5, "pdf.fonttype": 42, "font.family": "DejaVu Sans"})


def save(fig, name, run):
    fig.savefig(FIG / f"{name}.pdf", bbox_inches="tight", pad_inches=0.02)
    buf = io.BytesIO(); fig.savefig(buf, format="png", dpi=300, bbox_inches="tight", pad_inches=0.02)
    (FIG / f"{name}.png").write_bytes(buf.getvalue()); run.path(f"{name}.png").write_bytes(buf.getvalue())
    run.outputs.append(run.path(f"{name}.png")); plt.close(fig)


with PhaseRun("part38_paper_figures_v2", __file__,
              inputs=[P30 / "oof_predictions.csv", P30 / "tabpfn_vs_baselines_own.csv", P30 / "own_vs_kaggle.csv",
                      P31 / "ablation_vs_full.csv", P33 / "oof_predictions.csv", P33 / "tabpfn_vs_modern_recal_own.csv",
                      P36 / "summary.csv", P30 / "summary.csv"]) as run:
    FIG.mkdir(parents=True, exist_ok=True)
    oof30, oof33 = pd.read_csv(P30 / "oof_predictions.csv"), pd.read_csv(P33 / "oof_predictions.csv")
    clin = pd.read_csv(OUT / "part04_clinical" / "oof_predictions.csv")
    curves = {"Clinical XGBoost": clin[(clin.group == "C5_clinical_full") & (clin.model == "XGBoost")],
              "MRI only (LR)": oof30[oof30.model == "MRI_only_LR"],
              "Fusion LR": oof30[oof30.model == "Fusion_PCA_LR"],
              "Fusion RF": oof30[oof30.model == "Fusion_PCA_RF"],
              "Fusion CatBoost": oof33[oof33.model == "Fusion_PCA_CatBoost"],
              "MIND-AD (proposed)": oof30[oof30.model == "TabPFN_v2"]}
    cols = {"Clinical XGBoost": "#1f77b4", "MRI only (LR)": "#ff7f0e", "Fusion LR": "#2ca02c", "Fusion RF": "#d62728",
            "Fusion CatBoost": "#8c564b", "MIND-AD (proposed)": PROP}

    # ---------------- Fig 6
    t30 = pd.read_csv(P30 / "tabpfn_vs_baselines_own.csv"); t33 = pd.read_csv(P33 / "tabpfn_vs_modern_recal_own.csv")
    t31 = pd.read_csv(P31 / "ablation_vs_full.csv")
    t31 = t31[t31.comparator == "TabPFN_clinical_only"]
    forest = pd.concat([t30, t33, t31])
    forest = forest[forest.metric == "mcc"].copy()
    lab = {"TabPFN_transportable": "MIND-AD transportable", "Fusion_PCA_RF": "Fusion RF", "Fusion_PCA_LR": "Fusion LR",
           "Fusion_PCA_XGBoost": "Fusion XGBoost", "MRI_only_LR": "MRI only (LR)", "Clinical_C5_LR": "Clinical LR",
           "Clinical_C5_XGBoost": "Clinical XGBoost", "Fusion_PCA_CatBoost": "Fusion CatBoost",
           "Fusion_PCA_LightGBM": "Fusion LightGBM", "Fusion_PCA_RF_isotonic": "Fusion RF (isotonic)",
           "TabPFN_clinical_only": "TabPFN clinical only"}
    forest = forest.sort_values("delta").reset_index(drop=True)
    fig = plt.figure(figsize=(7.16, 2.75))
    a1 = fig.add_axes([0.06, 0.15, 0.25, 0.75]); a2 = fig.add_axes([0.37, 0.15, 0.25, 0.75])
    a3 = fig.add_axes([0.80, 0.15, 0.19, 0.75])
    for nm, p in curves.items():
        lw = 2.0 if "proposed" in nm else 0.9
        f, t, _ = roc_curve(p.y_true, p.y_prob); a1.plot(f, t, lw=lw, color=cols[nm], label=f"{nm} ({auc(f, t):.3f})")
        pr, rc, _ = precision_recall_curve(p.y_true, p.y_prob); a2.plot(rc, pr, lw=lw, color=cols[nm])
    a1.plot([0, 1], [0, 1], ":", color="grey", lw=0.8)
    a1.set(xlabel="1 − specificity", ylabel="sensitivity", title="(a) ROC (pooled out-of-fold)")
    a2.set(xlabel="recall", ylabel="precision", title="(b) Precision–recall", ylim=(0.45, 1.01))
    a1.legend(fontsize=5.6, loc="lower right", frameon=True, handlelength=1.4)
    for i, r in forest.iterrows():
        col = "#c8372d" if r.p_holm < 0.05 else ("#d97a2b" if r.p_wilcoxon < 0.05 else "#7f8c8d")
        a3.errorbar(r.delta, i, xerr=[[r.delta - r.ci95_low], [r.ci95_high - r.delta]], fmt="o", color=col,
                    capsize=1.8, ms=3, lw=1)
    a3.axvline(0, color="k", lw=0.6)
    a3.set_yticks(range(len(forest))); a3.set_yticklabels([lab[c] for c in forest.comparator], fontsize=6.3)
    a3.set(xlabel="ΔMCC (MIND-AD − baseline)", title="(c) Paired MCC differences")
    a3.tick_params(axis="x", labelsize=7)
    h = [plt.Line2D([], [], marker="o", ls="", color=c, ms=3.5) for c in ("#c8372d", "#d97a2b", "#7f8c8d")]
    a3.legend(h, ["Holm p<0.05", "unadjusted p<0.05", "n.s."], fontsize=5.5, loc="lower right", handletextpad=0.2)
    save(fig, "fig6_own_roc_sig", run)

    # ---------------- Fig 7
    calc = {"Fusion LR": curves["Fusion LR"], "Fusion RF": curves["Fusion RF"],
            "Fusion RF (isotonic)": oof33[oof33.model == "Fusion_PCA_RF_isotonic"],
            "MIND-AD (proposed)": curves["MIND-AD (proposed)"]}
    ccol = {"Fusion LR": "#2ca02c", "Fusion RF": "#d62728", "Fusion RF (isotonic)": "#e377c2", "MIND-AD (proposed)": PROP}
    fig, ax = plt.subplots(figsize=(3.3, 3.0))
    ax.plot([0, 1], [0, 1], ":", color="grey", lw=0.8)
    for nm, p in calc.items():
        fr, mp = calibration_curve(p.y_true, p.y_prob, n_bins=10, strategy="quantile")
        b = np.mean([brier_score_loss(g.y_true, g.y_prob) for _, g in p.groupby(["seed", "fold"])])
        ax.plot(mp, fr, marker="o", ms=2.8, lw=2.0 if "proposed" in nm else 0.9, color=ccol[nm],
                label=f"{nm} (Brier {b:.3f})")
    ax.set(xlabel="mean predicted probability", ylabel="observed fraction with CDR > 0",
           title="Reliability (study-label-free MRI)", xlim=(-0.02, 1.02), ylim=(-0.02, 1.02))
    ax.legend(fontsize=6.2, loc="upper left")
    save(fig, "fig7_own_calibration", run)

    # ---------------- Fig 5
    kv = pd.read_csv(P30 / "own_vs_kaggle.csv")
    names = {"TabPFN_v2": "MIND-AD (proposed)", "Fusion_PCA_RF": "Fusion RF", "Fusion_PCA_LR": "Fusion LR",
             "MRI_only_LR": "MRI only (LR)"}
    fig, axes = plt.subplots(1, 2, figsize=(3.5, 2.3), sharey=True)
    for ax, m, xl in [(axes[0], "mcc", "MCC"), (axes[1], "roc_auc", "ROC-AUC")]:
        s = kv[kv.metric == m].reset_index(drop=True)
        for i, r in s.iterrows():
            ax.plot([r.mean_ref, r.mean_comp], [i, i], color="#9aa5b1", lw=1.8, zorder=1)
            ax.scatter(r.mean_comp, i, color="#c8372d", s=22, zorder=2, label="third-party" if i == 0 else None)
            ax.scatter(r.mean_ref, i, color="#2f6aa8", s=22, zorder=2, label="study-label-free" if i == 0 else None)
            ax.text((r.mean_ref + r.mean_comp) / 2, i + 0.22, f"+{r.mean_comp - r.mean_ref:.2f}", ha="center",
                    fontsize=6, color="#444444")
        ax.set_yticks(range(len(s))); ax.set_yticklabels([names[x.replace(" own", "")] for x in s.reference], fontsize=6.8)
        ax.set_xlabel(xl, fontsize=7.5); ax.tick_params(axis="x", labelsize=6.5); ax.grid(axis="x", alpha=0.3)
        ax.set_ylim(-0.5, len(s) - 0.4)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, fontsize=6.3, loc="lower center", ncol=2, bbox_to_anchor=(0.6, -0.02), frameon=False,
               handletextpad=0.1)
    fig.tight_layout(w_pad=0.6, rect=(0, 0.08, 1, 1))
    save(fig, "fig5_kaggle_vs_own", run)

    # ---------------- Fig 8 (morphometry robustness)
    s30, s36 = pd.read_csv(P30 / "summary.csv"), pd.read_csv(P36 / "summary.csv")
    rows = [("MIND-AD", "TabPFN_v2", "TabPFN_morph"), ("Fusion XGBoost", "Fusion_PCA_XGBoost", "Fusion_PCA_XGBoost_morph"),
            ("Fusion RF", "Fusion_PCA_RF", "Fusion_PCA_RF_morph"), ("Fusion LR", "Fusion_PCA_LR", "Fusion_PCA_LR_morph"),
            ("MRI only (LR)", "MRI_only_LR", "MRI_only_LR_morph")]
    fig, axes = plt.subplots(1, 3, figsize=(7.16, 1.9), sharey=True)
    y = np.arange(len(rows))
    for ax, m, xl in zip(axes, ["mcc", "roc_auc", "brier"], ["MCC", "ROC-AUC", "Brier score (lower is better)"]):
        a = [float(s30.loc[s30.model == r[1], f"{m}_mean"].iloc[0]) for r in rows]
        b = [float(s36.loc[s36.model == r[2], f"{m}_mean"].iloc[0]) for r in rows]
        ax.barh(y + 0.19, a, 0.36, color="#2f6aa8", label="ResNet slices")
        ax.barh(y - 0.19, b, 0.36, color="#e0a030", label="tissue morphometry")
        lo = {"mcc": 0.2, "roc_auc": 0.65, "brier": 0.10}[m]
        ax.set_xlim(lo, max(a + b) * 1.06 if m != "brier" else 0.26)
        ax.set_xlabel(xl, fontsize=7.5); ax.grid(axis="x", alpha=0.3)
    axes[0].set_yticks(y); axes[0].set_yticklabels([r[0] for r in rows], fontsize=7); axes[0].invert_yaxis()
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, fontsize=6.8, loc="upper center", ncol=2, bbox_to_anchor=(0.55, 1.04), frameon=False)
    fig.tight_layout(w_pad=0.5, rect=(0, 0, 1, 0.92))
    save(fig, "fig8_morph_robustness", run)
    print("figures written to", FIG)
