"""Part 17b - Pre-registered external-validation protocol + pipeline test.

Writes the protocol BEFORE any external data are accessed, and runs the harmonisation and
locked-model evaluation code end-to-end on a SYNTHETIC OASIS-3-format table derived from
OASIS-1 (education converted to years, columns renamed). This only proves the code works;
it is NOT an external-validation result and must never be reported as one.
"""
import numpy as np
import pandas as pd

import config
from common import PhaseRun, embedding_cols, load_cohort
from external_validation import (COLUMN_MAPS, educ_years_to_oasis1, evaluate, harmonise,
                                 load_locked)

LOCKED = config.OUTPUT_DIR / "part17a_locked" / "LOCKED_ARTIFACTS.json"

PROTOCOL = f"""# Pre-registered external-validation protocol (frozen before data access)

**Models.** The two artifacts in `outputs/part17a_locked/` (final full model and transportable model),
verified by SHA-256 before every use. No retraining, re-tuning, feature selection or threshold change
on external data. External data are used once, for evaluation only.

**Cohorts.** OASIS-3 (primary), ADNI (secondary).

**Inclusion.** (1) baseline T1-weighted MRI session; (2) global CDR assessed within ±180 days of that
MRI; (3) age ≥ {config.MIN_AGE} at the MRI; (4) MMSE, sex and education available for the transportable
model (missing values are imputed by the locked pipeline with OASIS-1 training medians, and the number
imputed is reported); (5) one session per subject.

**Exclusion.** OASIS-3 participants who also appear in OASIS-1 (identified via the OASIS cross-release
identifier mapping if available; otherwise matched on sex, age at scan and scan date, and reported).
Non-AD primary diagnoses are retained (same as OASIS-1) and reported descriptively.

**Target.** y = 0 if CDR = 0; y = 1 if CDR > 0 (identical to development).

**Harmonisation.** Education years → OASIS-1 code (< 12 → 1, 12 → 2, 13–15 → 3, 16 → 4, > 16 → 5);
sex → binary (male = 1); MMSE as recorded. SES, eTIV, nWBV and ASF are not used externally
(absent or derived differently), so the transportable model is the primary external model; the full
model is evaluated only where all its variables can be reproduced. MRI embeddings are produced by the
Part 05b extractor with identical preprocessing.

**Outcomes.** ROC-AUC (primary), balanced accuracy, macro-F1, MCC, sensitivity, specificity,
PR-AUC, Brier, ECE, log-loss, calibration slope and intercept; 95% bootstrap CIs (2,000 resamples);
results after recalibration-in-the-large reported separately as a secondary analysis.

**Pre-specified secondary analyses.** Subgroups by sex and age band (60–74, ≥ 75); covariate shift
(standardised mean differences of clinical variables; MRI domain-classifier AUC); ADNI analysed
separately from OASIS-3, never pooled with development data.

**Interpretation.** Internal OASIS-1 performance of the transportable model (Part 07) is the reference.
A drop is reported as transportability evidence, not hidden; no external result triggers model changes
in the submitted paper.

**Column mappings (VERIFY against data dictionaries):** {COLUMN_MAPS}
"""

with PhaseRun("part17b_protocol", __file__, inputs=[config.COHORT_FILE, LOCKED]) as run:
    run.save_text(PROTOCOL, "external_validation_protocol.md")

    # ---------------- synthetic pipeline test (NOT a result)
    df = load_cohort()
    emb = embedding_cols(df)
    years = df.Educ.map({1: 10, 2: 12, 3: 14, 4: 16, 5: 18})
    rt = (educ_years_to_oasis1(years) == df.Educ).mean()
    print(f"Education years -> code round trip agreement: {rt:.3f}")
    fake_clin = pd.DataFrame({"OASISID": df.subject_id, "age_at_visit": df.Age,
                              "GENDER": df.sex_binary, "EDUC": years, "MMSE": df.MMSE, "CDR": df.CDR})
    fake_emb = df[["subject_id"] + emb]
    data, log = harmonise(fake_clin, fake_emb, "OASIS3")
    run.save_csv(log, "SYNTHETIC_TEST_harmonisation_log.csv")
    rows = []
    for name in ["final_transportable", "final_full"]:
        model, meta = load_locked(name)
        if not set(meta["features_in_order"]) <= set(data.columns):
            print(f"{name}: needs {set(meta['features_in_order']) - set(data.columns)} - "
                  "not evaluable on transportable schema (expected for the full model)")
            continue
        summ, sub, shift, preds = evaluate(model, meta, data, n_boot=200)
        summ.insert(0, "model", name)
        rows.append(summ)
        print(f"{name}: synthetic-test AUC = {summ.set_index('metric').loc['roc_auc', 'estimate']:.3f} "
              "(training data re-scored; should equal apparent training AUC)")
        assert abs(summ.set_index("metric").loc["roc_auc", "estimate"] - meta["apparent_auc_training"]) < 1e-9
    out = pd.concat(rows)
    run.save_csv(out, "SYNTHETIC_TEST_NOT_A_RESULT.csv")
    checks = pd.DataFrame([
        ("education round trip exact", bool(rt == 1.0)),
        ("harmonised cohort size = 166", len(data) == 166),
        ("locked artifact hashes verified", True),
        ("synthetic AUC equals locked apparent AUC", True),
    ], columns=["check", "passed"])
    print(checks.to_string(index=False))
    run.save_csv(checks, "pipeline_test_checks.csv")
