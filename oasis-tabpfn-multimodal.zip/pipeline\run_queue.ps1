# Resumable work queue (see queue.txt).
#  - skips steps whose run_manifest.json says success for the CURRENT script hash
#  - Python steps resume inside a step from outputs/_cache and fold checkpoints
#  - stops the version search once any part19_v*/verdict.json has SIGNIFICANTLY_BETTER = true
#  - retries a failed step once; single instance via lock file
# Started automatically at logon by the scheduled task "JBHI_pipeline_resume".
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
$py = "python"
# Work offline: TabPFN v2 weights are already downloaded; never wait on the network.
$env:HF_HUB_OFFLINE = "1"
$env:TABPFN_DISABLE_TELEMETRY = "1"
# Two OpenMP runtimes (MKL + torch) are present in this Anaconda install; this flag was verified to
# reproduce a known TabPFN fold exactly (MCC 1.000, Brier 0.0076, k = 64) on 2026-10-27.
$env:KMP_DUPLICATE_LIB_OK = "TRUE"
# Restart the OASIS-1 downloader if it has not finished (it has its own lock and resumes per byte).
if (-not (Test-Path (Join-Path (Split-Path $PSScriptRoot -Parent) "oasis1_raw\DOWNLOAD_COMPLETE.txt"))) {
    $dl = Join-Path $PSScriptRoot "download_oasis1.ps1"
    Start-Process powershell -WindowStyle Hidden -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$dl`""
}
$out = Join-Path $PSScriptRoot "outputs"
$logDir = Join-Path $out "_runner"
New-Item -ItemType Directory -Force $logDir | Out-Null
$status = Join-Path $logDir "queue_status.txt"
$lock = Join-Path $logDir "queue.lock"

function Log($msg) { "$(Get-Date -Format s)  $msg" | Out-File $status -Append -Encoding utf8 }

if (Test-Path $lock) {
    $old = Get-Content $lock -ErrorAction SilentlyContinue
    if ($old -and (Get-Process -Id $old -ErrorAction SilentlyContinue)) { exit 0 }
}
$PID | Out-File $lock -Encoding ascii
Log "queue runner started (pid $PID)"

function Is-Done($script, $phase) {
    $man = Join-Path $out "$phase\run_manifest.json"
    if (-not (Test-Path $man)) { return $false }
    $m = Get-Content $man -Raw | ConvertFrom-Json
    $h = (Get-FileHash (Join-Path $PSScriptRoot $script) -Algorithm SHA256).Hash.ToLower()
    return ($m.status -eq "success" -and $m.script.sha256 -eq $h)
}

function Significant-Found {
    foreach ($v in Get-ChildItem $out -Directory -Filter "part19_v*") {
        $f = Join-Path $v.FullName "verdict.json"
        if (Test-Path $f) {
            $j = Get-Content $f -Raw | ConvertFrom-Json
            if ($j.SIGNIFICANTLY_BETTER -eq $true) { return $v.Name }
        }
    }
    return $null
}

try {
  do {
    $ranAny = $false                                   # re-read queue.txt until a pass runs nothing new
    foreach ($line in Get-Content (Join-Path $PSScriptRoot "queue.txt")) {
        if ($line -match "^\s*#" -or $line.Trim() -eq "") { continue }
        $type, $script, $phase = $line.Split("|")
        if ($type -eq "version") {
            $sig = Significant-Found
            if ($sig) { Log "SKIP $script (significant version already found: $sig)"; continue }
        }
        if (Is-Done $script $phase) { Log "DONE-ALREADY $script"; continue }
        $ok = $false
        foreach ($attempt in 1, 2) {
            Log "RUN  $script (attempt $attempt)"
            & $py -u $script *>> (Join-Path $logDir ($script -replace '\.py$', '.log'))
            if ($LASTEXITCODE -eq 0) { $ok = $true; break }
            Log "FAIL $script exit=$LASTEXITCODE"
        }
        if (-not $ok) { Log "STOPPED at $script"; exit 1 }
        Log "OK   $script"
        $ranAny = $true
        if ($type -eq "version") {
            $sig = Significant-Found
            if ($sig) { Log "SIGNIFICANT VERSION FOUND: $sig" }
        }
    }
  } while ($ranAny)
    Log "QUEUE COMPLETE"
}
finally {
    Remove-Item $lock -ErrorAction SilentlyContinue
}
