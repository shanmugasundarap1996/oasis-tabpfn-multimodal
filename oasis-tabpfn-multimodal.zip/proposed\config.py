"""Configuration of the proposed framework (PCA-fused MRI + clinical features -> TabPFN v2)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "outputs"

CLINICAL_FILE = DATA_DIR / "oasis_cross-sectional.csv"   # OASIS-1 clinical table
EMBED_FILE = DATA_DIR / "mri_embeddings_own.csv"         # subject_id, emb_0 ... emb_511 (extract_mri_features.py)
COHORT_IDS = DATA_DIR / "cohort_ids.csv"                 # the 166 analysed subjects (fixes the published cohort)

# Cohort
MIN_AGE = 60
TARGET = "target_binary"            # 0: CDR = 0, 1: CDR > 0  (CDR is never a predictor)

# Inputs
# Column order matters for TabPFN's internal ensembling; this order reproduces the paper's results.
CLINICAL = ["Age", "sex_binary", "Educ", "SES", "eTIV", "nWBV", "ASF", "MMSE"]
EMBED_PREFIX = "emb_"
N_EMBED = 512

# Proposed model
PCA_GRID = [8, 16, 24, 32, 64]      # MRI PCA dimension k, chosen by inner cross-validation
TUNING_SCORING = "roc_auc"
THRESHOLD = 0.5
RANDOM_STATE = 42

# Evaluation protocol
OUTER_SEEDS = [42, 2026, 3407, 7319, 9871]   # 5-fold CV x 5 seeds = 25 outer test folds
N_OUTER = 5
N_INNER = 3                                  # inner seed = outer seed * 100 + outer fold
