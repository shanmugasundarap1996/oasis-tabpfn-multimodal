"""Part 19 v9 - TabPFN with the input feature set chosen per outer fold by inner-CV ROC-AUC
among {full, transportable, MRI+MMSE, MRI+MMSE+Age} (MRI PCA k = 16), + inner-tuned MCC threshold.
Lets the model drop clinical variables that add noise. Resumable."""
from sklearn.metrics import roc_auc_score

import config
from common import PhaseRun
from newmethods import BASELINE_FILE, PROTOCOL_FILE, run_cached_version

SETS = ["full", "transport", "mri_mmse", "mri_mmse_age"]
KEYS = [f"tabpfn|{s}|16" for s in SETS]


def combine(P, y):
    auc = {k: roc_auc_score(y, P[k]["oof"]) for k in KEYS}
    best = max(auc, key=auc.get)
    return P[best]["oof"], P[best]["test"], {"selected_set": best.split("|")[1], **{f"inner_auc_{k.split('|')[1]}": v for k, v in auc.items()}}


with PhaseRun("part19_v9_tabpfn_featsel", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"keys": KEYS, "selection": "inner-OOF ROC-AUC", "threshold": "inner-OOF MCC-optimal"}) as run:
    run_cached_version(run, "v9_tabpfn_featsel", KEYS, combine)
