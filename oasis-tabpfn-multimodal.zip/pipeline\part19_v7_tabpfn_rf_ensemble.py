"""Part 19 v7 - Probability average of TabPFN and fusion-RF (both with inner-CV-selected settings)
+ inner-tuned MCC threshold. Combines the best-calibrated and the highest-MCC baseline. Resumable."""
import config
from common import PhaseRun
from newmethods import BASELINE_FILE, PROTOCOL_FILE, run_cached_version

KEYS = ["tabpfn|full|sel", "rf|sel"]


def combine(P, y):
    return (sum(P[k]["oof"] for k in KEYS) / len(KEYS), sum(P[k]["test"] for k in KEYS) / len(KEYS), None)


with PhaseRun("part19_v7_tabpfn_rf_ensemble", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"keys": KEYS, "combination": "mean probability", "threshold": "inner-OOF MCC-optimal"}) as run:
    run_cached_version(run, "v7_tabpfn_rf_ensemble", KEYS, combine)
