"""Part 27d - Sensitivity analysis without SES (missing almost only in the dementia group):
proposed TabPFN and fusion-RF with the 7 clinical variables excluding SES; compared with the full models."""
import pandas as pd

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from compare_tools import paired_table, pca_grid, tabpfn_spec
from models import build

V5 = config.OUTPUT_DIR / "part19_v5_tabpfn" / "fold_metrics.csv"
P07 = config.OUTPUT_DIR / "part07_fusion" / "fold_metrics.csv"

with PhaseRun("part27d_no_ses", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, V5, P07]) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    no_ses = [c for c in config.CLINICAL_FULL if c != "SES"]          # order preserved
    specs = [tabpfn_spec("noSES", emb, no_ses)]
    pipe, grid = build("RF", mri_cols=emb, tab_cols=no_ses, pca_dim=8, extra_grid=pca_grid())
    specs.append({"group": "noSES", "name": "Fusion_PCA_RF", "features": emb + no_ses, "pipeline": pipe, "grid": grid})
    folds, preds, params = run_nested_cv(df, specs, ckpt_dir=str(run.dir / "_ckpt"))
    run.save_csv(folds, "fold_metrics.csv"); run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summ = summarize(folds); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "mcc", "roc_auc", "brier"]].to_string(index=False))
    full_tab = pd.read_csv(V5)
    p7 = pd.read_csv(P07)
    full_rf = p7[(p7.group == "Fusion_PCA_nested") & (p7.model == "RF")]
    t1 = paired_table(full_tab, "TabPFN_full", {"TabPFN_noSES": folds[folds.model == "TabPFN_v2"]})
    t2 = paired_table(full_rf, "RF_full", {"RF_noSES": folds[folds.model == "Fusion_PCA_RF"]})
    t3 = paired_table(folds[folds.model == "TabPFN_v2"], "TabPFN_noSES", {"RF_noSES": folds[folds.model == "Fusion_PCA_RF"]})
    tab = pd.concat([t1, t2, t3]); run.save_csv(tab, "no_ses_comparisons.csv")
    print(tab.round(4).to_string(index=False))
    assert check_oof_integrity(preds, df)
