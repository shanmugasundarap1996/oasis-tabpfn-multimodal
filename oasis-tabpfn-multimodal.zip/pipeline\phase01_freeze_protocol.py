"""Phase 01 - Freeze the scientific problem: task, target, exclusion rule,
research questions, validation protocol. Writes a hash-stamped protocol record."""
import config
from common import PhaseRun

RESEARCH_QUESTIONS = {
    "RQ1_modality_value": "Does combining MRI representations with clinical/cognitive "
                          "information improve classification over individual modalities?",
    "RQ2_graph_value": "Does modelling patient similarity through population graphs improve "
                       "classification over conventional multimodal fusion?",
    "RQ3_generalization": "Do apparent graph-learning improvements persist under repeated "
                          "cross-validation and strict inductive evaluation?",
    "RQ4_reliability": "Are predictions sufficiently calibrated and interpretable for "
                       "biomedical decision-support settings?",
}

NOT_CLAIMED = [
    "early AD prediction",
    "disease progression prediction",
    "future conversion prediction (MCI-to-AD)",
    "whole-volume 3D MRI modelling (unless Phase 05 audit shows 3D input)",
]

PLAN_FILE = config.PIPELINE_DIR / "IMPLEMENTATION_PLAN.md"

with PhaseRun("phase01_protocol", __file__, inputs=[PLAN_FILE]) as run:
    protocol = {
        "task": config.TASK,
        "dataset": "OASIS-1 cross-sectional",
        "target": {
            "column": config.TARGET_COL,
            "definition": "0 if CDR == 0; 1 if CDR > 0",
            "source": config.TARGET_SOURCE,
        },
        "inclusion": [
            "clinical record and MRI embedding available (subject-level match)",
            "CDR available",
            f"Age >= {config.MIN_AGE}",
            "one row per subject (first session; reliability rescans excluded)",
        ],
        "exclusion_rule": "CDR defines the target and must never enter the predictor matrix. "
                          "Forbidden predictors: " + ", ".join(config.FORBIDDEN_PREDICTORS),
        "feature_sets": {
            "C1_demographics": config.DEMOGRAPHICS,
            "C2_mri_biomarkers": config.MRI_BIOMARKERS,
            "C3_cognitive": config.COGNITIVE,
            "C4_clinical_no_mmse": config.CLINICAL_NO_MMSE,
            "C5_clinical_full": config.CLINICAL_FULL,
            "MRI_embedding": f"{config.N_EMBED}-D ({config.EMBED_PREFIX}0..{config.N_EMBED - 1})",
        },
        "validation": {
            "outer": f"{config.N_OUTER_FOLDS}-fold stratified CV x {len(config.OUTER_SEEDS)} seeds "
                     f"= {config.N_OUTER_FOLDS * len(config.OUTER_SEEDS)} outer test evaluations",
            "outer_seeds": config.OUTER_SEEDS,
            "inner": f"{config.N_INNER_FOLDS}-fold stratified CV inside each outer training set "
                     "for all tuning (PCA dim, K, hyperparameters, thresholds)",
            "fit_inside_training_fold_only": ["imputation", "scaling", "PCA", "feature selection",
                                              "hyperparameter tuning", "graph construction",
                                              "calibration", "threshold selection"],
            "same_splits_for_every_model": True,
            "tuning_criterion": f"inner-CV {config.TUNING_SCORING}",
            "decision_threshold": config.DECISION_THRESHOLD,
        },
        "metrics": {
            "primary": config.PRIMARY_METRICS,
            "secondary": config.SECONDARY_METRICS,
            "reliability": config.RELIABILITY_METRICS,
        },
        "search_grids": {"pca_dims": config.PCA_DIMS, "knn_k": config.KNN_K},
        "statistics": "Paired Wilcoxon signed-rank on the 25 outer folds; Holm-Bonferroni; "
                      "rank-biserial effect size; mean difference with 95% CI.",
        "external_validation": {
            "primary": "OASIS-3", "secondary": "ADNI",
            "rule": "locked models only; external data never used for training, tuning or model choice",
            "transportable_clinical": config.TRANSPORTABLE_CLINICAL,
        },
        "research_questions": RESEARCH_QUESTIONS,
        "not_claimed": NOT_CLAIMED,
    }
    run.save_json(protocol, "protocol_frozen.json")

    md = ["# Phase 01 - Frozen Study Protocol", "",
          f"**Task.** {config.TASK}", "",
          "**Target.** y = 0 if CDR = 0; y = 1 if CDR > 0.", "",
          f"**Exclusion rule.** {protocol['exclusion_rule']}", "",
          "## Research questions"]
    md += [f"- **{k}**: {v}" for k, v in RESEARCH_QUESTIONS.items()]
    md += ["", "## Claims this study does NOT make"] + [f"- {c}" for c in NOT_CLAIMED]
    md += ["", "## Validation", f"- Outer: {protocol['validation']['outer']}",
           f"- Seeds: {config.OUTER_SEEDS}", f"- Inner: {protocol['validation']['inner']}",
           "- Fitted inside training folds only: "
           + ", ".join(protocol["validation"]["fit_inside_training_fold_only"])]
    run.save_text("\n".join(md) + "\n", "protocol_frozen.md")
