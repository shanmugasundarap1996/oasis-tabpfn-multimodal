"""Part 27b - Modern gradient-boosting baselines (CatBoost, LightGBM) on PCA fusion, nested tuning,
same frozen folds; compared with the proposed TabPFN (Part 19 v5). Resumable per fold."""
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.pipeline import Pipeline

import pandas as pd

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from compare_tools import paired_table, pca_grid
from models import preprocessor

V5 = config.OUTPUT_DIR / "part19_v5_tabpfn" / "fold_metrics.csv"

with PhaseRun("part27b_modern_baselines", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, V5]) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    C5 = config.CLINICAL_FULL
    cat = Pipeline([("prep", preprocessor(emb, C5, pca_dim=8)),
                    ("clf", CatBoostClassifier(iterations=300, auto_class_weights="Balanced", verbose=0,
                                               random_seed=42, thread_count=1))])
    lgb = Pipeline([("prep", preprocessor(emb, C5, pca_dim=8)),
                    ("clf", LGBMClassifier(n_estimators=200, class_weight="balanced", random_state=42,
                                           n_jobs=1, verbose=-1))])
    specs = [{"group": "Fusion_PCA_nested", "name": "CatBoost", "features": emb + C5, "pipeline": cat,
              "grid": {**pca_grid(), "clf__depth": [4, 6], "clf__learning_rate": [0.03, 0.1]}},
             {"group": "Fusion_PCA_nested", "name": "LightGBM", "features": emb + C5, "pipeline": lgb,
              "grid": {**pca_grid(), "clf__num_leaves": [7, 15], "clf__learning_rate": [0.03, 0.1],
                       "clf__min_child_samples": [5, 10]}}]
    folds, preds, params = run_nested_cv(df, specs, ckpt_dir=str(run.dir / "_ckpt"))
    run.save_csv(folds, "fold_metrics.csv"); run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summ = summarize(folds); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "mcc", "roc_auc", "brier"]].to_string(index=False))
    ref = pd.read_csv(V5)
    tab = paired_table(ref, "TabPFN_v2", {m: folds[folds.model == m] for m in folds.model.unique()})
    run.save_csv(tab, "tabpfn_vs_modern_baselines.csv")
    print(tab.round(4).to_string(index=False))
    assert check_oof_integrity(preds, df)
