"""Fit the proposed framework on the whole cohort and predict new subjects.

Usage:  python predict_new.py new_subjects.csv  [output.csv]
new_subjects.csv needs the 8 clinical columns (Age, sex_binary [F=0, M=1], Educ, SES, MMSE, eTIV, nWBV,
ASF; missing values allowed) and emb_0 ... emb_511 produced by the same MRI feature extractor.
k is chosen by 5-fold cross-validation on the full cohort.
"""
import sys

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold

import config
from data_prep import build_cohort, embedding_cols
from model import fit_with_inner_cv, selected_k

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    df = build_cohort()
    emb = embedding_cols(df)
    feats = emb + config.CLINICAL
    cv = list(StratifiedKFold(5, shuffle=True, random_state=config.RANDOM_STATE)
              .split(np.zeros(len(df)), df["target_3class"]))
    gs = fit_with_inner_cv(df[feats], df[config.TARGET].to_numpy(), emb, cv)
    print(f"fitted on {len(df)} subjects, selected k = {selected_k(gs)}, CV AUC = {gs.best_score_:.3f}")

    new = pd.read_csv(sys.argv[1])
    prob = gs.predict_proba(new[feats])[:, 1]
    out = pd.DataFrame({"subject_id": new.get("subject_id", pd.Series(range(len(new)))),
                        "P_CDR_gt_0": prob, "prediction": np.where(prob >= config.THRESHOLD,
                                                                   "dementia spectrum", "cognitively normal")})
    path = sys.argv[2] if len(sys.argv) > 2 else "predictions.csv"
    out.to_csv(path, index=False)
    print(out.to_string(index=False))
    print("saved", path)
