# Runs pipeline parts sequentially (detached, no time limit); stops at the first failure.
# Usage: powershell -File run_pipeline.ps1 part05_mri_embedding.py part06_mri_pca.py ...
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
$py = "python"
$logDir = Join-Path $PSScriptRoot "outputs\_runner"
New-Item -ItemType Directory -Force $logDir | Out-Null
$status = Join-Path $logDir "status.txt"
"started $(Get-Date -Format s)" | Out-File $status -Encoding utf8
foreach ($s in $args) {
    "RUNNING  $s  $(Get-Date -Format s)" | Out-File $status -Append -Encoding utf8
    & $py -u $s *> (Join-Path $logDir ($s -replace '\.py$', '.log'))
    if ($LASTEXITCODE -ne 0) {
        "FAILED   $s  exit=$LASTEXITCODE  $(Get-Date -Format s)" | Out-File $status -Append -Encoding utf8
        exit 1
    }
    "DONE     $s  $(Get-Date -Format s)" | Out-File $status -Append -Encoding utf8
}
"ALL DONE $(Get-Date -Format s)" | Out-File $status -Append -Encoding utf8
