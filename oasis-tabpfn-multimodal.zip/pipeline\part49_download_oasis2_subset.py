"""Part 49 - Amendment 9 addendum: stream the open OASIS-2 raw archives and extract only the first-visit (MR1) RAW
MPRAGE files of the 29 overlap-screened participants (Part 42 rule). Resumable: sessions already on disk are
skipped; an archive is marked done when fully streamed."""
import tarfile
import urllib.request

import pandas as pd

import config
from common import PhaseRun

URL = "https://download.nrg.wustl.edu/data/OAS2_RAW_PART{}.tar.gz"
DEST = config.BASE_DIR / "oasis2_raw"
FLAGS = config.OUTPUT_DIR / "part42_external_clinical" / "overlap_flags.csv"

with PhaseRun("part49_download_oasis2_subset", __file__, inputs=[FLAGS]) as run:
    flags = pd.read_csv(FLAGS)
    need = {f"{s}_MR1" for s in flags.subject_id[flags.n_candidates == 0]}
    have = {p.name for p in DEST.glob("OAS2_RAW_PART*/*_MR1") if len(list((p / "RAW").glob("mpr-*.nifti.img"))) > 0}
    print(f"overlap-screened sessions: {len(need)}; already on disk: {len(need & have)}", flush=True)
    for part in (1, 2):
        marker = DEST / f"_streamed_PART{part}.txt"
        if marker.exists() or need <= have:
            continue
        with urllib.request.urlopen(URL.format(part), timeout=120) as resp, tarfile.open(fileobj=resp, mode="r|gz") as tf:
            for m in tf:
                parts = m.name.split("/")
                if len(parts) >= 4 and parts[1] in need and parts[2] == "RAW" and parts[1] not in have:
                    tf.extract(m, DEST, filter="data")
                    if m.name.endswith(".img"):
                        print(f"  {m.name}", flush=True)
        marker.write_text("done")
        have = {p.name for p in DEST.glob("OAS2_RAW_PART*/*_MR1") if len(list((p / "RAW").glob("mpr-*.nifti.img"))) > 0}
    missing = sorted(need - have)
    run.save_csv(pd.DataFrame({"session": sorted(need), "on_disk": [s in have for s in sorted(need)]}), "subset_status.csv")
    print(f"done; missing: {missing}")
