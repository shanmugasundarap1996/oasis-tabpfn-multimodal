"""Part 39 - Amendment 6, families M1 and M2 (label-free ResNet MRI features, N = 166, frozen folds).

M1: does MRI add to NON-IMAGING clinical data?  NI = Age, sex, Educ, SES, MMSE (eTIV/nWBV/ASF are MRI-derived).
M2: does MRI help WITHOUT cognitive testing?    NM = Age, sex, Educ, SES, eTIV, nWBV, ASF (no MMSE);
    secondary: MRI + demographics only vs demographics only.
Wilcoxon + Holm within each family (primary), Nadeau-Bengio (sensitivity). Resumable per fold."""
import pandas as pd
from sklearn.pipeline import Pipeline
from threadpoolctl import threadpool_limits

import config
import tabpfn_retry  # noqa: F401  (retries sporadic ARPACK failures in the main-process refit)
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from compare_tools import paired_table, pca_grid, tabpfn_spec
from models import build, preprocessor

threadpool_limits(1, user_api="blas")      # avoid the MKL LU livelock seen in Part 36
OWN = config.RAW_DIR / "mri_embeddings_own.csv"
P04 = config.OUTPUT_DIR / "part04_clinical" / "fold_metrics.csv"
DEMO = ["Age", "sex_binary", "Educ", "SES"]
NI = DEMO + ["MMSE"]                       # non-imaging clinical (CLINICAL_FULL order kept)
NM = config.CLINICAL_NO_MMSE               # Age, sex, Educ, SES, eTIV, nWBV, ASF


def tabpfn_clin(group, tab, name):
    from tabpfn import TabPFNClassifier
    from tabpfn.constants import ModelVersion
    pipe = Pipeline([("prep", preprocessor((), tab)),
                     ("clf", TabPFNClassifier.create_default_for_version(ModelVersion.V2, device="cpu", random_state=42))])
    return {"group": group, "name": name, "features": list(tab), "pipeline": pipe, "grid": {"clf__random_state": [42]}}


def tab_spec(group, name, learner, tab):
    pipe, grid = build(learner, tab_cols=tab)
    return {"group": group, "name": name, "features": list(tab), "pipeline": pipe, "grid": grid}


def fusion_spec(group, name, learner, mri, tab):
    pipe, grid = build(learner, mri_cols=mri, tab_cols=tab, pca_dim=8, extra_grid=pca_grid())
    return {"group": group, "name": name, "features": mri + list(tab), "pipeline": pipe, "grid": grid}


with PhaseRun("part39_clinical_sensitivity", __file__,
              inputs=[config.COHORT_FILE, OWN, config.FOLDS_FILE, config.INNER_FOLDS_FILE, P04],
              params={"NI": NI, "NM": NM, "DEMO": DEMO}) as run:
    base = load_cohort()
    df = base.drop(columns=embedding_cols(base)).merge(pd.read_csv(OWN), on="subject_id", how="left", validate="one_to_one")
    df = df.set_index("subject_id").loc[base.subject_id].reset_index()
    emb = embedding_cols(df)

    specs = [tabpfn_spec("M1", emb, NI, name="TabPFN_MRI_NI"), tabpfn_clin("M1", NI, "TabPFN_NI"),
             tab_spec("M1", "LR_NI", "LR", NI), tab_spec("M1", "XGBoost_NI", "XGBoost", NI),
             fusion_spec("M1", "Fusion_LR_MRI_NI", "LR", emb, NI),
             tabpfn_spec("M2", emb, NM, name="TabPFN_MRI_NM"), tabpfn_clin("M2", NM, "TabPFN_NM"),
             fusion_spec("M2", "Fusion_RF_MRI_NM", "RF", emb, NM), fusion_spec("M2", "Fusion_LR_MRI_NM", "LR", emb, NM),
             tabpfn_spec("M2", emb, DEMO, name="TabPFN_MRI_DEMO"), tabpfn_clin("M2", DEMO, "TabPFN_DEMO")]
    folds, preds, params = run_nested_cv(df, specs, ckpt_dir=str(run.dir / "_ckpt"))
    run.save_csv(folds, "fold_metrics.csv"); run.save_csv(preds, "oof_predictions.csv"); run.save_csv(params, "best_params.csv")
    summ = summarize(folds); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "mcc", "roc_auc", "brier"]].to_string(index=False), flush=True)

    F = lambda m: folds[folds.model == m]
    clin = pd.read_csv(P04)
    m1 = paired_table(F("TabPFN_MRI_NI"), "TabPFN[MRI+NI]",
                      {m: F(m) for m in ["TabPFN_NI", "LR_NI", "XGBoost_NI"]})
    m2 = paired_table(F("TabPFN_MRI_NM"), "TabPFN[MRI+NM]",
                      {"TabPFN_NM": F("TabPFN_NM"), "Fusion_RF_MRI_NM": F("Fusion_RF_MRI_NM"),
                       "Fusion_LR_MRI_NM": F("Fusion_LR_MRI_NM"),
                       "Clinical_C4_LR": clin[(clin.group == "C4_clinical_no_MMSE") & (clin.model == "LR")]})
    m2b = paired_table(F("TabPFN_MRI_DEMO"), "TabPFN[MRI+DEMO]", {"TabPFN_DEMO": F("TabPFN_DEMO")})
    for t, n in [(m1, "M1_mri_beyond_nonimaging.csv"), (m2, "M2_without_mmse.csv"), (m2b, "M2b_mri_plus_demographics.csv")]:
        run.save_csv(t, n)
        print(n, "\n", t[t.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False), flush=True)
    assert check_oof_integrity(preds, df)
