"""Part 48 - Amendment 9: locked external validation of the frozen OASIS-1 models (Part 47, harmonised MRI).

Sources
  adni        : ADNI (requires approved access). Place in data/external_adni/:
                  ADNIMERGE.csv              (VERIFY column names against the ADNI data dictionary)
                  CDR.csv (optional)         (CDGLOBAL by RID/VISCODE2; enables the CDR 0 vs > 0 labeling)
                  MRI/<PTID>/**/<*.nii|*.nii.gz> baseline T1 MPRAGE (NIfTI download from ida.loni.usc.edu)
  oasis2      : OASIS-2 visit 1 (CDR 0 vs > 0); primary subset = 29 overlap-screened participants (Part 42 rule);
                all image-available sessions reported only as a contamination illustration (Amendment 9 addendum).

Steps: cohort -> clinical harmonisation -> overlap screen vs OASIS-1 -> pipeline H on external T1 (reoriented to the
OASIS-1 array convention) -> study-label-free ResNet features -> locked inference -> metrics with bootstrap CIs,
calibration, paired comparisons, subgroups, internal-vs-external table. No external label is used before
evaluation. Usage: python part48_external_locked.py adni | oasis2"""
import json
import sys

import joblib
import nibabel as nib
import numpy as np
import pandas as pd

import config
import external_tools as et
import part43_harmonised_mri as H
import tabpfn_retry  # noqa: F401
from common import PhaseRun, sha256
from external_validation import educ_years_to_oasis1

SOURCE = sys.argv[1] if len(sys.argv) > 1 else "adni"
FROZEN = config.OUTPUT_DIR / "part47_frozen_harmonised"
ADNI = config.RAW_DIR / "external_adni"
CACHE = config.BASE_DIR / "mri_harmonised" / SOURCE
# VERIFY against the ADNI data dictionary once the files are available
ADNI_COLS = {"id": "PTID", "rid": "RID", "visit": "VISCODE", "age": "AGE", "sex": "PTGENDER", "male": "Male",
             "educ": "PTEDUCAT", "mmse": "MMSE", "dx": "DX_bl", "site": "SITE"}


def load_external_t1(paths):
    """External NIfTI -> arrays in the OASIS-1 raw convention used by pipeline H (axes L, A, S; i.e. canonical RAS
    with the first axis flipped), plus voxel spacing."""
    vols, spacing = [], None
    for p in paths:
        img = nib.as_closest_canonical(nib.load(str(p)))
        a = np.asarray(img.dataobj).squeeze().astype(np.float32)[::-1, :, :]
        vols.append(a)
        spacing = tuple(float(z) for z in img.header.get_zooms()[:3])
    return vols, spacing


def adni_cohort():
    d = pd.read_csv(ADNI / "ADNIMERGE.csv", low_memory=False)
    c = ADNI_COLS
    d = d[(d[c["visit"]] == "bl") & (d[c["age"]] >= config.MIN_AGE) & d[c["mmse"]].notna()].copy()
    out = pd.DataFrame({"subject_id": d[c["id"]].astype(str), "rid": d[c["rid"]], "Age": d[c["age"]].astype(float),
                        "sex_binary": (d[c["sex"]] == c["male"]).astype(int), "Educ": educ_years_to_oasis1(d[c["educ"]]),
                        "MMSE": d[c["mmse"]].astype(float), "dx": d[c["dx"]], "site": d.get(c["site"])})
    out["label_dx"] = out.dx.map({"CN": 0, "AD": 1})             # MCI / SMC excluded from this labeling
    if (ADNI / "CDR.csv").exists():
        cdr = pd.read_csv(ADNI / "CDR.csv", low_memory=False)
        cdr = cdr[cdr.VISCODE2.isin(["sc", "bl"])].sort_values("VISCODE2").drop_duplicates("RID", keep="last")
        out = out.merge(cdr[["RID", "CDGLOBAL"]].rename(columns={"RID": "rid"}), on="rid", how="left")
        out["label_cdr"] = np.where(out.CDGLOBAL.isna() | (out.CDGLOBAL < 0), np.nan, (out.CDGLOBAL > 0).astype(float))
    mri = {}
    for sid in out.subject_id:
        files = sorted((ADNI / "MRI" / sid).rglob("*.nii*")) if (ADNI / "MRI" / sid).exists() else []
        if files:
            mri[sid] = [files[0]]                                   # earliest-sorted baseline T1 (VERIFY naming)
    out["mri_paths"] = out.subject_id.map(mri)
    return out


def oasis2_cohort():
    """OASIS-2 visit 1 with raw MR1 scans on disk; label = CDR 0 vs > 0; overlap flags from the Part 42 rule."""
    ext = et.load_oasis2()
    dirs = {p.name: p for p in (config.BASE_DIR / "oasis2_raw").glob("OAS2_RAW_PART*/*_MR1")}
    ext["mri_paths"] = ext.mri_id.map(
        lambda m: (sorted((dirs[m] / "RAW").glob("mpr-*.nifti.img")) or None) if m in dirs else None)
    ext["label_cdr"] = ext[config.TARGET_COL].astype(float)
    flags = pd.read_csv(config.OUTPUT_DIR / "part42_external_clinical" / "overlap_flags.csv")
    ext["overlap_candidates"] = ext.subject_id.map(flags.set_index("subject_id").n_candidates)
    return ext


def overlap_screen(ext):
    o1 = pd.read_csv(config.CLINICAL_FILE)
    o1 = o1[o1.ID.str.endswith("_MR1")].assign(sex_binary=lambda x: (x["M/F"] == "M").astype(int))
    flag = []
    for _, r in ext.iterrows():
        c = o1[(o1.sex_binary == r.sex_binary) & (o1.Educ == r.Educ) & (o1.MMSE == r.MMSE)
               & (r.Age - o1.Age).between(-2, 10)]
        flag.append(len(c))
    return np.array(flag)


def features(ext):
    tmpl, mask = H.load_template()
    model = H.resnet()
    CACHE.mkdir(parents=True, exist_ok=True)
    rows = []
    for _, r in ext.iterrows():
        f = CACHE / f"{r.subject_id}.npz"
        if not f.exists():
            vols, spacing = load_external_t1(r.mri_paths)
            vol, info = H.harmonise_arrays(vols, spacing, tmpl, mask)
            np.savez_compressed(f, emb=H.embed(model, H.slices(vol)).astype(np.float32),
                                qc_axial=np.rot90(vol[:, :, vol.shape[2] // 2]).astype(np.float16), **info)
        rows.append({"subject_id": r.subject_id, **{f"emb_{j}": float(v) for j, v in enumerate(np.load(f)["emb"])}})
        print(f"  features {r.subject_id}", flush=True)
    return pd.DataFrame(rows)


with PhaseRun(f"part48_external_{SOURCE}", __file__, inputs=[FROZEN / "FROZEN_MODELS.json"],
              params={"source": SOURCE, "adni_columns": ADNI_COLS}) as run:
    frozen = json.loads((FROZEN / "FROZEN_MODELS.json").read_text(encoding="utf-8"))
    ext = adni_cohort() if SOURCE == "adni" else oasis2_cohort()
    ext = ext[ext.mri_paths.notna()].reset_index(drop=True)
    if SOURCE == "adni":
        ext["overlap_candidates"] = overlap_screen(ext)
    print(f"external subjects with T1: {len(ext)}; overlap-flagged: {int((ext.overlap_candidates > 0).sum())}", flush=True)
    data = ext.merge(features(ext), on="subject_id")
    run.save_csv(data.drop(columns=["mri_paths"]), "external_cohort_with_features.csv")

    models = {}
    for name, m in frozen["models"].items():
        art = FROZEN / m["artifact"]
        assert sha256(art) == m["artifact_sha256"], f"{name}: frozen artifact changed"
        if all(c in data.columns for c in m["features_in_order"]):
            models[name] = (joblib.load(art), m["features_in_order"])
    labels = [l for l in ("label_dx", "label_cdr") if l in data.columns]
    for lab in labels:
        for subset, keep in [("all", np.ones(len(data), bool)), ("overlap-screened", (data.overlap_candidates == 0).to_numpy())]:
            d = data[keep & data[lab].notna().to_numpy()]
            if d[lab].nunique() < 2:
                print(f"  {lab}/{subset}: one class only, skipped"); continue
            yv = d[lab].astype(int).to_numpy()
            probs = {n: mdl.predict_proba(d[f])[:, 1] for n, (mdl, f) in models.items()}
            run.save_csv(et.ci_table(yv, probs, f"{lab}/{subset}"), f"metrics_{lab}_{subset}.csv")
            ref = "multimodal_transportable_TabPFN"
            if ref in probs:
                run.save_csv(et.paired_bootstrap(yv, probs, ref), f"paired_{lab}_{subset}.csv")
            sub = []
            for nm, mk in [("female", d.sex_binary == 0), ("male", d.sex_binary == 1), ("age 60-74", d.Age < 75),
                           ("age >=75", d.Age >= 75)]:
                mk = mk.to_numpy()
                if mk.sum() >= 10 and len(np.unique(yv[mk])) == 2 and ref in probs:
                    r = et.metrics_ci(yv[mk], probs[ref][mk])
                    sub.append({"subgroup": nm, "n": int(mk.sum()), **{k: v[0] for k, v in r.items()}})
            run.save_csv(pd.DataFrame(sub), f"subgroups_{lab}_{subset}.csv")
            run.save_csv(d[["subject_id", lab]].assign(**{f"p_{n}": p for n, p in probs.items()}), f"predictions_{lab}_{subset}.csv")
