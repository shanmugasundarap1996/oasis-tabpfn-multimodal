"""External validation toolkit (Part 17): harmonisation of OASIS-3 / ADNI tables to the frozen
OASIS-1 schema, and evaluation of the LOCKED models (hash-verified).

Column names of the external sources MUST be checked against each dataset's data dictionary
before use; the defaults below are the commonly used names and are marked VERIFY.
"""
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold, cross_val_predict

import config
from common import binary_metrics, sha256

LOCK_DIR = config.OUTPUT_DIR / "part17a_locked"

# VERIFY against the data dictionaries after access is granted.
COLUMN_MAPS = {
    "OASIS3": {"subject_id": "OASISID", "age": "age_at_visit", "sex": "GENDER", "educ_years": "EDUC",
               "mmse": "MMSE", "cdr": "CDR", "sex_male_value": 1},
    "ADNI": {"subject_id": "RID", "age": "AGE", "sex": "PTGENDER", "educ_years": "PTEDUCAT",
             "mmse": "MMSE", "cdr": "CDGLOBAL", "sex_male_value": "Male"},
}


def educ_years_to_oasis1(years):
    """OASIS-1 Educ code: 1 < high school, 2 high-school graduate, 3 some college,
    4 college graduate, 5 beyond college."""
    y = pd.to_numeric(years, errors="coerce")
    return pd.Series(np.select([y < 12, y == 12, (y > 12) & (y < 16), y == 16, y > 16], [1, 2, 3, 4, 5],
                               default=np.nan), index=y.index).where(y.notna())


def harmonise(clinical, embeddings, source, min_age=config.MIN_AGE):
    """Map an external clinical table (one row per subject at the MRI-matched visit) and an
    embedding table (subject_id + emb_0..emb_511, produced by the Part 05b extractor) to the
    frozen schema. Returns (harmonised frame, exclusion log)."""
    cm = COLUMN_MAPS[source]
    c = pd.DataFrame({
        "subject_id": clinical[cm["subject_id"]].astype(str),
        "Age": pd.to_numeric(clinical[cm["age"]], errors="coerce"),
        "sex_binary": (clinical[cm["sex"]] == cm["sex_male_value"]).astype(int),
        "Educ": educ_years_to_oasis1(clinical[cm["educ_years"]]),
        "MMSE": pd.to_numeric(clinical[cm["mmse"]], errors="coerce"),
        "CDR": pd.to_numeric(clinical[cm["cdr"]], errors="coerce"),
    })
    log = [("input subjects", len(c))]
    c = c.dropna(subset=["CDR"]); log.append(("CDR available", len(c)))
    c = c[c.Age >= min_age]; log.append((f"age >= {min_age}", len(c)))
    c = c.merge(embeddings.assign(subject_id=embeddings.subject_id.astype(str)), on="subject_id", how="inner")
    log.append(("MRI embedding available", len(c)))
    c[config.TARGET_COL] = (c.CDR > 0).astype(int)
    return c.reset_index(drop=True), pd.DataFrame(log, columns=["step", "n"])


def load_locked(name):
    locked = json.loads((LOCK_DIR / "LOCKED_ARTIFACTS.json").read_text(encoding="utf-8"))
    art = LOCK_DIR / locked[name]["artifact"]
    if sha256(art) != locked[name]["sha256"]:
        raise RuntimeError(f"Locked artifact {art.name} hash mismatch - model was modified.")
    meta = json.loads((LOCK_DIR / f"{name}_metadata.json").read_text(encoding="utf-8"))
    return joblib.load(art), meta


def _logit(p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def evaluate(model, meta, data, n_boot=2000, seed=0):
    """Discrimination + calibration of a locked model on external data, with bootstrap CIs,
    recalibration-in-the-large, subgroup and covariate-shift diagnostics."""
    feats = meta["features_in_order"]
    y = data[config.TARGET_COL].to_numpy()
    prob = model.predict_proba(data[feats])[:, 1]
    pred = (prob >= meta["decision_threshold"]).astype(int)
    point = binary_metrics(y, pred, prob)
    lr = LogisticRegression(C=1e6, max_iter=1000).fit(_logit(prob).reshape(-1, 1), y)
    point["cal_slope"], point["cal_intercept"] = float(lr.coef_[0, 0]), float(lr.intercept_[0])
    # recalibration-in-the-large: shift the intercept so mean prediction = observed prevalence
    from scipy.optimize import brentq
    shift = brentq(lambda a: (1 / (1 + np.exp(-(_logit(prob) + a)))).mean() - y.mean(), -20, 20)
    p_ritl = 1 / (1 + np.exp(-(_logit(prob) + shift)))
    ritl = binary_metrics(y, (p_ritl >= 0.5).astype(int), p_ritl)

    rng = np.random.default_rng(seed)
    boots = []
    for _ in range(n_boot):
        i = rng.integers(0, len(y), len(y))
        if len(np.unique(y[i])) < 2:
            continue
        boots.append(binary_metrics(y[i], pred[i], prob[i]))
    boots = pd.DataFrame(boots)
    summary = pd.DataFrame([{"metric": m, "estimate": point[m],
                             "ci95_low": np.nanpercentile(boots[m], 2.5) if m in boots else np.nan,
                             "ci95_high": np.nanpercentile(boots[m], 97.5) if m in boots else np.nan,
                             "after_recalibration_in_the_large": ritl.get(m, np.nan)}
                            for m in config.ALL_METRICS + ["cal_slope", "cal_intercept"]])

    sub = []
    for name, mask in [("female", data.sex_binary == 0), ("male", data.sex_binary == 1),
                       ("age 60-74", data.Age < 75), ("age >= 75", data.Age >= 75)]:
        m = mask.to_numpy()
        if m.sum() > 10 and len(np.unique(y[m])) == 2:
            r = binary_metrics(y[m], pred[m], prob[m])
            sub.append({"subgroup": name, "n": int(m.sum()), "roc_auc": r["roc_auc"],
                        "balanced_accuracy": r["balanced_accuracy"], "mcc": r["mcc"], "brier": r["brier"]})

    ref = meta["clinical_reference_distribution"]
    shift_rows = [{"feature": f, "oasis1_mean": ref[f]["mean"], "external_mean": data[f].mean(),
                   "standardised_mean_difference": (data[f].mean() - ref[f]["mean"]) / ref[f]["std"]}
                  for f in meta["clinical_features"]]
    preds = data[["subject_id", config.TARGET_COL]].assign(y_prob=prob, y_pred=pred, y_prob_ritl=p_ritl)
    return summary, pd.DataFrame(sub), pd.DataFrame(shift_rows), preds


def domain_shift_auc(oasis1_emb, external_emb, seed=0):
    """How separable the two sources are from MRI embeddings alone (0.5 = no shift)."""
    X = np.vstack([oasis1_emb, external_emb])
    d = np.r_[np.zeros(len(oasis1_emb)), np.ones(len(external_emb))]
    p = cross_val_predict(LogisticRegression(C=0.1, max_iter=5000), X, d,
                          cv=StratifiedKFold(5, shuffle=True, random_state=seed), method="predict_proba")[:, 1]
    return float(roc_auc_score(d, p))
