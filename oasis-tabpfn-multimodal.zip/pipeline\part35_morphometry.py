"""Part 35 - Label-free regional tissue morphometry (Amendment 5, representation R2).

Input : OASIS-1 FSL-FAST segmentation of the atlas-registered first-session volume
        (FSL_SEG/*_t88_masked_gfc_fseg.img, 176 x 208 x 176, labels 0 background, 1 CSF, 2 GM, 3 WM),
        extracted from the 12 downloaded archives (resumable per archive).
Feature: GM and CSF fraction in each 8 mm cube (22 x 26 x 22 grid); a cube is kept for a tissue if its mean
        fraction over all sessions is >= 0.10 (unsupervised prevalence filter, no labels used).
Output: data/mri_morph_own.csv (subject_id, gm_*, csf_*). Resumable: one .npy per session.
"""
import re
import tarfile
from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd

import config
from common import PhaseRun

RAW = config.BASE_DIR / "oasis1_raw"
SEG = config.BASE_DIR / "oasis1_fseg"
CACHE = config.BASE_DIR / "oasis1_morph"
OUT_CSV = config.RAW_DIR / "mri_morph_own.csv"
PATTERN = re.compile(r"_MR1/FSL_SEG/[^/]*_fseg\.(img|hdr)$")
BLOCK, MIN_FRAC = 8, 0.10


def block_fractions(seg):
    s = seg[:176, :208, :176]
    out = []
    for lab in (2, 1):                                   # GM, CSF
        m = (s == lab).astype(np.float32)
        out.append(m.reshape(22, BLOCK, 26, BLOCK, 22, BLOCK).mean(axis=(1, 3, 5)).ravel())
    return np.concatenate(out)


with PhaseRun("part35_morphometry", __file__,
              params={"block_mm": BLOCK, "min_mean_fraction": MIN_FRAC, "tissues": "GM (label 2), CSF (label 1)"}) as run:
    SEG.mkdir(exist_ok=True); CACHE.mkdir(exist_ok=True)
    for i in range(1, 13):
        marker = SEG / f"_done_disc{i}.txt"
        if marker.exists():
            continue
        n = 0
        with tarfile.open(RAW / f"oasis_cross-sectional_disc{i}.tar.gz", "r:gz") as tf:
            for m in tf:
                if m.isfile() and PATTERN.search(m.name):
                    sess = m.name.split("/")[1]
                    dst = SEG / sess / Path(m.name).name
                    dst.parent.mkdir(exist_ok=True)
                    if not (dst.exists() and dst.stat().st_size == m.size):
                        tmp = dst.with_suffix(dst.suffix + ".part")
                        with tf.extractfile(m) as src, open(tmp, "wb") as fh:
                            fh.write(src.read())
                        tmp.replace(dst)
                    n += 1
        marker.write_text(f"{n} files", encoding="utf-8")
        print(f"  disc{i}: {n} segmentation files", flush=True)

    sessions = sorted(p.name for p in SEG.iterdir() if p.is_dir())
    print(f"sessions with segmentation: {len(sessions)}", flush=True)
    labels_seen = None
    for s in sessions:
        f = CACHE / f"{s}.npy"
        if f.exists():
            continue
        seg = np.asarray(nib.load(next((SEG / s).glob("*.img"))).dataobj).squeeze()
        if labels_seen is None:
            labels_seen = sorted(np.unique(seg).tolist())
            print("label values in first segmentation:", labels_seen, flush=True)
            assert set(labels_seen) <= {0, 1, 2, 3}, labels_seen
        tmp = CACHE / f"{s}.tmp.npy"
        np.save(tmp, block_fractions(seg)); tmp.replace(f)
    X = np.stack([np.load(CACHE / f"{s}.npy") for s in sessions])
    nb = 22 * 26 * 22
    names = [f"gm_{j}" for j in range(nb)] + [f"csf_{j}" for j in range(nb)]
    keep = X.mean(0) >= MIN_FRAC
    df = pd.DataFrame(X[:, keep].round(5), columns=[n for n, k in zip(names, keep) if k])
    df.insert(0, "subject_id", [s.replace("_MR1", "") for s in sessions])
    df.to_csv(OUT_CSV, index=False)
    run.outputs.append(OUT_CSV)
    summ = pd.DataFrame({"tissue": ["GM", "CSF"], "cubes_kept": [int(keep[:nb].sum()), int(keep[nb:].sum())],
                         "mean_total_fraction": [float(X[:, :nb].mean()), float(X[:, nb:].mean())]})
    run.save_csv(summ, "morph_summary.csv")
    print(summ.to_string(index=False))
    print(f"saved {OUT_CSV} ({len(df)} subjects x {df.shape[1] - 1} features)")
