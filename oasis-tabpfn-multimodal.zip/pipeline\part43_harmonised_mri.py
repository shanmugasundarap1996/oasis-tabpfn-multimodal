"""Part 43 - Amendment 7, E2: harmonised MRI pipeline H applied identically to OASIS-1 (training) and OASIS-2 (test).

OASIS-2 releases only raw scans, so both cohorts are processed from their raw first-session MPRAGE repeats:
  1. raw arrays (256 x 256 x 128, axes anterior / superior / left-right, 1 x 1 x 1.25 mm) permuted to the T88 axis
     order (left-right, anterior, superior) - identical rule for both releases (checked visually, same protocol);
  2. rigid registration of every repeat to repeat 1, then voxel-wise mean;
  3. N4 bias-field correction;
  4. similarity -> affine registration to a label-free template (voxel-wise mean of all 416 official OASIS-1
     T88 masked images), Mattes MI restricted to the template brain mask (voxels non-zero in >= 50 % of images);
  5. resampling onto the template grid (176 x 208 x 176, 1 mm) and masking with the template brain mask;
  6. the Part 29 slices, intensity scaling and frozen ImageNet ResNet18 (code copied verbatim).
No labels are used. Resumable: one .npz per session in mri_harmonised/<cohort>/.
Usage: python part43_harmonised_mri.py template | oasis1 | oasis2 | collect"""
import shutil
import sys
import tarfile
import time
from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd
import SimpleITK as sitk
import torch
import torch.nn.functional as F
import torchvision

import config
from common import PhaseRun, load_cohort

OUT = config.BASE_DIR / "mri_harmonised"
T88 = config.BASE_DIR / "oasis1_t88"
O1_RAW = config.BASE_DIR / "oasis1_raw"
O2_RAW = config.BASE_DIR / "oasis2_raw"
TMP = OUT / "_tmp_oasis1"
PERM = (2, 0, 1)
RAW_SPACING = (1.25, 1.0, 1.0)          # after permutation
AXIAL = [0.40, 0.45, 0.50, 0.55, 0.60]
CORONAL = [0.45, 0.50, 0.55, 0.60]
MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
sitk.ProcessObject.SetGlobalDefaultNumberOfThreads(4)


# ---------------- Part 29 feature code (verbatim)
def slices(vol):
    brain = vol[vol > 0]
    hi = np.percentile(brain, 99.5) if brain.size else 1.0
    v = np.clip(vol, 0, hi) / hi
    out = [np.rot90(v[:, :, int(round(f * (v.shape[2] - 1)))]) for f in AXIAL]
    out += [np.rot90(v[:, int(round(f * (v.shape[1] - 1))), :]) for f in CORONAL]
    return out


def embed(model, sl):
    x = torch.stack([F.interpolate(torch.tensor(s.copy(), dtype=torch.float32)[None, None], size=(224, 224),
                                   mode="bilinear", align_corners=False)[0, 0] for s in sl])
    x = x[:, None].repeat(1, 3, 1, 1)
    x = (x - MEAN) / STD
    with torch.no_grad():
        return model(x).numpy().mean(0)


# ---------------- harmonised preprocessing
def to_sitk(arr, spacing):
    im = sitk.GetImageFromArray(np.ascontiguousarray(arr.transpose(2, 1, 0)).astype(np.float32))
    im.SetSpacing(spacing)
    return im


def from_sitk(im):
    return sitk.GetArrayFromImage(im).transpose(2, 1, 0)


def load_raw(path):
    return np.asarray(nib.load(str(path)).dataobj).squeeze().astype(np.float32).transpose(PERM)


def register(fixed, moving, tx, shrink, sigma, iters, fixed_mask=None, moving_init=None):
    r = sitk.ImageRegistrationMethod()
    if moving_init is not None:
        r.SetMovingInitialTransform(moving_init)
    r.SetMetricAsMattesMutualInformation(32)
    r.SetMetricSamplingStrategy(r.RANDOM)
    r.SetMetricSamplingPercentage(0.15, 42)
    if fixed_mask is not None:
        r.SetMetricFixedMask(fixed_mask)
    r.SetInterpolator(sitk.sitkLinear)
    r.SetOptimizerAsGradientDescent(learningRate=1.0, numberOfIterations=iters,
                                    convergenceMinimumValue=1e-6, convergenceWindowSize=10)
    r.SetOptimizerScalesFromPhysicalShift()
    r.SetShrinkFactorsPerLevel(shrink)
    r.SetSmoothingSigmasPerLevel(sigma)
    r.SmoothingSigmasAreSpecifiedInPhysicalUnitsOn()
    r.SetInitialTransform(tx, inPlace=False)
    out = r.Execute(fixed, moving)
    return out, r.GetMetricValue()


def harmonise(raw_paths, tmpl, mask):
    """OASIS raw repeats (Analyze/NIfTI pairs in the 256 x 256 x 128 acquisition layout)."""
    return harmonise_arrays([load_raw(p) for p in raw_paths], RAW_SPACING, tmpl, mask)


def harmonise_arrays(arrays, spacing, tmpl, mask):
    """Repeats already in the OASIS-1 axis convention (left-right, anterior, superior), with voxel spacing."""
    vols = [to_sitk(a, spacing) for a in arrays]
    ref, acc = vols[0], from_sitk(vols[0]).astype(np.float64)
    for v in vols[1:]:
        tx, _ = register(ref, v, sitk.Euler3DTransform(sitk.CenteredTransformInitializer(
            ref, v, sitk.Euler3DTransform(), sitk.CenteredTransformInitializerFilter.GEOMETRY)), [4, 2], [2, 1], 100)
        acc += from_sitk(sitk.Resample(v, ref, tx, sitk.sitkLinear, 0.0))
    avg = to_sitk((acc / len(vols)).astype(np.float32), spacing)

    small = sitk.Shrink(avg, [4, 4, 4])
    n4 = sitk.N4BiasFieldCorrectionImageFilter()
    n4.SetMaximumNumberOfIterations([50, 50, 30])
    n4.Execute(small, sitk.OtsuThreshold(small, 0, 1, 200))
    corr = sitk.Cast(avg / sitk.Exp(n4.GetLogBiasFieldAsImage(avg)), sitk.sitkFloat32)

    corr = sitk.Cast(corr / float(np.percentile(from_sitk(corr)[from_sitk(corr) > 0], 99)), sitk.sitkFloat32)  # as template
    init = sitk.CenteredTransformInitializer(tmpl, corr, sitk.Similarity3DTransform(),
                                             sitk.CenteredTransformInitializerFilter.MOMENTS)
    sim, m1 = register(tmpl, corr, init, [8, 4, 2], [4, 2, 1], 300)              # head-to-head (with skull)
    aff0 = sitk.AffineTransform(3)
    aff0.SetCenter(init.GetCenter())
    aff, m2 = register(tmpl, corr, aff0, [4, 2, 1], [2, 1, 0], 300, moving_init=sim)
    tx = sitk.CompositeTransform([sim, aff])          # x -> sim(aff(x))
    out = from_sitk(sitk.Resample(corr, tmpl, tx, sitk.sitkLinear, 0.0)) * from_sitk(mask)
    return out.astype(np.float32), {"n_repeats": len(vols), "mi_similarity": m1, "mi_affine": m2}


GFC = OUT / "_t88_gfc"     # unmasked (with-skull) official T88 images, disc 1 (template only; label-free)


def extract_t88_gfc(disc=O1_RAW / "oasis_cross-sectional_disc1.tar.gz"):
    GFC.mkdir(parents=True, exist_ok=True)
    with tarfile.open(disc, "r:gz") as tf:
        for m in tf:
            if m.name.endswith(("_t88_gfc.img", "_t88_gfc.hdr")) and "_MR1/" in m.name:
                m.name = m.name.split("/")[-1]
                tf.extract(m, GFC)


def build_template():
    """Head template = mean of unmasked T88 images (disc 1); brain mask = voxels non-zero in >= 50 % of the
    416 masked T88 images. Both are label-free."""
    if not list(GFC.glob("*_t88_gfc.img")):
        extract_t88_gfc()
    head = [np.asarray(nib.load(str(f)).dataobj).squeeze().astype(np.float32) for f in sorted(GFC.glob("*_t88_gfc.img"))]
    head = [v / np.percentile(v[v > 0], 99) for v in head]          # per-image intensity scaling before averaging
    files = sorted(T88.glob("*_MR1/*.img"))
    cnt = None
    for f in files:
        v = np.asarray(nib.load(str(f)).dataobj).squeeze()
        cnt = (v > 0).astype(np.int32) if cnt is None else cnt + (v > 0)
    np.savez_compressed(OUT / "template.npz", template=np.mean(head, 0).astype(np.float32),
                        mask=(cnt >= 0.5 * len(files)).astype(np.uint8), n_head=len(head), n_mask=len(files))
    return len(head), len(files)


def load_template():
    z = np.load(OUT / "template.npz")
    m = sitk.Cast(to_sitk(z["mask"].astype(np.float32), (1.0, 1.0, 1.0)), sitk.sitkUInt8)
    return to_sitk(z["template"], (1.0, 1.0, 1.0)), m


def process(session, raw_paths, dest, model, tmpl, mask):
    f = dest / f"{session}.npz"
    if f.exists():
        return False
    t0 = time.time()
    vol, info = harmonise(raw_paths, tmpl, mask)
    e = embed(model, slices(vol))
    qc_ax = np.rot90(vol[:, :, int(round(0.5 * (vol.shape[2] - 1)))]).astype(np.float16)
    qc_cor = np.rot90(vol[:, int(round(0.5 * (vol.shape[1] - 1))), :]).astype(np.float16)
    tmp = dest / f"{session}.tmp.npz"
    np.savez_compressed(tmp, emb=e.astype(np.float32), qc_axial=qc_ax, qc_coronal=qc_cor,
                        seconds=time.time() - t0, **info)
    tmp.replace(f)
    return True


def resnet():
    torch.set_num_threads(2); torch.manual_seed(0)
    m = torchvision.models.resnet18(weights=torchvision.models.ResNet18_Weights.IMAGENET1K_V1)
    m.fc = torch.nn.Identity(); m.eval()
    return m


def run_oasis1(dest):
    ids = set(load_cohort().subject_id)
    model, (tmpl, mask) = resnet(), load_template()
    n = 0
    for disc in sorted(O1_RAW.glob("*_disc*.tar.gz"), key=lambda p: int(p.name.split("disc")[1].split(".")[0])):
        marker = dest / f"_done_{disc.name}.txt"
        if marker.exists():
            continue
        TMP.mkdir(parents=True, exist_ok=True)
        with tarfile.open(disc, "r:gz") as tf:
            for m in tf:
                parts = m.name.split("/")
                if (len(parts) >= 4 and parts[-2] == "RAW" and parts[-3].endswith("_MR1")
                        and parts[-3][:9] in ids and m.name.endswith((".img", ".hdr"))
                        and not (dest / f"{parts[-3]}.npz").exists()):
                    m.name = f"{parts[-3]}/{parts[-1]}"
                    tf.extract(m, TMP)
        for s in sorted(p for p in TMP.iterdir() if p.is_dir()):
            if process(s.name, sorted(s.glob("*mpr-*_anon.img")), dest, model, tmpl, mask):
                n += 1; print(f"  oasis1 {s.name} done ({n})", flush=True)
        shutil.rmtree(TMP)
        marker.write_text("done")


def run_oasis2(dest, wait_h=8):
    import external_tools as et
    need = set(et.load_oasis2().mri_id)
    model, (tmpl, mask) = resnet(), load_template()
    t0, n = time.time(), 0
    while True:
        avail = {p.name: p for p in O2_RAW.glob("OAS2_RAW_PART*/*_MR1")}
        for s in sorted(set(avail) & need):
            raws = sorted((avail[s] / "RAW").glob("mpr-*.nifti.img"))
            hdr_ok = all(r.with_suffix(".hdr").exists() and r.stat().st_size == 33554432 for r in raws)
            if raws and hdr_ok and process(s, raws, dest, model, tmpl, mask):
                n += 1; print(f"  oasis2 {s} done ({n})", flush=True)
        done = {p.stem for p in dest.glob("*.npz")}
        if need <= done or (O2_RAW / "_DOWNLOAD_FINISHED.txt").exists() and set(avail) & need <= done:
            break
        if time.time() - t0 > wait_h * 3600:
            raise TimeoutError("OASIS-2 download not finished")
        time.sleep(120)


if __name__ == "__main__":
    mode = sys.argv[1]
    OUT.mkdir(exist_ok=True)
    with PhaseRun(f"part43_harmonised_mri_{mode}", __file__,
                  params={"perm": PERM, "raw_spacing": RAW_SPACING, "axial": AXIAL, "coronal": CORONAL}) as run:
        if mode == "template":
            print(f"template from {build_template()} OASIS-1 T88 images")
        elif mode in ("oasis1", "oasis2"):
            dest = OUT / mode; dest.mkdir(exist_ok=True)
            (run_oasis1 if mode == "oasis1" else run_oasis2)(dest)
        elif mode == "collect":
            for c in ("oasis1", "oasis2"):
                rows, info = [], []
                for f in sorted((OUT / c).glob("*.npz")):
                    z = np.load(f)
                    sid = f.stem.replace("_MR1", "")
                    rows.append({"subject_id": sid, **{f"emb_{j}": float(v) for j, v in enumerate(z["emb"])}})
                    info.append({"session": f.stem, "n_repeats": int(z["n_repeats"]), "mi_similarity": float(z["mi_similarity"]),
                                 "mi_affine": float(z["mi_affine"]), "seconds": float(z["seconds"])})
                run.save_csv(pd.DataFrame(rows), f"mri_harmonised_{c}.csv")
                run.save_csv(pd.DataFrame(info), f"registration_qc_{c}.csv")
