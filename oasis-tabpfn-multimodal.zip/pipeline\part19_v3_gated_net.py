"""Part 19 v3 - Gated multimodal neural network with modality dropout (see newmethods.GatedFusionNet).
Tuned on the frozen inner folds: MRI PCA k, hidden size, weight decay, modality-dropout rate."""
import json

import numpy as np
import pandas as pd

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from newmethods import BASELINE_FILE, PROTOCOL_FILE, GatedFusionNet, compare

GRID = {"pca_k": [8, 16], "hidden": [16, 32], "weight_decay": [1e-3, 1e-2], "modality_dropout": [0.0, 0.3]}

with PhaseRun("part19_v3_gated_net", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"grid": GRID, "fixed": {"epochs": 300, "lr": 0.01, "dropout": 0.3, "n_seeds": 3}}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    feats = emb + config.CLINICAL_FULL
    spec = [{"group": "v3_gated_net", "name": "GatedFusionNet", "features": feats,
             "pipeline": GatedFusionNet(n_mri=len(emb)), "grid": GRID}]
    folds, preds, params = run_nested_cv(df, spec)
    run.save_csv(folds, "fold_metrics.csv")
    run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summary = summarize(folds)
    run.save_csv(summary, "summary.csv")
    print(summary[["model", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "brier"]].to_string(index=False))
    print("\nSelected configs:\n", params.drop(columns=["group", "model", "seed", "fold"]).value_counts().head(8))

    # interpretability: mean gate value (weight on MRI branch) on the full cohort, modal config
    modal = {k: type(GRID[k][0])(params[k].mode().iloc[0]) for k in GRID}
    net = GatedFusionNet(n_mri=len(emb), **modal).fit(df[feats], df[config.TARGET_COL])
    gates = pd.DataFrame({"subject_id": df.subject_id, "y_true": df[config.TARGET_COL],
                          "CDR": df.CDR, "gate_mri_weight": net.gate_values(df[feats])})
    run.save_csv(gates, "gate_values_descriptive.csv")
    print("\nMean MRI-branch gate weight by CDR (descriptive):\n",
          gates.groupby("CDR").gate_mri_weight.agg(["mean", "std"]).round(3))

    table, verdict = compare(folds, "v3_gated_net")
    run.save_csv(table, "comparison_vs_baseline.csv")
    run.save_json(verdict, "verdict.json")
    print("\n", table[table.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))
    print("\nVERDICT:", json.dumps(verdict, indent=2, default=str))
    assert check_oof_integrity(preds, df)
