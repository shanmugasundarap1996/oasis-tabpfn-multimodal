"""Shared helpers: proof manifests, console logging, metrics, frozen-fold access."""
import hashlib
import json
import platform
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

import config


# ---------------------------------------------------------------- proof / logging
class _Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, s):
        for st in self.streams:
            st.write(s)

    def flush(self):
        for st in self.streams:
            st.flush()


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def package_versions():
    out = {"python": sys.version.split()[0], "platform": platform.platform()}
    for mod in ["numpy", "pandas", "scipy", "sklearn", "matplotlib",
                "xgboost", "torch", "shap", "statsmodels"]:
        try:
            out[mod] = __import__(mod).__version__
        except Exception:
            pass
    return out


class PhaseRun:
    """Context manager for one phase: creates outputs/<name>/, tees stdout to
    run_log.txt, and writes run_manifest.json (hashes of script, inputs, outputs)."""

    def __init__(self, name, script, inputs=(), params=None):
        self.name = name
        self.script = Path(script)
        self.inputs = [Path(p) for p in inputs]
        self.params = params or {}
        self.dir = config.OUTPUT_DIR / name
        self.outputs = []

    def __enter__(self):
        self.dir.mkdir(parents=True, exist_ok=True)
        self.started = datetime.now()
        self.script_sha = sha256(self.script)
        self.config_sha = sha256(Path(config.__file__))
        self.module_sha = {p.name: sha256(p) for p in sorted(config.PIPELINE_DIR.glob("*.py"))
                           if p.name in ("common.py", "models.py", "graphs.py", "gnn.py",
                                         "external_validation.py")}
        self._log = open(self.dir / "run_log.txt", "w", encoding="utf-8")
        self._stdout = sys.stdout
        sys.stdout = _Tee(self._stdout, self._log)
        print(f"=== {self.name} | started {self.started.isoformat(timespec='seconds')}")
        for p in self.inputs:
            print(f"input  {p}  sha256={sha256(p)[:16]}...")
        return self

    def path(self, filename):
        return self.dir / filename

    def save_csv(self, df, filename, index=False):
        p = self.path(filename)
        df.to_csv(p, index=index, encoding="utf-8-sig")
        self.outputs.append(p)
        print(f"saved  {p.name}  ({len(df)} rows)")
        return p

    def save_text(self, text, filename):
        p = self.path(filename)
        p.write_text(text, encoding="utf-8")
        self.outputs.append(p)
        print(f"saved  {p.name}")
        return p

    def save_json(self, obj, filename):
        return self.save_text(json.dumps(obj, indent=2, default=str), filename)

    def save_fig(self, fig, filename, dpi=300):
        p = self.path(filename)
        fig.savefig(p, dpi=dpi, bbox_inches="tight")
        self.outputs.append(p)
        print(f"saved  {p.name}")
        return p

    def __exit__(self, exc_type, exc, tb):
        finished = datetime.now()
        status = "success" if exc_type is None else f"FAILED: {exc_type.__name__}: {exc}"
        print(f"=== {self.name} | {status} | {(finished - self.started).total_seconds():.1f}s")
        sys.stdout = self._stdout
        self._log.close()
        manifest = {
            "phase": self.name,
            "status": status,
            "started": self.started.isoformat(timespec="seconds"),
            "finished": finished.isoformat(timespec="seconds"),
            "script": {"path": str(self.script), "sha256": self.script_sha},
            "config_sha256": self.config_sha,
            "shared_modules_sha256": self.module_sha,
            "inputs": {str(p): sha256(p) for p in self.inputs},
            "outputs": {p.name: sha256(p) for p in self.outputs if p.exists()},
            "params": self.params,
            "environment": package_versions(),
        }
        (self.dir / "run_manifest.json").write_text(
            json.dumps(manifest, indent=2, default=str), encoding="utf-8")
        return False


# ---------------------------------------------------------------- data access
def load_cohort(path=None):
    df = pd.read_csv(path or config.COHORT_FILE)
    assert df["subject_id"].is_unique
    return df


def embedding_cols(df):
    cols = [c for c in df.columns if c.startswith(config.EMBED_PREFIX)]
    assert len(cols) == config.N_EMBED, f"expected {config.N_EMBED}, got {len(cols)}"
    return cols


def assert_no_forbidden(features):
    bad = set(features) & set(config.FORBIDDEN_PREDICTORS)
    assert not bad, f"Forbidden predictors in feature set: {bad}"


def iter_outer_folds(df):
    """Yield (seed, fold, train_idx, test_idx) from the frozen Phase 03 folds,
    with positional indices into df."""
    folds = pd.read_csv(config.FOLDS_FILE)
    pos = pd.Series(np.arange(len(df)), index=df["subject_id"])
    for seed in config.OUTER_SEEDS:
        f = folds[folds.seed == seed].set_index("subject_id").loc[df["subject_id"]]
        for k in range(1, config.N_OUTER_FOLDS + 1):
            test = pos[f.index[f.fold.to_numpy() == k]].to_numpy()
            train = pos[f.index[f.fold.to_numpy() != k]].to_numpy()
            yield seed, k, np.sort(train), np.sort(test)


_INNER_CACHE = {}


def inner_splits(df, seed, fold, train_idx):
    """Frozen inner folds for one outer training set, as (train, val) positions
    relative to train_idx (ready for GridSearchCV(cv=...))."""
    if "inner" not in _INNER_CACHE:
        _INNER_CACHE["inner"] = pd.read_csv(config.INNER_FOLDS_FILE)
    inner = _INNER_CACHE["inner"]
    f = inner[(inner.seed == seed) & (inner.outer_fold == fold)].set_index("subject_id").inner_fold
    lab = f.loc[df["subject_id"].iloc[train_idx]].to_numpy()
    return [(np.where(lab != j)[0], np.where(lab == j)[0])
            for j in range(1, config.N_INNER_FOLDS + 1)]


# ---------------------------------------------------------------- nested CV runner
def run_nested_cv(df, specs, y_col=None, ckpt_dir=None):
    """specs: list of dicts {name, group, features, pipeline, grid}.
    For every frozen outer fold, tune each spec with GridSearchCV on the frozen inner
    folds (scoring = config.TUNING_SCORING), refit on the outer training set and
    evaluate on the outer test set. Returns (fold_metrics, oof_predictions, best_params).
    ckpt_dir: if given, each (seed, fold, spec) result is stored there and reused on restart."""
    import os
    import pickle
    import time
    from sklearn.base import clone
    from sklearn.model_selection import GridSearchCV

    y = df[y_col or config.TARGET_COL].astype(int).to_numpy()
    for s in specs:
        assert_no_forbidden(s["features"])
    if ckpt_dir:
        os.makedirs(ckpt_dir, exist_ok=True)
    metric_rows, pred_rows, param_rows = [], [], []
    t0 = time.time()
    for seed, fold, tr, te in iter_outer_folds(df):
        cv_in = inner_splits(df, seed, fold, tr)
        for s in specs:
            ck = os.path.join(ckpt_dir, f"{s['group']}__{s['name']}__s{seed}_f{fold}.pkl") if ckpt_dir else None
            if ck and os.path.exists(ck):
                with open(ck, "rb") as fh:
                    m_, p_, pr_ = pickle.load(fh)
                metric_rows.append(m_); param_rows.append(p_); pred_rows.extend(pr_)
                continue
            n_m, n_p, n_pr = len(metric_rows), len(param_rows), len(pred_rows)
            Xtr = df.iloc[tr][s["features"]]
            Xte = df.iloc[te][s["features"]]
            gs = GridSearchCV(clone(s["pipeline"]), s["grid"], cv=cv_in,
                              scoring=config.TUNING_SCORING, n_jobs=-1, refit=True)
            gs.fit(Xtr, y[tr])
            prob = gs.predict_proba(Xte)[:, 1]
            pred = (prob >= config.DECISION_THRESHOLD).astype(int)
            m = binary_metrics(y[te], pred, prob)
            m.update({"group": s["group"], "model": s["name"], "seed": seed, "fold": fold,
                      "inner_cv_score": gs.best_score_, "n_features": len(s["features"])})
            metric_rows.append(m)
            param_rows.append({"group": s["group"], "model": s["name"], "seed": seed,
                               "fold": fold, **{k: str(v) for k, v in gs.best_params_.items()}})
            for j, idx in enumerate(te):
                pred_rows.append({"group": s["group"], "model": s["name"], "seed": seed,
                                  "fold": fold, "subject_id": df["subject_id"].iloc[idx],
                                  "y_true": int(y[idx]), "y_prob": float(prob[j]),
                                  "y_pred": int(pred[j])})
            if ck:
                tmp = ck + ".tmp"
                with open(tmp, "wb") as fh:
                    pickle.dump((metric_rows[n_m], param_rows[n_p], pred_rows[n_pr:]), fh)
                os.replace(tmp, ck)
        print(f"  seed {seed} fold {fold} done ({time.time() - t0:.0f}s)", flush=True)
    return pd.DataFrame(metric_rows), pd.DataFrame(pred_rows), pd.DataFrame(param_rows)


def summarize(fold_df, by=("group", "model"), metrics=None):
    """Mean, SD and 'mean ± SD' string for each metric over the 25 outer folds."""
    metrics = metrics or config.ALL_METRICS
    g = fold_df.groupby(list(by))[metrics]
    mean, sd = g.mean(), g.std(ddof=1)
    out = pd.DataFrame(index=mean.index)
    for m in metrics:
        out[f"{m}_mean"] = mean[m]
        out[f"{m}_sd"] = sd[m]
    for m in metrics:
        out[m] = [f"{a:.4f} ± {b:.4f}" for a, b in zip(mean[m], sd[m])]
    out["n_folds"] = g.size()
    return out.reset_index()


def check_oof_integrity(pred_df, df):
    """Every (group, model, seed) must predict every subject exactly once."""
    c = pred_df.groupby(["group", "model", "seed"]).subject_id.agg(["size", "nunique"])
    return bool(((c["size"] == len(df)) & (c["nunique"] == len(df))).all())


# ---------------------------------------------------------------- metrics
def expected_calibration_error(y_true, y_prob, n_bins=10):
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob, dtype=float)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    ids = np.digitize(y_prob, bins[1:-1], right=True)
    ece = 0.0
    for b in range(n_bins):
        m = ids == b
        if np.any(m):
            ece += m.mean() * abs(y_true[m].mean() - y_prob[m].mean())
    return float(ece)


def binary_metrics(y_true, y_pred, y_prob):
    from sklearn.metrics import (accuracy_score, average_precision_score,
                                 balanced_accuracy_score, brier_score_loss,
                                 confusion_matrix, f1_score, log_loss,
                                 matthews_corrcoef, precision_score,
                                 recall_score, roc_auc_score)
    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)
    y_prob = np.clip(np.asarray(y_prob, dtype=float), 1e-7, 1 - 1e-7)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "macro_f1": f1_score(y_true, y_pred, average="macro"),
        "mcc": matthews_corrcoef(y_true, y_pred),
        "accuracy": accuracy_score(y_true, y_pred),
        "sensitivity": recall_score(y_true, y_pred, zero_division=0),
        "specificity": tn / (tn + fp) if (tn + fp) else np.nan,
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, y_prob),
        "pr_auc": average_precision_score(y_true, y_prob),
        "brier": brier_score_loss(y_true, y_prob),
        "ece": expected_calibration_error(y_true, y_prob),
        "logloss": log_loss(y_true, np.c_[1 - y_prob, y_prob], labels=[0, 1]),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }
