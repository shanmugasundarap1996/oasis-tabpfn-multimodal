"""Cohort construction and frozen subject-level folds."""
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold

import config


def build_cohort():
    """OASIS-1 subjects with an MRI embedding, a CDR rating and age >= 60 (one row per subject),
    restricted to the published cohort if data/cohort_ids.csv is present."""
    clinical = pd.read_csv(config.CLINICAL_FILE)
    emb = pd.read_csv(config.EMBED_FILE)
    clinical["subject_id"] = clinical["ID"].str.extract(r"(OAS1_\d{4})", expand=False)
    # first session per subject (MR2 rows are reliability rescans)
    clinical = clinical.sort_values(["subject_id", "ID"]).drop_duplicates("subject_id")
    df = clinical.merge(emb, on="subject_id", how="inner", validate="one_to_one")
    df = df[df["CDR"].notna() & (df["Age"] >= config.MIN_AGE)].copy()
    if config.COHORT_IDS.exists():   # published cohort (subjects that also had a third-party embedding)
        df = df[df["subject_id"].isin(pd.read_csv(config.COHORT_IDS)["subject_id"])].copy()
    df["target_binary"] = (df["CDR"] > 0).astype(int)
    df["target_3class"] = np.select([df.CDR.eq(0), df.CDR.eq(0.5), df.CDR.ge(1.0)], [0, 1, 2])
    df["sex_binary"] = df["M/F"].map({"F": 0, "M": 1})
    return df.sort_values("subject_id").reset_index(drop=True)


def embedding_cols(df):
    cols = [c for c in df.columns if c.startswith(config.EMBED_PREFIX)]
    assert len(cols) == config.N_EMBED
    return cols


def outer_folds(df):
    """Yield (seed, fold, train_idx, test_idx): 5-fold CV x 5 seeds, stratified on CDR level."""
    strat = df["target_3class"].to_numpy()
    for seed in config.OUTER_SEEDS:
        skf = StratifiedKFold(config.N_OUTER, shuffle=True, random_state=seed)
        for k, (tr, te) in enumerate(skf.split(df, strat), start=1):
            yield seed, k, tr, te


def inner_folds(df, seed, fold, tr):
    """Frozen 3-fold inner split of an outer training set (positions relative to tr)."""
    strat = df["target_3class"].to_numpy()[tr]
    skf = StratifiedKFold(config.N_INNER, shuffle=True, random_state=seed * 100 + fold)
    return list(skf.split(np.zeros(len(tr)), strat))
