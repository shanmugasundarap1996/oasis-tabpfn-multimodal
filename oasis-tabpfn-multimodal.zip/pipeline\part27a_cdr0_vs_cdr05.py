"""Part 27a - Early-detection task: CDR 0 (n=85) vs CDR 0.5 (very mild, n=58).
Subjects with CDR >= 1 are removed from training AND test sets of the frozen folds; everything
else (folds, nested tuning, models) is identical to the main analysis. Resumable per fold."""
import pandas as pd

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from compare_tools import paired_table, pca_grid, tabpfn_spec
from models import build

with PhaseRun("part27a_cdr0_vs_cdr05", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE],
              params={"task": "CDR 0 vs CDR 0.5", "excluded": "CDR >= 1"}) as run:
    full = load_cohort()
    df = full[full.CDR.isin([0, 0.5])].reset_index(drop=True)
    emb = embedding_cols(df)
    print(f"subjects: {len(df)} (CDR 0: {(df.CDR == 0).sum()}, CDR 0.5: {(df.CDR == 0.5).sum()})")
    C5, C4 = config.CLINICAL_FULL, config.CLINICAL_NO_MMSE
    specs = [tabpfn_spec("CDR05", emb, C5)]
    for name in ["RF", "LR", "XGBoost"]:
        pipe, grid = build(name, mri_cols=emb, tab_cols=C5, pca_dim=8, extra_grid=pca_grid())
        specs.append({"group": "CDR05", "name": f"Fusion_PCA_{name}", "features": emb + C5, "pipeline": pipe, "grid": grid})
    pipe, grid = build("LR", mri_cols=emb, pca_dim=8, extra_grid=pca_grid())
    specs.append({"group": "CDR05", "name": "MRI_only_LR", "features": emb, "pipeline": pipe, "grid": grid})
    for nm, tab in [("Clinical_C5_LR", C5), ("Clinical_C4_noMMSE_LR", C4)]:
        pipe, grid = build("LR", tab_cols=tab)
        specs.append({"group": "CDR05", "name": nm, "features": list(tab), "pipeline": pipe, "grid": grid})
    folds, preds, params = run_nested_cv(df, specs, ckpt_dir=str(run.dir / "_ckpt"))
    run.save_csv(folds, "fold_metrics.csv"); run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summ = summarize(folds); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "mcc", "roc_auc", "brier"]].to_string(index=False))
    ref = folds[folds.model == "TabPFN_v2"]
    others = {m: folds[folds.model == m] for m in folds.model.unique() if m != "TabPFN_v2"}
    n_te = len(df) / 5
    tab = paired_table(ref, "TabPFN_v2", others, n_tr=len(df) - n_te, n_te=n_te)
    run.save_csv(tab, "tabpfn_vs_baselines.csv")
    print(tab[tab.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))
    assert check_oof_integrity(preds, df)
