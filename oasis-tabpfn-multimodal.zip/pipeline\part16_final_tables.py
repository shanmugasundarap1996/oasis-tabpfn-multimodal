"""Part 16 - Final model decision, publication tables/figures, reproducibility index.

Decision rule (fixed before results were inspected):
  1. Candidate with the highest mean MCC over the 25 outer folds = reference.
  2. Equivalence set = reference + every candidate NOT significantly worse than it on MCC and on
     ROC-AUC (paired two-sided Wilcoxon, p >= 0.05 for both).
  3. Final model = least complex member of the equivalence set
     (complexity: LR < SVM < RF < XGBoost < GCN < GAT); ties broken by lower Brier.
  Scenario A = GCN chosen and better than every classical model; B = GAT likewise; C = classical model.
"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import precision_recall_curve, roc_curve

import config
from common import PhaseRun, package_versions, sha256

OUT = config.OUTPUT_DIR
COMPLEXITY = {"LR": 0, "SVM_RBF": 1, "RF": 2, "XGBoost": 3, "GCN": 4, "GAT": 5}
CANDIDATES = {   # label: (fold file, oof file, group, model)
    "Fusion PCA - LR": ("part07_fusion/fold_metrics.csv", "part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "LR"),
    "Fusion PCA - SVM": ("part07_fusion/fold_metrics.csv", "part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "SVM_RBF"),
    "Fusion PCA - RF": ("part07_fusion/fold_metrics.csv", "part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "RF"),
    "Fusion PCA - XGBoost": ("part07_fusion/fold_metrics.csv", "part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "XGBoost"),
    "Fusion raw - LR": ("part07_fusion/fold_metrics.csv", "part07_fusion/oof_predictions.csv", "Fusion_raw_520", "LR"),
    "Fusion raw - XGBoost": ("part07_fusion/fold_metrics.csv", "part07_fusion/oof_predictions.csv", "Fusion_raw_520", "XGBoost"),
    "GCN inductive": ("part10_inductive/fold_metrics.csv", "part10_inductive/oof_predictions.csv", "GNN_inductive", "GCN"),
    "GAT inductive": ("part10_inductive/fold_metrics.csv", "part10_inductive/oof_predictions.csv", "GNN_inductive", "GAT"),
}
REFERENCE_CURVES = {
    "Clinical C5 - XGBoost": ("part04_clinical/oof_predictions.csv", "C5_clinical_full", "XGBoost"),
    "Clinical C4 (no MMSE) - LR": ("part04_clinical/oof_predictions.csv", "C4_clinical_no_MMSE", "LR"),
    "MRI PCA - LR": ("part06_pca/nested_oof_predictions.csv", "MRI_PCA_nested", "LR"),
    "Fusion PCA - LR": ("part07_fusion/oof_predictions.csv", "Fusion_PCA_nested", "LR"),
    "GCN inductive": ("part10_inductive/oof_predictions.csv", "GNN_inductive", "GCN"),
}
MAIN_COLS = ["balanced_accuracy", "macro_f1", "mcc", "sensitivity", "specificity", "roc_auc", "pr_auc", "brier"]


def load(f, g, m):
    t = pd.read_csv(OUT / f)
    return t[(t.group == g) & (t.model == m)]


def fmt(s, cols=MAIN_COLS):
    return {c: f"{s[c].mean():.3f} ± {s[c].std(ddof=1):.3f}" for c in cols}


def table(spec):
    rows = []
    for label, (f, g, m) in spec.items():
        rows.append({"representation / model": label, **fmt(load(f, g, m))})
    return pd.DataFrame(rows)


inputs = sorted({str(OUT / v[0]) for v in CANDIDATES.values()} | {str(OUT / v[1]) for v in CANDIDATES.values()})
with PhaseRun("part16_final", __file__, inputs=inputs,
              params={"rule": __doc__.split("Decision rule")[1].split("Scenario")[0].strip(),
                      "complexity": COMPLEXITY}) as run:

    # ---------------- decision gate
    fm = {k: load(v[0], v[2], v[3]).set_index(["seed", "fold"]).sort_index() for k, v in CANDIDATES.items()}
    means = pd.DataFrame({k: {"mcc": d.mcc.mean(), "roc_auc": d.roc_auc.mean(), "brier": d.brier.mean(),
                              "complexity": COMPLEXITY[CANDIDATES[k][3]]} for k, d in fm.items()}).T
    ref = means.mcc.astype(float).idxmax()
    gate = []
    for k, d in fm.items():
        p_mcc = 1.0 if k == ref else stats.wilcoxon(d.mcc, fm[ref].mcc).pvalue
        p_auc = 1.0 if k == ref else stats.wilcoxon(d.roc_auc, fm[ref].roc_auc).pvalue
        worse = (p_mcc < 0.05 and d.mcc.mean() < fm[ref].mcc.mean()) or \
                (p_auc < 0.05 and d.roc_auc.mean() < fm[ref].roc_auc.mean())
        gate.append({"candidate": k, **means.loc[k].to_dict(), "p_mcc_vs_ref": p_mcc,
                     "p_auc_vs_ref": p_auc, "in_equivalence_set": not worse})
    gate = pd.DataFrame(gate).sort_values("mcc", ascending=False)
    eq = gate[gate.in_equivalence_set].sort_values(["complexity", "brier"])
    final = eq.iloc[0].candidate
    fam = CANDIDATES[final][3]
    classical_best = gate[~gate.candidate.str.contains("GCN|GAT")].mcc.max()
    if fam in ("GCN", "GAT") and gate.set_index("candidate").loc[final, "mcc"] > classical_best:
        scenario = "A" if fam == "GCN" else "B"
    else:
        scenario = "C"
    decision = {"reference_highest_mcc": ref, "equivalence_set": eq.candidate.tolist(),
                "final_model": final, "final_family": fam, "final_group": CANDIDATES[final][2],
                "scenario": scenario,
                "scenario_meaning": {"A": "graph-learning framework", "B": "attention-graph framework",
                                     "C": "classical multimodal fusion; graph complexity does not add reliable value"}[scenario]}
    run.save_csv(gate, "decision_gate.csv")
    run.save_json(decision, "final_model_decision.json")
    print("Decision gate:\n", gate.round(4).to_string(index=False))
    print("\nDECISION:", json.dumps(decision, indent=2))

    # ---------------- publication tables
    t2 = table({
        "C1 demographics - LR": ("part04_clinical/fold_metrics.csv", "C1_demographics", "LR"),
        "C2 MRI biomarkers - LR": ("part04_clinical/fold_metrics.csv", "C2_mri_biomarkers", "LR"),
        "C3 MMSE - XGBoost": ("part04_clinical/fold_metrics.csv", "C3_cognitive_MMSE", "XGBoost"),
        "C4 clinical w/o MMSE - LR": ("part04_clinical/fold_metrics.csv", "C4_clinical_no_MMSE", "LR"),
        "C5 clinical - LR": ("part04_clinical/fold_metrics.csv", "C5_clinical_full", "LR"),
        "C5 clinical - XGBoost": ("part04_clinical/fold_metrics.csv", "C5_clinical_full", "XGBoost"),
        "MRI 512 - LR": ("part05_mri/fold_metrics.csv", "MRI_512", "LR"),
        "MRI PCA (nested k) - LR": ("part06_pca/nested_fold_metrics.csv", "MRI_PCA_nested", "LR"),
    })
    run.save_csv(t2, "table2_unimodal.csv")
    t3 = table({
        **{f"Fusion PCA - {m}": ("part07_fusion/fold_metrics.csv", "Fusion_PCA_nested", m) for m in COMPLEXITY if m not in ("GCN", "GAT")},
        "Fusion raw 520 - LR": ("part07_fusion/fold_metrics.csv", "Fusion_raw_520", "LR"),
        "MRI + Age - LR": ("part07_fusion/fold_metrics.csv", "Abl_MRI+Age", "LR"),
        "MRI + MMSE - LR": ("part07_fusion/fold_metrics.csv", "Abl_MRI+MMSE", "LR"),
        "MRI + C4 (no MMSE) - LR": ("part07_fusion/fold_metrics.csv", "Abl_MRI+C4_noMMSE", "LR"),
        "Transportable (Age, Sex, Educ, MMSE + MRI) - LR": ("part07_fusion/fold_metrics.csv", "Transportable_PCA_nested", "LR"),
    })
    run.save_csv(t3, "table3_fusion_ablation.csv")
    t4 = table({
        "Fusion PCA - LR (reference)": ("part07_fusion/fold_metrics.csv", "Fusion_PCA_nested", "LR"),
        "GCN transductive": ("part09_gnn/fold_metrics.csv", "GNN_transductive", "GCN"),
        "GCN inductive": ("part10_inductive/fold_metrics.csv", "GNN_inductive", "GCN"),
        "GAT transductive": ("part09_gnn/fold_metrics.csv", "GNN_transductive", "GAT"),
        "GAT inductive": ("part10_inductive/fold_metrics.csv", "GNN_inductive", "GAT"),
    })
    run.save_csv(t4, "table4_graph.csv")
    cal = pd.read_csv(OUT / "part12_calibration/calibration_summary.csv")
    run.save_csv(cal, "table5a_calibration.csv")
    st = pd.read_csv(OUT / "part13_stats/paired_statistics.csv")
    st5 = st[(st.family == "primary") & st.metric.isin(["mcc", "roc_auc"])][
        ["question", "metric", "mean_diff", "ci95_low", "ci95_high", "p_wilcoxon", "p_holm", "p_nb_holm",
         "rank_biserial"]]
    run.save_csv(st5, "table5b_statistics.csv")
    eff = pd.read_csv(OUT / "part15_efficiency/efficiency_table.csv")
    run.save_csv(eff.drop(columns="config"), "table6_efficiency.csv")
    for name, t in [("Table II", t2), ("Table III", t3), ("Table IV", t4)]:
        print(f"\n{name}:\n", t[["representation / model", "balanced_accuracy", "mcc", "roc_auc"]].to_string(index=False))

    # ---------------- figures: ROC / PR (pooled OOF) and MCC forest plot
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    for label, (f, g, m) in REFERENCE_CURVES.items():
        p = load(f, g, m)
        fpr, tpr, _ = roc_curve(p.y_true, p.y_prob)
        pr, rc, _ = precision_recall_curve(p.y_true, p.y_prob)
        axes[0].plot(fpr, tpr, label=label); axes[1].plot(rc, pr, label=label)
    axes[0].plot([0, 1], [0, 1], "--", color="grey")
    axes[0].set_xlabel("1 - specificity"); axes[0].set_ylabel("sensitivity"); axes[0].set_title("ROC (pooled OOF, 5 repeats)")
    axes[1].set_xlabel("recall"); axes[1].set_ylabel("precision"); axes[1].set_title("Precision-recall")
    axes[0].legend(fontsize=7)
    fig.tight_layout()
    run.save_fig(fig, "fig_roc_pr.png")
    plt.close(fig)

    forest = {**{k: (v[0], v[2], v[3]) for k, v in CANDIDATES.items()},
              "GCN transductive": ("part09_gnn/fold_metrics.csv", "GNN_transductive", "GCN"),
              "GAT transductive": ("part09_gnn/fold_metrics.csv", "GNN_transductive", "GAT"),
              "MRI PCA - LR": ("part06_pca/nested_fold_metrics.csv", "MRI_PCA_nested", "LR"),
              "Clinical C5 - LR": ("part04_clinical/fold_metrics.csv", "C5_clinical_full", "LR"),
              "Clinical C4 (no MMSE) - LR": ("part04_clinical/fold_metrics.csv", "C4_clinical_no_MMSE", "LR")}
    fr = []
    for label, (f, g, m) in forest.items():
        d = load(f, g, m).mcc.to_numpy()
        boot = np.random.default_rng(0).choice(d, (5000, len(d))).mean(1)
        fr.append((label, d.mean(), np.percentile(boot, 2.5), np.percentile(boot, 97.5)))
    fr = sorted(fr, key=lambda r: r[1])
    fig, ax = plt.subplots(figsize=(7, 5))
    for i, (label, mu, lo, hi) in enumerate(fr):
        ax.errorbar(mu, i, xerr=[[mu - lo], [hi - mu]], fmt="o",
                    color="#b03a2e" if label == final else "#34495e", capsize=3)
    ax.set_yticks(range(len(fr))); ax.set_yticklabels([r[0] for r in fr], fontsize=8)
    ax.set_xlabel("MCC (mean, 95% bootstrap CI over 25 outer folds)")
    ax.set_title(f"Final model (red): {final}")
    fig.tight_layout()
    run.save_fig(fig, "fig_mcc_forest.png")
    plt.close(fig)

    # ---------------- reproducibility index
    idx = []
    for man in sorted(OUT.glob("*/run_manifest.json")):
        m = json.loads(man.read_text(encoding="utf-8"))
        idx.append({"phase": m["phase"], "status": m["status"], "finished": m["finished"],
                    "script": m["script"]["path"].split("\\")[-1], "script_sha256": m["script"]["sha256"][:16],
                    "config_sha256": m["config_sha256"][:16], "n_outputs": len(m["outputs"])})
    run.save_csv(pd.DataFrame(idx), "reproducibility_index.csv")
    v = package_versions()
    req = "\n".join(f"{k}=={v[k]}" for k in ["numpy", "pandas", "scipy", "sklearn",
                                             "matplotlib", "xgboost", "torch", "shap", "statsmodels"] if k in v)
    req = req.replace("sklearn==", "scikit-learn==")
    run.save_text(f"# python {v['python']}\n{req}\n", "requirements.txt")
