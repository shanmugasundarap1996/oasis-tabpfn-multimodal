"""Part 50 - Amendment 9 (2): fidelity of the harmonised MRI pipeline H on OASIS-1.
(a) agreement of H features with the official-T88 features: per-feature Pearson correlation across the 166 subjects
    (after subject-wise centring would remove the common component, so features are compared across subjects);
(b) internal frozen 5x5 nested CV of the transportable multimodal TabPFN and the MRI-only LR on H features, compared
    with the same models on official features (Part 30 / identical folds)."""
import numpy as np
import pandas as pd

import config
import tabpfn_retry  # noqa: F401
from common import PhaseRun, embedding_cols, load_cohort, run_nested_cv, summarize
from compare_tools import paired_table, pca_grid, tabpfn_spec
from models import build

H_FILE = config.OUTPUT_DIR / "part43_harmonised_mri_collect" / "mri_harmonised_oasis1.csv"
OFF = config.RAW_DIR / "mri_embeddings_own.csv"
TRANSPORT = ["Age", "sex_binary", "Educ", "MMSE"]

with PhaseRun("part50_h_fidelity", __file__, inputs=[config.COHORT_FILE, H_FILE, OFF, config.FOLDS_FILE]) as run:
    base = load_cohort()
    off = pd.read_csv(OFF).set_index("subject_id").loc[base.subject_id]
    hh = pd.read_csv(H_FILE).set_index("subject_id").loc[base.subject_id]
    r = np.array([np.corrcoef(off[c], hh[c])[0, 1] if off[c].std() > 0 and hh[c].std() > 0 else np.nan for c in off.columns])
    agree = pd.DataFrame([{"n_features": len(r), "median_r": np.nanmedian(r), "q25_r": np.nanpercentile(r, 25),
                           "q75_r": np.nanpercentile(r, 75), "share_r_gt_0.5": float(np.nanmean(r > 0.5))}])
    run.save_csv(agree, "feature_agreement.csv")
    print(agree.round(3).to_string(index=False), flush=True)

    df = base.drop(columns=embedding_cols(base)).merge(hh.reset_index(), on="subject_id", how="left", validate="one_to_one")
    df = df.set_index("subject_id").loc[base.subject_id].reset_index()
    emb = embedding_cols(df)
    pipe, grid = build("LR", mri_cols=emb, pca_dim=8, extra_grid=pca_grid())
    specs = [tabpfn_spec("H", emb, TRANSPORT, name="TabPFN_transportable_H"),
             {"group": "H", "name": "MRI_only_LR_H", "features": emb, "pipeline": pipe, "grid": grid}]
    folds, preds, params = run_nested_cv(df, specs, ckpt_dir=str(run.dir / "_ckpt"))
    run.save_csv(folds, "fold_metrics.csv"); run.save_csv(preds, "oof_predictions.csv")
    summ = summarize(folds); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "mcc", "roc_auc", "brier"]].to_string(index=False), flush=True)
    p30 = pd.read_csv(config.OUTPUT_DIR / "part30_own_mri_benchmark" / "fold_metrics.csv")
    t = paired_table(folds[folds.model == "TabPFN_transportable_H"], "TabPFN_transportable_H (H features)",
                     {"TabPFN_transportable (official)": p30[p30.model == "TabPFN_transportable"]})
    run.save_csv(t, "h_vs_official.csv")
    print(t[t.metric.isin(["mcc", "roc_auc", "brier"])].round(4).to_string(index=False))
