"""Part 42c - paired bootstrap comparison (Amendment 7 statistics) on the pre-specified independent OASIS-2 subset
(participants not flagged by the overlap rule). Uses the saved Part 42 predictions; no model is refitted."""
import pandas as pd

import config
import external_tools as et

D = config.OUTPUT_DIR / "part42_external_clinical"
pred = pd.read_csv(D / "external_predictions.csv")
flags = pd.read_csv(D / "overlap_flags.csv")
ind = pred[pred.subject_id.isin(flags.subject_id[flags.n_candidates == 0])]
probs = {c[2:]: ind[c].to_numpy() for c in ind.columns if c.startswith("p_")}
t = et.paired_bootstrap(ind[config.TARGET_COL].to_numpy(), probs, "TabPFN_C5")
t.to_csv(D / "tabpfn_vs_baselines_independent29.csv", index=False)
print(f"n = {len(ind)}")
print(t[["comparator", "metric", "delta", "ci95_low", "ci95_high", "p_boot", "p_holm"]].round(4).to_string(index=False))
