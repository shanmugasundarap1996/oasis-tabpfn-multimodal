"""Population-graph utilities shared by Parts 08-10.

Node features are built with transforms fitted on training subjects only.
Graph types:
  G1 clinical            : C5 clinical (standardised)
  G2 MRI                 : PCA-k of MRI embedding
  G3 clinical + raw MRI  : C5 || 512-D embedding
  G4 clinical + PCA-MRI  : C5 || PCA-k
"""
import numpy as np
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

import config

GRAPH_TYPES = ["G1_clinical", "G2_MRI_PCA", "G3_clin+MRI_raw", "G4_clin+MRI_PCA"]
GRAPH_PCA_DIM = 16


def node_features(df, emb, tr, te, gtype, pca_dim=GRAPH_PCA_DIM, seed=42):
    """Return (X_train, X_test) for one graph type, fitted on training rows only."""
    def block(cols):
        imp, sc = SimpleImputer(strategy="median"), StandardScaler()
        a = sc.fit_transform(imp.fit_transform(df.iloc[tr][cols]))
        b = sc.transform(imp.transform(df.iloc[te][cols]))
        return a, b

    Ctr, Cte = block(config.CLINICAL_FULL)
    Mtr, Mte = block(emb)
    if gtype in ("G2_MRI_PCA", "G4_clin+MRI_PCA"):
        p = PCA(n_components=pca_dim, random_state=seed).fit(Mtr)
        Mtr, Mte = p.transform(Mtr), p.transform(Mte)
    if gtype == "G1_clinical":
        return Ctr, Cte
    if gtype == "G2_MRI_PCA":
        return Mtr, Mte
    return np.hstack([Ctr, Mtr]), np.hstack([Cte, Mte])


def _dist(A, B, metric):
    if metric == "cosine":
        An = A / (np.linalg.norm(A, axis=1, keepdims=True) + 1e-12)
        Bn = B / (np.linalg.norm(B, axis=1, keepdims=True) + 1e-12)
        return 1.0 - An @ Bn.T
    return np.sqrt(np.maximum(((A[:, None, :] - B[None, :, :]) ** 2).sum(-1), 0))


def knn_adjacency(X, k, metric="euclidean"):
    """Symmetric kNN adjacency (no self loops) among the rows of X."""
    D = _dist(X, X, metric)
    np.fill_diagonal(D, np.inf)
    nn = np.argsort(D, axis=1)[:, :k]
    A = np.zeros((len(X), len(X)), dtype=np.float32)
    A[np.repeat(np.arange(len(X)), k), nn.ravel()] = 1.0
    return np.maximum(A, A.T)


def transductive_adjacency(Xtr, Xte, k, metric="euclidean"):
    """Graph over train+test nodes (test features, never test labels)."""
    return knn_adjacency(np.vstack([Xtr, Xte]), k, metric)


def inductive_adjacency(Xtr, Xte, k, metric="euclidean"):
    """Train-train kNN graph; each test node linked (both directions) only to its
    k nearest TRAINING nodes; no test-test edges."""
    ntr, nte = len(Xtr), len(Xte)
    A = np.zeros((ntr + nte, ntr + nte), dtype=np.float32)
    A[:ntr, :ntr] = knn_adjacency(Xtr, k, metric)
    nn = np.argsort(_dist(Xte, Xtr, metric), axis=1)[:, :k]
    rows = np.repeat(np.arange(ntr, ntr + nte), k)
    A[rows, nn.ravel()] = 1.0
    A[nn.ravel(), rows] = 1.0
    return A


def test_neighbours(Xtr, Xte, k, metric="euclidean"):
    return np.argsort(_dist(Xte, Xtr, metric), axis=1)[:, :k]


def edge_homophily(A, y):
    i, j = np.nonzero(np.triu(A, 1))
    return float((y[i] == y[j]).mean()) if len(i) else np.nan
