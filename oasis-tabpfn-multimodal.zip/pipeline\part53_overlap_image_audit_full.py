"""Part 53 - Amendment 12: complete image-level overlap audit of the OASIS-2 external set against ALL OASIS-1 first
sessions. Raw MPRAGE repeats are put in the common axis convention (Part 43 PERM), downsampled 4x by block mean, and
compared by voxel-wise Pearson correlation (maximum over repeat pairs). Threshold T is fixed label-free from positive
controls (Part 44 record-linked pairs) and the null of the 14 earlier image-checked sessions, before the 29 are scored.
Resumable: downsampled OASIS-1 volumes are cached per session."""
import tarfile

import nibabel as nib
import numpy as np
import pandas as pd

import config
from common import PhaseRun

O1_RAW, O2_RAW = config.BASE_DIR / "oasis1_raw", config.BASE_DIR / "oasis2_raw"
CACHE = config.BASE_DIR / "mri_harmonised" / "_ds4_oasis1"
P42, P44 = config.OUTPUT_DIR / "part42_external_clinical", config.OUTPUT_DIR / "part44_overlap_image_verification"
PERM = (2, 0, 1)


def ds4(a):
    a = a[: a.shape[0] // 4 * 4, : a.shape[1] // 4 * 4, : a.shape[2] // 4 * 4]
    return a.reshape(a.shape[0] // 4, 4, a.shape[1] // 4, 4, a.shape[2] // 4, 4).mean((1, 3, 5)).astype(np.float32)


def prep(path):
    a = np.asarray(nib.load(str(path)).dataobj).squeeze().astype(np.float32)
    v = ds4(a.transpose(PERM)).ravel()
    return (v - v.mean()) / (v.std() + 1e-9)


def max_corr(A, B):
    return float(max((a @ b) / len(a) for a in A for b in B))


with PhaseRun("part53_overlap_image_audit_full", __file__,
              inputs=[P42 / "overlap_flags.csv", P44 / "image_verification.csv"]) as run:
    CACHE.mkdir(parents=True, exist_ok=True)
    # 1) downsampled raw repeats of all OASIS-1 first sessions (cached)
    for disc in sorted(O1_RAW.glob("*_disc*.tar.gz")):
        marker = CACHE / f"_done_{disc.name}.txt"
        if marker.exists():
            continue
        tmp = CACHE / "_tmp"
        with tarfile.open(disc, "r|gz") as tf:
            for m in tf:
                parts = m.name.split("/")
                if len(parts) >= 4 and parts[-2] == "RAW" and parts[-3].endswith("_MR1") and m.name.endswith((".img", ".hdr")):
                    m.name = f"{parts[-3]}/{parts[-1]}"
                    tf.extract(m, tmp, filter="data")
        cur = 0
        for sdir in sorted(p for p in tmp.iterdir() if p.is_dir()):
            vols = [prep(f) for f in sorted(sdir.glob("*mpr-*_anon.img"))]
            if vols:
                np.save(CACHE / f"{sdir.name}.npy", np.stack(vols)); cur += 1
        import shutil
        shutil.rmtree(tmp)
        marker.write_text(f"{cur} sessions")
        print(f"  {disc.name}: {cur} sessions cached", flush=True)
    o1 = {p.stem: np.load(p) for p in CACHE.glob("*.npy")}
    print(f"OASIS-1 sessions: {len(o1)}", flush=True)

    # 2) OASIS-2 sessions: 14 earlier image-checked + 29 external
    flags = pd.read_csv(P42 / "overlap_flags.csv")
    ext = [f"{s}_MR1" for s in flags.subject_id[flags.n_candidates == 0]]
    ver = pd.read_csv(P44 / "image_verification.csv")
    dirs = {p.name: p for p in O2_RAW.glob("OAS2_RAW_PART*/*_MR1")}
    o2 = {s: [prep(f) for f in sorted((dirs[s] / "RAW").glob("mpr-*.nifti.img"))]
          for s in set(ext) | {f"{v}_MR1" for v in ver.oasis2} if s in dirs}

    # sanity: the Analyze reader must reproduce nibabel for a cached session checked in Part 44
    chk = sorted((config.BASE_DIR / "mri_harmonised" / "_tmp_part44").glob("*/*mpr-1_anon.img"))
    if chk:
        ref = prep(chk[0]); s = chk[0].parent.name
        print(f"reader check {s}: r = {float(ref @ o1[s][0] / len(ref)):.6f} (must be 1.0)", flush=True)

    def scores(s):
        return pd.Series({k: max_corr(o2[s], v) for k, v in o1.items()})

    # 3) threshold from positive controls and null of the earlier sessions (label-free; fixed before the 29)
    pos = [scores(f"{r.oasis2}_MR1")[r.oasis1_candidate] for r in ver.itertuples() if r.max_corr_candidate >= 0.85]
    nullmax = [scores(f"{r.oasis2}_MR1").drop(r.oasis1_candidate).max() for r in ver.itertuples()]
    T = (min(pos) + float(np.percentile(nullmax, 99))) / 2
    run.save_csv(pd.DataFrame({"positive_controls": pd.Series(pos), "null_max": pd.Series(nullmax)}), "threshold_inputs.csv")
    print(f"positive controls {np.round(pos, 3)}; null-max 99th pct {np.percentile(nullmax, 99):.3f}; T = {T:.3f}", flush=True)

    # 4) score the 29 external participants against all OASIS-1 sessions
    rows = []
    for s in ext:
        sc = scores(s)
        rows.append({"oasis2": s, "best_oasis1": sc.idxmax(), "max_corr": sc.max(), "second_corr": sc.nlargest(2).iloc[-1],
                     "median_corr": sc.median(), "image_flagged": sc.max() >= T})
    res = pd.DataFrame(rows).sort_values("max_corr", ascending=False)
    run.save_csv(res, "external_image_audit.csv")
    run.save_csv(pd.DataFrame([{"n_external": len(res), "threshold": T, "n_flagged": int(res.image_flagged.sum()),
                                "max_corr_external": res.max_corr.max(), "min_positive_control": min(pos)}]), "summary.csv")
    print(res.round(3).to_string(index=False))
