"""Label-free MRI feature extraction (512-D per subject) from OASIS-1 atlas-registered T1 volumes.

Usage:  python extract_mri_features.py <oasis1_root> [output.csv]
<oasis1_root> is the folder holding the extracted OASIS-1 cross-sectional discs; every first-session file
OAS1_xxxx_MR1/PROCESSED/MPRAGE/T88_111/*_t88_masked_gfc.img (176 x 208 x 176, 1 mm) is used.

Slices are fixed a priori (same anatomy in all subjects because volumes are atlas-registered):
5 axial at 40-60 % of axis 2 and 4 coronal at 45-60 % of axis 1. Intensities are clipped at the 99.5th
brain percentile and scaled to [0, 1]; slices are resized to 224 x 224, replicated to 3 channels,
ImageNet-normalised and passed through a frozen ImageNet ResNet18; the 512-D pooled outputs are averaged
over slices. No labels are used. Resumable: one .npy per session in features_cache/.
"""
import sys
from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
import torchvision

AXIAL = [0.40, 0.45, 0.50, 0.55, 0.60]
CORONAL = [0.45, 0.50, 0.55, 0.60]
MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)


def slices(vol):
    brain = vol[vol > 0]
    hi = np.percentile(brain, 99.5) if brain.size else 1.0
    v = np.clip(vol, 0, hi) / hi
    out = [np.rot90(v[:, :, int(round(f * (v.shape[2] - 1)))]) for f in AXIAL]
    out += [np.rot90(v[:, int(round(f * (v.shape[1] - 1))), :]) for f in CORONAL]
    return out


def embed(model, sl):
    x = torch.stack([F.interpolate(torch.tensor(s.copy(), dtype=torch.float32)[None, None], size=(224, 224),
                                   mode="bilinear", align_corners=False)[0, 0] for s in sl])
    x = (x[:, None].repeat(1, 3, 1, 1) - MEAN) / STD
    with torch.no_grad():
        return model(x).numpy().mean(0)


def main(root, out_csv):
    files = {}
    for f in sorted(Path(root).rglob("*_MR1_*t88_masked_gfc.img")):
        files.setdefault(f.name.split("_mpr")[0], f)       # OAS1_xxxx_MR1 -> first matching file
    cache = Path(out_csv).resolve().parent / "features_cache"
    cache.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    model = torchvision.models.resnet18(weights=torchvision.models.ResNet18_Weights.IMAGENET1K_V1)
    model.fc = torch.nn.Identity()
    model.eval()
    rows = []
    for i, (session, f) in enumerate(sorted(files.items()), 1):
        npy = cache / f"{session}.npy"
        if not npy.exists():
            vol = np.asarray(nib.load(f).dataobj).squeeze().astype(np.float32)
            np.save(npy, embed(model, slices(vol)).astype(np.float32))
        e = np.load(npy)
        rows.append({"subject_id": session.replace("_MR1", ""), **{f"emb_{j}": float(v) for j, v in enumerate(e)}})
        if i % 25 == 0:
            print(f"{i}/{len(files)} sessions", flush=True)
    pd.DataFrame(rows).to_csv(out_csv, index=False)
    print(f"saved {out_csv} ({len(rows)} subjects x 512)")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "data/mri_embeddings_own.csv")
