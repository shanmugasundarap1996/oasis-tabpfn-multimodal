"""Part 40 - Amendment 6, M3: full OASIS-1 cohort (first session, CDR available, age >= 60), WITHOUT the
third-party-embedding filter, label-free ResNet MRI features. New 5x5 outer / 3-fold inner folds generated with the
Phase 03 procedure (same seeds, stratified by CDR level). Proposed TabPFN vs baselines. Resumable per fold."""
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from threadpoolctl import threadpool_limits

import config
import tabpfn_retry  # noqa: F401  (retries sporadic ARPACK failures in the main-process refit)
from common import PhaseRun, check_oof_integrity, embedding_cols, run_nested_cv, summarize
from compare_tools import paired_table, pca_grid, tabpfn_spec
from sklearn.pipeline import Pipeline

from models import build, preprocessor

# No BLAS thread limit here: with it, TabPFN's internal ARPACK SVD failed (error -8); Part 30 ran this
# 512-feature setup unlimited without problems.


def tabpfn_clin(group, tab, name):
    from tabpfn import TabPFNClassifier
    from tabpfn.constants import ModelVersion
    pipe = Pipeline([("prep", preprocessor((), tab)),
                     ("clf", TabPFNClassifier.create_default_for_version(ModelVersion.V2, device="cpu", random_state=42))])
    return {"group": group, "name": name, "features": list(tab), "pipeline": pipe, "grid": {"clf__random_state": [42]}}
OWN = config.RAW_DIR / "mri_embeddings_own.csv"
C5 = config.CLINICAL_FULL

with PhaseRun("part40_full_cohort", __file__, inputs=[config.CLINICAL_FILE, OWN],
              params={"min_age": config.MIN_AGE, "seeds": config.OUTER_SEEDS}) as run:
    clin = pd.read_csv(config.CLINICAL_FILE)
    clin["subject_id"] = clin.ID.str[:9]
    clin = clin[clin.ID.str.endswith("MR1")].sort_values("subject_id").drop_duplicates("subject_id")
    df = clin[clin.CDR.notna() & (clin.Age >= config.MIN_AGE)].copy()
    df = df.merge(pd.read_csv(OWN), on="subject_id", how="inner", validate="one_to_one")
    df["target_binary"] = (df.CDR > 0).astype(int)
    df["target_3class"] = np.select([df.CDR.eq(0), df.CDR.eq(0.5), df.CDR.ge(1.0)], [0, 1, 2])
    df["sex_binary"] = df["M/F"].map({"F": 0, "M": 1})
    df = df.sort_values("subject_id").reset_index(drop=True)
    old = pd.read_csv(config.COHORT_FILE).subject_id
    flow = pd.DataFrame([{"n_full_cohort": len(df), "n_cdr0": int((df.CDR == 0).sum()), "n_cdr05": int((df.CDR == 0.5).sum()),
                          "n_cdr_ge1": int((df.CDR >= 1).sum()), "n_in_primary_166": int(df.subject_id.isin(old).sum()),
                          "n_added": int((~df.subject_id.isin(old)).sum())}])
    run.save_csv(flow, "cohort_flow_full.csv"); print(flow.to_string(index=False), flush=True)
    run.save_csv(df[["subject_id", "Age", "M/F", "CDR", "target_binary", "target_3class"]], "cohort_full.csv")

    # folds: identical procedure to Phase 03
    ids, strat = df.subject_id.to_numpy(), df.target_3class.to_numpy()
    outer, inner = [], []
    for seed in config.OUTER_SEEDS:
        for k, (tr, te) in enumerate(StratifiedKFold(5, shuffle=True, random_state=seed).split(ids, strat), start=1):
            outer += [{"subject_id": s, "seed": seed, "fold": k} for s in ids[te]]
            for j, (_, ite) in enumerate(StratifiedKFold(3, shuffle=True, random_state=seed * 100 + k).split(ids[tr], strat[tr]), start=1):
                inner += [{"subject_id": s, "seed": seed, "outer_fold": k, "inner_fold": j} for s in ids[tr][ite]]
    run.save_csv(pd.DataFrame(outer), "outer_folds_full.csv"); run.save_csv(pd.DataFrame(inner), "inner_folds_full.csv")
    config.FOLDS_FILE = run.path("outer_folds_full.csv")
    config.INNER_FOLDS_FILE = run.path("inner_folds_full.csv")

    emb = embedding_cols(df)
    specs = [tabpfn_spec("Full", emb, C5), tabpfn_clin("Full", C5, "TabPFN_clinical_only")]
    for name in ["LR", "XGBoost"]:
        pipe, grid = build(name, mri_cols=emb, tab_cols=C5, pca_dim=8, extra_grid=pca_grid())
        specs.append({"group": "Full", "name": f"Fusion_PCA_{name}", "features": emb + C5, "pipeline": pipe, "grid": grid})
        pipe, grid = build(name, tab_cols=C5)
        specs.append({"group": "Full", "name": f"Clinical_C5_{name}", "features": list(C5), "pipeline": pipe, "grid": grid})
    pipe, grid = build("LR", mri_cols=emb, pca_dim=8, extra_grid=pca_grid())
    specs.append({"group": "Full", "name": "MRI_only_LR", "features": emb, "pipeline": pipe, "grid": grid})
    folds, preds, params = run_nested_cv(df, specs, ckpt_dir=str(run.dir / "_ckpt"))
    run.save_csv(folds, "fold_metrics.csv"); run.save_csv(preds, "oof_predictions.csv"); run.save_csv(params, "best_params.csv")
    summ = summarize(folds); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "mcc", "roc_auc", "brier"]].to_string(index=False), flush=True)
    n_te = len(df) / 5
    tab = paired_table(folds[folds.model == "TabPFN_v2"], "TabPFN_v2 (full cohort)",
                       {m: folds[folds.model == m] for m in folds.model.unique() if m != "TabPFN_v2"},
                       n_tr=len(df) - n_te, n_te=n_te)
    run.save_csv(tab, "tabpfn_vs_baselines_full.csv")
    print(tab[tab.metric.isin(["mcc", "roc_auc", "brier"])].round(4).to_string(index=False))
    assert check_oof_integrity(preds, df)
