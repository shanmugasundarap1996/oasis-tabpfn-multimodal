# Agentic cost-aware multimodal acquisition (Part 20) — frozen before first run (2026-10-24)

## Idea
Instead of giving every patient every test, an agent runs a perceive → plan → act → observe loop:
start from cheap information, estimate how much each further test would improve the diagnosis,
acquire it only if the expected benefit exceeds its cost, and stop when more evidence is not worth it.

## OASIS-1 action space (limited by the dataset; ADNI would add APOE / PET / CSF)
| State | Information | Cumulative cost (units) |
|---|---|---|
| S0 | demographics: Age, Sex, Education, SES | 0 (always available) |
| S1 | S0 + MMSE | 1 |
| S2 | S0 + MRI (embedding + eTIV, nWBV, ASF) | 10 |
| S3 | S0 + MMSE + MRI | 11 |
Actions: acquire MMSE (cost 1), acquire MRI (cost 10), STOP. Cost ratio MRI : MMSE = 10 : 1 in the main
analysis; sensitivity analysis with 5 : 1 and 20 : 1. CDR is never an input.

## Components (all fitted inside each outer training set; frozen 5×5 outer / 3-fold inner folds)
1. **Evidence agent** — one logistic-regression model per state (MRI block: standardised, PCA-8),
   C tuned on inner folds. Gives P(CDR>0 | information at that state).
2. **Planner / acquisition agent** — learned value-of-information: for every current state s and every
   reachable terminal state t, a random-forest regressor predicts the patient's expected Brier loss at t
   from the information available at s (features + current probability + entropy). Trained on
   cross-fitted (inner-fold out-of-fold) predictions of the training subjects only.
   Decision: choose t minimising Ê[Brier_t | info at s] + λ · additional cost(s → t); if t = s → STOP,
   else acquire the cheapest modality on the way to t, observe it, and re-plan.
3. **Critic** — final probability from the stop-state model; calibration (ECE) of the agent's decisions reported.

## Comparators (same folds)
- Static policies: S0 only, S1 (demographics + MMSE), S2 (demographics + MRI), S3 (everything, "full fusion").
- Heuristic uncertainty agent: stop when max(p, 1 − p) ≥ τ, otherwise acquire MMSE, then MRI; τ ∈ {0.6, 0.7, 0.8, 0.9, 0.95}.
- Random-acquisition control: everyone gets MMSE; MRI given to a random subset of the same size the agent chose.
- Reference: Fusion PCA + RF (Part 07), MCC 0.852.

## λ grid (fixed in advance; no λ selection on test data)
λ ∈ {0, 0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05}.

## Primary outcome and success criterion
Performance-versus-cost frontier (MCC, macro-F1, AUC vs mean cost and % of patients sent to MRI).
**Success** = at least one λ for which, versus static full fusion S3 (paired over 25 folds):
(a) mean MRI-acquisition rate ≤ 80 % (≥ 20 % fewer MRI scans), and
(b) non-inferior MCC with margin 0.03: lower bound of the 95 % bootstrap CI of ΔMCC (agent − S3) > −0.03,
with Holm correction across the 8 λ values (applied to the one-sided bootstrap test at α = 0.05).
Secondary: agent vs random-acquisition control at matched MRI rate (paired Wilcoxon on MCC);
missing-MRI scenario (MRI unavailable for 30 % / 50 % of test patients) versus static fusion with imputation.

## Amendments
None.
