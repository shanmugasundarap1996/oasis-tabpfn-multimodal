"""Part 26 - Architecture diagram of the proposed framework (Fig. 1), vector version of the
author-approved layout: (a) inputs, (b) leakage-safe representation, (c) TabPFN in-context learning,
(d) evaluation protocol. Outputs: paper/figures/fig1_architecture.pdf / .png (600 dpi)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import (Circle, Ellipse, FancyArrowPatch, FancyBboxPatch, Rectangle, Wedge)

import config
from common import PhaseRun

FIG_DIR = config.BASE_DIR / "paper" / "figures"
C = {"blue": "#2f6aa8", "blue_f": "#e3eefa", "blue_f2": "#f3f8fd", "green": "#3d8a3a", "green_f": "#e6f3e2",
     "green_f2": "#f5fbf3", "gold": "#c99a12", "gold_f": "#fff7dc", "gold_f2": "#fffcf0", "red": "#c8372d",
     "red_f": "#fdebe8", "red_f2": "#fff6f4", "purple": "#6b4c9a", "purple_f": "#efe8f8", "orange": "#d97a2b",
     "orange_f": "#fdeedd", "grey": "#4a5563", "grey_f": "#eef1f5", "ink": "#1b2430", "navy": "#183a66"}
plt.rcParams.update({"font.family": "DejaVu Sans", "pdf.fonttype": 42, "mathtext.fontset": "dejavusans"})


def box(ax, x, y, w, h, fc, ec, lw=1.0, ls="-", r=0.008, z=2):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0.002,rounding_size={r}",
                                fc=fc, ec=ec, lw=lw, ls=ls, zorder=z))


FS = 1.10   # global text scale (legibility at print size)


def T(ax, x, y, s, fs=5.6, bold=False, color=None, ha="center", va="center", style="normal", rot=0,
      serif=False):
    ax.text(x, y, s, fontsize=fs * FS, fontweight="bold" if bold else "normal", color=color or C["ink"],
            ha=ha, va=va, style=style, rotation=rot, zorder=7, linespacing=1.15,
            family="DejaVu Serif" if serif else "DejaVu Sans")


def arrow(ax, p1, p2, color="#222222", lw=0.9):
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=7, lw=lw, color=color, zorder=6,
                                 shrinkA=0, shrinkB=0))


def poly(ax, pts, color="#222222", lw=0.9):
    xs, ys = zip(*pts)
    ax.plot(xs[:-1], ys[:-1], color=color, lw=lw, zorder=6)
    arrow(ax, pts[-2], pts[-1], color=color, lw=lw)


# ---------------- small vector icons
def icon_mri(ax, x, y, s):
    for i in range(3):
        ax.add_patch(Rectangle((x + i * s * 0.13, y - i * s * 0.13), s, s, fc="#111111", ec="white", lw=0.6, zorder=3))
    cx, cy = x + 0.26 * s + s / 2, y - 0.26 * s + s / 2
    ax.add_patch(Ellipse((cx, cy), s * 0.70, s * 0.84, fc="#bdbdbd", ec="#e8e8e8", lw=0.6, zorder=4))
    ax.add_patch(Ellipse((cx, cy), s * 0.56, s * 0.70, fc="#8f8f8f", ec="none", zorder=4))
    for dx in (-0.09, 0.09):
        ax.add_patch(Ellipse((cx + dx * s, cy), s * 0.10, s * 0.26, fc="#2b2b2b", ec="none", zorder=5))
    ax.plot([cx, cx], [cy - 0.40 * s, cy + 0.40 * s], color="#5a5a5a", lw=0.5, zorder=5)


def icon_people(ax, x, y, s, col):
    for dx, sc in ((-0.32, 0.8), (0.32, 0.8), (0, 1.0)):
        ax.add_patch(Circle((x + dx * s, y + 0.22 * s * sc), 0.13 * s * sc, fc=col, ec="none", zorder=5))
        ax.add_patch(Wedge((x + dx * s, y - 0.18 * s * sc), 0.24 * s * sc, 0, 180, fc=col, ec="none", zorder=5))


def icon_brain(ax, x, y, s, col):
    for dx, dy, r in ((-0.18, 0.08, 0.2), (0.0, 0.16, 0.22), (0.2, 0.06, 0.2), (-0.08, -0.12, 0.2),
                      (0.14, -0.12, 0.19)):
        ax.add_patch(Circle((x + dx * s, y + dy * s), r * s, fc=col, ec="white", lw=0.4, zorder=5))


def icon_bars(ax, x, y, s, col):
    for i, h in enumerate((0.35, 0.6, 0.9)):
        ax.add_patch(Rectangle((x + (i - 1.5) * 0.24 * s, y - 0.45 * s), 0.17 * s, h * s, fc=col, ec="none", zorder=5))
    ax.plot([x - 0.45 * s, x + 0.45 * s], [y - 0.45 * s, y - 0.45 * s], color=col, lw=0.8, zorder=5)


with PhaseRun("part26_architecture_figure", __file__) as run:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig = plt.figure(figsize=(7.16, 4.25))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 1); ax.set_ylim(0, 0.594); ax.axis("off")

    # ================= panel titles (serif)
    T(ax, 0.128, 0.578, "(a) Multimodal inputs (OASIS-1)", fs=6.3, bold=True, serif=True)
    T(ax, 0.449, 0.578, "(b) Leakage-safe multimodal representation", fs=6.3, bold=True, serif=True)
    T(ax, 0.814, 0.578, "(c) In-context learning with TabPFN v2", fs=6.3, bold=True, serif=True)

    # ================= (a) inputs
    box(ax, 0.008, 0.39, 0.245, 0.172, C["blue_f"], C["blue"], lw=1.1)
    T(ax, 0.13, 0.548, "Structural MRI", fs=7, bold=True, color=C["navy"])
    T(ax, 0.13, 0.527, "Atlas-registered T1 volume (OASIS-1)", fs=5.2)
    icon_mri(ax, 0.02, 0.445, 0.05)
    T(ax, 0.172, 0.497, "Frozen ImageNet ResNet18\n9 fixed slices, averaged", fs=4.9)
    box(ax, 0.112, 0.43, 0.12, 0.036, "white", C["blue"], lw=0.9)
    T(ax, 0.172, 0.448, r"$\mathbf{z}^{\mathrm{MRI}}\in\mathbb{R}^{512}$", fs=6.4, color=C["navy"])
    T(ax, 0.172, 0.412, "(label-free; no fine-tuning)", fs=4.8)

    box(ax, 0.008, 0.13, 0.245, 0.247, C["green_f"], C["green"], lw=1.1)
    T(ax, 0.13, 0.362, "Clinical / cognitive variables", fs=6.8, bold=True)
    T(ax, 0.13, 0.343, "8 variables (CDR not used as input)", fs=5.3)
    rows = [("Demographics", "Age, sex (F=0, M=1),\neducation, SES", icon_people),
            ("Cognition", "MMSE score", icon_brain), ("Volumetry", "eTIV, nWBV, ASF", icon_bars)]
    for i, (lab, val, ic) in enumerate(rows):
        y0 = 0.283 - i * 0.052
        box(ax, 0.02, y0, 0.221, 0.046, "white", C["green"], lw=0.8)
        ic(ax, 0.05, y0 + 0.023, 0.034, "#3c4b5c")
        T(ax, 0.08, y0 + 0.033, lab, fs=6.0, bold=True, ha="left")
        T(ax, 0.08, y0 + 0.014, val, fs=5.1, ha="left")
    T(ax, 0.13, 0.163, r"$\mathbf{x}^{\mathrm{clin}}\in\mathbb{R}^{8}$", fs=6.6, color=C["green"], bold=True)
    T(ax, 0.13, 0.142, "(CDR defines the target, never a predictor)", fs=4.6, color=C["green"])

    # ================= (b) representation
    box(ax, 0.268, 0.13, 0.358, 0.432, C["gold_f2"], C["gold"], lw=1.1, ls=(0, (4, 3)), r=0.014)
    box(ax, 0.282, 0.512, 0.33, 0.04, C["gold_f"], C["gold"], lw=0.8)
    ax.text(0.447, 0.538, "All preprocessing and PCA are fitted on the", fontsize=5.6, fontweight="bold",
            ha="center", va="center", zorder=7, color=C["ink"])
    ax.text(0.447, 0.523, "outer-training fold only (no test-data leakage)", fontsize=5.6, fontweight="bold",
            ha="center", va="center", zorder=7, color=C["ink"])
    # MRI column
    box(ax, 0.282, 0.275, 0.17, 0.228, C["blue_f2"], C["blue"], lw=0.9)
    T(ax, 0.367, 0.49, "MRI embedding processing", fs=4.7, bold=True, color=C["navy"])
    T(ax, 0.367, 0.475, r"($\mathbf{z}^{\mathrm{MRI}}\in\mathbb{R}^{512}$)", fs=5.4)
    for j, s in enumerate(["Median imputation\n(training fold)", "Standardization\n(training fold)"]):
        yy = 0.437 - j * 0.045
        box(ax, 0.292, yy - 0.016, 0.15, 0.032, "white", C["blue"], lw=0.7)
        T(ax, 0.367, yy, s, fs=5.2)
    arrow(ax, (0.367, 0.421), (0.367, 0.408), color=C["blue"])
    box(ax, 0.292, 0.3, 0.15, 0.06, "white", C["blue"], lw=0.7)
    T(ax, 0.367, 0.348, "PCA compression", fs=5.5, bold=True)
    T(ax, 0.367, 0.332, r"$k\in\{8,16,24,32,64\}$", fs=5.4)
    T(ax, 0.367, 0.312, "(chosen by 3-fold inner CV\nusing ROC-AUC)", fs=4.7, color=C["orange"])
    arrow(ax, (0.367, 0.376), (0.367, 0.36), color=C["blue"])
    box(ax, 0.284, 0.226, 0.166, 0.044, C["blue_f"], C["blue"], lw=0.9)
    T(ax, 0.367, 0.258, "Reduced MRI representation", fs=4.5, bold=True)
    T(ax, 0.367, 0.243, r"$\mathbf{z}_k^{\mathrm{MRI}}\in\mathbb{R}^{k}$", fs=5.2)
    T(ax, 0.367, 0.2325, "(k selected adaptively per fold)", fs=4.4)
    arrow(ax, (0.367, 0.3), (0.367, 0.27), color=C["blue"])
    # clinical column
    box(ax, 0.462, 0.275, 0.15, 0.228, C["green_f2"], C["green"], lw=0.9)
    T(ax, 0.537, 0.49, "Clinical feature processing", fs=4.5, bold=True, color=C["green"])
    T(ax, 0.537, 0.475, r"($\mathbf{x}^{\mathrm{clin}}\in\mathbb{R}^{8}$)", fs=5.4)
    for j, s in enumerate(["Median imputation\n(training fold)", "Standardization\n(training fold)"]):
        yy = 0.437 - j * 0.045
        box(ax, 0.47, yy - 0.016, 0.134, 0.032, "white", C["green"], lw=0.7)
        T(ax, 0.537, yy, s, fs=5.2)
    arrow(ax, (0.537, 0.421), (0.537, 0.408), color=C["green"])
    box(ax, 0.47, 0.3, 0.134, 0.046, "white", C["green"], lw=0.7)
    T(ax, 0.537, 0.331, "Processed clinical\nfeatures", fs=4.7, bold=True)
    T(ax, 0.537, 0.309, r"$\tilde{\mathbf{x}}^{\mathrm{clin}}\in\mathbb{R}^{8}$", fs=5.4)
    arrow(ax, (0.537, 0.376), (0.537, 0.346), color=C["green"])
    # fusion
    box(ax, 0.39, 0.163, 0.22, 0.058, C["purple_f"], C["purple"], lw=1.1)
    T(ax, 0.5, 0.208, "Early multimodal fusion", fs=5.8, bold=True)
    T(ax, 0.5, 0.19, r"$\mathbf{x}=[\,\mathbf{z}_k^{\mathrm{MRI}}\ \Vert\ \tilde{\mathbf{x}}^{\mathrm{clin}}\,]\in\mathbb{R}^{k+8}$",
      fs=5.6)
    T(ax, 0.5, 0.172, "(up to 98.4% fewer MRI dimensions)", fs=4.8)
    poly(ax, [(0.33, 0.2255), (0.33, 0.192), (0.39, 0.192)])
    arrow(ax, (0.537, 0.3), (0.537, 0.221))
    # train / test
    box(ax, 0.282, 0.138, 0.1, 0.05, C["orange_f"], C["orange"], lw=0.9)
    T(ax, 0.332, 0.172, "Training subjects\n(context set)", fs=4.4, bold=True)
    T(ax, 0.332, 0.147, r"$\mathcal{D}_{\mathrm{train}}=\{(\mathbf{x}_j,y_j)\}$", fs=4.9)
    arrow(ax, (0.39, 0.172), (0.382, 0.172))
    T(ax, 0.457, 0.148, "Test subject (query)", fs=4.9, bold=True)
    T(ax, 0.562, 0.148, r"$(\mathbf{x}_\ast,\ ?)$", fs=5.2)
    box(ax, 0.392, 0.138, 0.218, 0.021, C["grey_f"], C["grey"], lw=0.7)

    # ================= (c) TabPFN
    box(ax, 0.636, 0.13, 0.356, 0.432, C["red_f2"], C["red"], lw=1.1, r=0.014)
    box(ax, 0.69, 0.488, 0.25, 0.066, C["red_f"], C["red"], lw=1.0)
    T(ax, 0.815, 0.54, "TabPFN v2", fs=7.2, bold=True, color=C["red"])
    T(ax, 0.815, 0.522, "Pre-trained on synthetic tabular tasks", fs=4.8, bold=True, color=C["red"])
    T(ax, 0.815, 0.507, "(weights frozen during this study)", fs=4.6, color=C["red"])
    T(ax, 0.815, 0.493, "0 trainable parameters on OASIS-1", fs=4.8, bold=True)
    # context / query table
    tx, cw, rh = 0.662, 0.0122, 0.026
    T(ax, tx + 3.5 * cw + 0.002, 0.468, "Context (training)", fs=4.6, bold=True)
    T(ax, tx + 3 * cw, 0.452, r"Features $\mathbf{x}$", fs=4.6)
    T(ax, tx + 6.5 * cw + 0.006, 0.452, r"$y$", fs=5.0)
    top = 0.44
    for r_, lab in enumerate("01011"):
        yy = top - (r_ + 1) * rh
        for c_ in range(6):
            ax.add_patch(Rectangle((tx + c_ * cw, yy), cw, rh * 0.86, fc="#f8cdbf", ec=C["red"], lw=0.4, zorder=3))
        ax.add_patch(Rectangle((tx + 6 * cw + 0.004, yy), cw, rh * 0.86, fc="white", ec=C["red"], lw=0.5, zorder=3))
        T(ax, tx + 6.5 * cw + 0.004, yy + rh * 0.43, lab, fs=5.2)
    T(ax, tx + 3 * cw, top - 5 * rh - 0.01, "...", fs=5.4)
    T(ax, tx - 0.008, top - 2.5 * rh, "Context", fs=5.0, rot=90, color=C["red"])
    T(ax, tx + 3.5 * cw + 0.002, 0.27, "Query (test)", fs=4.6, bold=True)
    qy = 0.236
    for c_ in range(6):
        ax.add_patch(Rectangle((tx + c_ * cw, qy), cw, rh * 0.86, fc="#eaf2fb", ec=C["blue"], lw=0.4, zorder=3))
    ax.add_patch(Rectangle((tx + 6 * cw + 0.004, qy), cw, rh * 0.86, fc="white", ec=C["grey"], lw=0.5, zorder=3))
    T(ax, tx + 6.5 * cw + 0.004, qy + rh * 0.43, "?", fs=5.6, bold=True)
    T(ax, tx - 0.008, qy + rh * 0.43, "Query", fs=5.0, rot=90, color=C["blue"])
    poly(ax, [(0.61, 0.192), (0.641, 0.192), (0.641, qy + rh * 0.43), (tx - 0.014, qy + rh * 0.43)])
    poly(ax, [(0.332, 0.138), (0.332, 0.134), (0.646, 0.134), (0.646, top - 3.5 * rh), (tx - 0.014, top - 3.5 * rh)])
    # transformer
    bx, bw = 0.763, 0.09
    box(ax, bx, 0.215, bw, 0.255, C["red_f"], C["red"], lw=1.1)
    T(ax, bx + bw / 2, 0.452, "Transformer", fs=5.6, bold=True)
    T(ax, bx + bw / 2, 0.435, "(frozen weights)", fs=4.9)
    for i, s in enumerate(["self-attention\nacross features", "attention across\ncontext samples",
                           "query attends\nto context only"]):
        box(ax, bx + 0.006, 0.384 - i * 0.05, bw - 0.012, 0.04, "white", C["red"], lw=0.6)
        T(ax, bx + bw / 2, 0.404 - i * 0.05, s, fs=4.5)
    T(ax, bx + bw / 2, 0.23, r"$\times\,L$ layers", fs=5.4, color=C["red"])
    arrow(ax, (0.808, 0.488), (0.808, 0.47))
    arrow(ax, (tx + 7 * cw + 0.006, 0.372), (bx, 0.372))
    arrow(ax, (tx + 7 * cw + 0.006, qy + rh * 0.43), (bx, qy + rh * 0.43))
    # outputs
    ox, ow = 0.862, 0.123
    box(ax, ox, 0.39, ow, 0.07, C["purple_f"], C["purple"], lw=1.0)
    T(ax, ox + ow / 2, 0.443, "Predictive\ndistribution", fs=4.8, bold=True)
    T(ax, ox + ow / 2, 0.413, r"$q_\theta(y\mid\mathbf{x}_\ast,\mathcal{D}_{\mathrm{train}})$", fs=5.6)
    box(ax, ox, 0.322, ow, 0.05, C["blue_f"], C["blue"], lw=1.0)
    T(ax, ox + ow / 2, 0.355, "Predicted dementia\nprobability", fs=5.0, bold=True)
    T(ax, ox + ow / 2, 0.332, r"$P(\mathrm{CDR}>0)$", fs=5.4)
    box(ax, ox, 0.262, ow, 0.042, "white", C["grey"], lw=0.9)
    T(ax, ox + ow / 2, 0.288, "Classification", fs=5.4, bold=True)
    T(ax, ox + ow / 2, 0.272, r"(threshold $\tau=0.5$)", fs=5.0)
    box(ax, ox, 0.2, 0.0595, 0.046, C["green_f"], C["green"], lw=0.9)
    T(ax, ox + 0.0298, 0.223, "Cognitively\nnormal\n(CDR = 0)", fs=4.4, bold=True, color=C["green"])
    box(ax, ox + 0.0635, 0.2, 0.0595, 0.046, C["red_f"], C["red"], lw=0.9)
    T(ax, ox + 0.0933, 0.223, "Dementia\nspectrum\n(CDR > 0)", fs=4.4, bold=True, color=C["red"])
    arrow(ax, (bx + bw, 0.425), (ox, 0.425))
    arrow(ax, (ox + ow / 2, 0.39), (ox + ow / 2, 0.372))
    arrow(ax, (ox + ow / 2, 0.322), (ox + ow / 2, 0.304))
    arrow(ax, (ox + 0.045, 0.262), (ox + 0.0298, 0.246))
    arrow(ax, (ox + 0.078, 0.262), (ox + 0.0933, 0.246))
    box(ax, 0.7, 0.145, 0.22, 0.036, "white", C["red"], lw=0.8)
    T(ax, 0.81, 0.163, "In-context learning inference\n(no gradient training on patient data)", fs=5.0,
      color=C["red"])

    # ================= (d) evaluation
    box(ax, 0.008, 0.008, 0.984, 0.112, C["grey_f"], C["grey"], lw=1.0)
    T(ax, 0.018, 0.104, "(d) Evaluation protocol and analyses", fs=7.2, bold=True, serif=True, ha="left")
    items = [("Frozen subject-level", "5-fold CV × 5 seeds\n(25 outer folds)"),
             ("Inner 3-fold CV", "select k only\n(ROC-AUC)"),
             ("Metrics", "accuracy, balanced accuracy,\nmacro-F1, MCC, sens., spec.,\nROC-AUC, PR-AUC, Brier, ECE"),
             ("Statistical comparison", "paired Wilcoxon (Holm),\nNadeau–Bengio test"),
             ("Additional analyses", "modality ablation, CDR 0 vs 0.5,\ncalibration, subgroups"),
             ("Embedding leakage audit", "third-party vs label-free\nMRI embeddings")]
    x0, gap = 0.018, 0.012
    w = (0.982 - x0 - gap * (len(items) - 1)) / len(items)
    for i, (h, s) in enumerate(items):
        xi = x0 + i * (w + gap)
        box(ax, xi, 0.016, w, 0.072, "white", C["blue"], lw=0.8)
        T(ax, xi + w / 2, 0.075, h, fs=5.0, bold=True)
        T(ax, xi + w / 2, 0.043, s, fs=4.2)
        if i:
            arrow(ax, (xi - gap, 0.052), (xi, 0.052), color=C["blue"])

    import io
    fig.savefig(FIG_DIR / "fig1_architecture.pdf", bbox_inches="tight", pad_inches=0.02)
    buf = io.BytesIO()                       # write PNG via memory (direct 600-dpi write fails on this system)
    fig.savefig(buf, format="png", dpi=600, bbox_inches="tight", pad_inches=0.02)
    for target in (FIG_DIR / "fig1_architecture.png", run.path("fig1_architecture.png")):
        target.write_bytes(buf.getvalue())
    run.outputs.append(run.path("fig1_architecture.png"))
    plt.close(fig)
    print("saved", FIG_DIR / "fig1_architecture.pdf")
