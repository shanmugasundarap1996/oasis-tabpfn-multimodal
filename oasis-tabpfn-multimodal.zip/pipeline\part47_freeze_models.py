"""Part 47 - Amendment 9, phase 1: freeze the OASIS-1 models for locked external validation.

Each model is fitted once on all 166 primary OASIS-1 subjects. The MRI PCA k is chosen by 5-fold stratified CV on
OASIS-1 (seed 42, ROC-AUC); baselines use the main-analysis grids; threshold 0.5. Artifacts (joblib) and metadata
(JSON: k*, feature order, threshold, versions, input hashes, OASIS-1 reference distribution) are written to
outputs/part47_frozen_<source>/. Usage: python part47_freeze_models.py official | harmonised
  official   : MRI features from the official OASIS-1 T88 volumes (Part 29) - reference only
  harmonised : MRI features from pipeline H (Part 43) - the locked models for external MRI data"""
import json
import sys

import joblib
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.pipeline import Pipeline

import config
import tabpfn_retry  # noqa: F401
from common import PhaseRun, embedding_cols, load_cohort, sha256
from compare_tools import NESTED_K
from models import build, preprocessor

SOURCE = sys.argv[1] if len(sys.argv) > 1 else "harmonised"
EMB = {"official": config.RAW_DIR / "mri_embeddings_own.csv",
       "harmonised": config.OUTPUT_DIR / "part43_harmonised_mri_collect" / "mri_harmonised_oasis1.csv"}[SOURCE]
TRANSPORT = ["Age", "sex_binary", "Educ", "MMSE"]
C5 = config.CLINICAL_FULL
CV = StratifiedKFold(5, shuffle=True, random_state=42)


def tabpfn(mri, tab):
    from tabpfn import TabPFNClassifier
    from tabpfn.constants import ModelVersion
    return Pipeline([("prep", preprocessor(mri, tab, pca_dim=8 if mri else None)),
                     ("clf", TabPFNClassifier.create_default_for_version(ModelVersion.V2, device="cpu", random_state=42))])


def k_grid():
    return {"prep__mri__pca": [PCA(n_components=k, random_state=42) for k in NESTED_K]}


with PhaseRun(f"part47_frozen_{SOURCE}", __file__, inputs=[config.COHORT_FILE, EMB],
              params={"source": SOURCE, "k_grid": list(NESTED_K), "cv": "5-fold stratified, seed 42"}) as run:
    base = load_cohort()
    df = base.drop(columns=embedding_cols(base)).merge(pd.read_csv(EMB), on="subject_id", how="left", validate="one_to_one")
    df = df.set_index("subject_id").loc[base.subject_id].reset_index()
    emb = embedding_cols(df)
    assert df[emb].notna().all().all(), "MRI features missing for some cohort subjects"
    y = df[config.TARGET_COL].to_numpy()

    specs = {  # name: (pipeline, grid, mri cols, tabular cols)
        "multimodal_transportable_TabPFN": (tabpfn(emb, TRANSPORT), k_grid(), emb, TRANSPORT),
        "multimodal_full_TabPFN": (tabpfn(emb, C5), k_grid(), emb, C5),
        "clinical_transportable_TabPFN": (tabpfn((), TRANSPORT), {}, [], TRANSPORT),
        "clinical_full_TabPFN": (tabpfn((), C5), {}, [], C5),
        "mri_only_TabPFN": (tabpfn(emb, ()), k_grid(), emb, []),
    }
    for name, learner, mri, tab in [("mri_only_LR", "LR", emb, ()), ("fusion_transportable_LR", "LR", emb, TRANSPORT),
                                    ("fusion_transportable_XGBoost", "XGBoost", emb, TRANSPORT)]:
        pipe, grid = build(learner, mri_cols=mri, tab_cols=tab, pca_dim=8,
                           extra_grid={"prep__mri__pca__n_components": list(NESTED_K)})
        specs[name] = (pipe, grid, list(mri), list(tab))

    meta_all = {}
    for name, (pipe, grid, mri, tab) in specs.items():
        feats = list(mri) + list(tab)
        if grid:
            gs = GridSearchCV(pipe, grid, scoring="roc_auc", cv=CV, refit=True, n_jobs=1).fit(df[feats], y)
            fitted, best, cv_auc = gs.best_estimator_, {k: str(v) for k, v in gs.best_params_.items()}, float(gs.best_score_)
        else:
            fitted, best, cv_auc = pipe.fit(df[feats], y), {}, float("nan")
        art = run.dir / f"{name}.joblib"
        joblib.dump(fitted, art)
        meta = {"model": name, "mri_source": SOURCE, "features_in_order": feats, "mri_features": list(mri),
                "tabular_features": list(tab), "selected_params": best, "oasis1_5fold_cv_auc_of_selected": cv_auc,
                "decision_threshold": config.DECISION_THRESHOLD, "n_train": int(len(y)), "n_pos": int(y.sum()),
                "artifact": art.name, "artifact_sha256": sha256(art),
                "reference_distribution": {c: {"mean": float(df[c].mean()), "std": float(df[c].std())} for c in tab}}
        meta_all[name] = meta
        print(f"  {name}: {best} cv_auc={cv_auc:.3f}", flush=True)
    import sklearn, tabpfn, xgboost
    versions = {"sklearn": sklearn.__version__, "tabpfn": tabpfn.__version__, "xgboost": xgboost.__version__,
                "numpy": np.__version__, "pandas": pd.__version__}
    out = {"models": meta_all, "versions": versions, "cohort_sha256": sha256(config.COHORT_FILE), "mri_sha256": sha256(EMB)}
    (run.dir / "FROZEN_MODELS.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    run.outputs.append(run.dir / "FROZEN_MODELS.json")
