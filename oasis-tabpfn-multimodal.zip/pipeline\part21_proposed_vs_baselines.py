"""Part 21 - Proposed systems vs all baselines (paired over the identical 25 outer folds).

Proposed system 1: TabPFN v2 foundation model on PCA fusion (Part 19 v5).
Proposed system 2: agentic cost-aware acquisition (Part 20), MRI:MMSE cost 10:1, two operating points:
                   lambda = 0.0005 (accuracy-oriented) and lambda = 0.005 (cost-oriented).
Baselines: clinical (C4 no-MMSE, C5), MRI only, fusion LR / XGBoost / RF, GCN / GAT (inductive),
static full-information model S3 (agent's own backbone).
Tests per pair x metric: Wilcoxon signed-rank, Holm across ALL comparisons x metrics of each system,
Nadeau-Bengio corrected t-test (Holm), bootstrap 95% CI, rank-biserial effect size.
"""
import numpy as np
import pandas as pd
from scipy import stats

import config
from common import PhaseRun

OUT = config.OUTPUT_DIR
METRICS = ["mcc", "balanced_accuracy", "macro_f1", "roc_auc"]
N_TRAIN, N_TEST = 133, 33

BASELINES = {
    "Clinical C4 (no MMSE) - LR": ("part04_clinical/fold_metrics.csv", "C4_clinical_no_MMSE", "LR"),
    "Clinical C5 - LR": ("part04_clinical/fold_metrics.csv", "C5_clinical_full", "LR"),
    "Clinical C5 - XGBoost": ("part04_clinical/fold_metrics.csv", "C5_clinical_full", "XGBoost"),
    "MRI only - LR": ("part06_pca/nested_fold_metrics.csv", "MRI_PCA_nested", "LR"),
    "Fusion PCA - LR": ("part07_fusion/fold_metrics.csv", "Fusion_PCA_nested", "LR"),
    "Fusion PCA - XGBoost": ("part07_fusion/fold_metrics.csv", "Fusion_PCA_nested", "XGBoost"),
    "Fusion PCA - RF (strongest)": ("part07_fusion/fold_metrics.csv", "Fusion_PCA_nested", "RF"),
    "GCN inductive": ("part10_inductive/fold_metrics.csv", "GNN_inductive", "GCN"),
    "GAT inductive": ("part10_inductive/fold_metrics.csv", "GNN_inductive", "GAT"),
}
AGENT_FILE = OUT / "part20_agent/agent_fold_metrics.csv"
TABPFN_FILE = OUT / "part19_v5_tabpfn/fold_metrics.csv"


def load(f, g, m):
    t = pd.read_csv(OUT / f)
    return t[(t.group == g) & (t.model == m)].set_index(["seed", "fold"]).sort_index()


def agent_rows(policy, param):
    a = pd.read_csv(AGENT_FILE)
    a = a[(a.scenario == "full_availability") & (a.mri_cost_ratio == 10) & (a.policy == policy)]
    a = a[a.param.astype(str) == str(param)]
    return a.set_index(["seed", "fold"]).sort_index()


def holm(p):
    p = np.asarray(p, float)
    out, running = np.empty_like(p), 0.0
    for rank, i in enumerate(np.argsort(p)):
        running = max(running, (len(p) - rank) * p[i])
        out[i] = min(running, 1.0)
    return out


def rank_biserial(d):
    d = d[d != 0]
    if len(d) == 0:
        return 0.0
    r = stats.rankdata(np.abs(d))
    return float((r[d > 0].sum() - r[d < 0].sum()) / r.sum())


def nb(d):
    v = np.var(d, ddof=1)
    if v == 0:
        return 1.0
    t = d.mean() / np.sqrt((1 / len(d) + N_TEST / N_TRAIN) * v)
    return float(2 * stats.t.sf(abs(t), len(d) - 1))


def compare(system, S, refs):
    rows = []
    for name, R in refs.items():
        assert (S.index == R.index).all() and len(S) == 25
        for m in METRICS:
            d = (S[m] - R[m]).to_numpy()
            boot = np.random.default_rng(0).choice(d, (10000, len(d))).mean(1)
            rows.append({"system": system, "baseline": name, "metric": m, "mean_system": S[m].mean(),
                         "mean_baseline": R[m].mean(), "delta": d.mean(), "ci95_low": np.percentile(boot, 2.5),
                         "ci95_high": np.percentile(boot, 97.5), "wins": int((d > 0).sum()),
                         "losses": int((d < 0).sum()),
                         "p_wilcoxon": stats.wilcoxon(d).pvalue if np.any(d != 0) else 1.0,
                         "p_nadeau_bengio": nb(d), "rank_biserial": rank_biserial(d)})
    t = pd.DataFrame(rows)
    t["p_holm"] = holm(t.p_wilcoxon)
    t["p_nb_holm"] = holm(t.p_nadeau_bengio)
    t["verdict"] = np.where((t.p_holm < 0.05) & (t.delta > 0), "significantly BETTER",
                   np.where((t.p_holm < 0.05) & (t.delta < 0), "significantly WORSE", "not significant"))
    t["robust_to_NB"] = t.p_nb_holm < 0.05
    return t


with PhaseRun("part21_proposed_vs_baselines", __file__,
              inputs=[TABPFN_FILE, AGENT_FILE] + sorted({str(OUT / v[0]) for v in BASELINES.values()}),
              params={"metrics": METRICS, "holm_scope": "per proposed system, all baselines x metrics"}) as run:
    refs = {k: load(*v) for k, v in BASELINES.items()}
    tab = pd.read_csv(TABPFN_FILE).set_index(["seed", "fold"]).sort_index()
    s1 = compare("System 1: TabPFN v2", tab, refs)

    refs2 = dict(refs)
    refs2["Static full-information S3 (agent backbone)"] = agent_rows("static", "S3")
    refs2["Static clinical S1 (demographics + MMSE)"] = agent_rows("static", "S1")
    refs2["Static MRI S2 (demographics + MRI)"] = agent_rows("static", "S2")
    out2 = []
    for lam in ["0.0005", "0.005"]:
        A = agent_rows("agent", lam)
        r = dict(refs2)
        r["Random MRI allocation (same MRI rate)"] = agent_rows("random_matched", lam)
        t = compare(f"System 2: Agent (lambda={lam})", A, r)
        t["system_mri_rate"] = A.mri_rate.mean()
        t["system_mean_cost"] = A.mean_cost.mean()
        out2.append(t)
    s2 = pd.concat(out2, ignore_index=True)
    res = pd.concat([s1, s2], ignore_index=True)
    run.save_csv(res, "proposed_vs_baselines.csv")

    pd.set_option("display.width", 260)
    show = ["baseline", "mean_system", "mean_baseline", "delta", "ci95_low", "ci95_high", "wins", "losses",
            "p_holm", "p_nb_holm", "verdict"]
    for sysname, g in res.groupby("system", sort=False):
        for m in ["mcc", "roc_auc"]:
            print(f"\n=== {sysname} | {m}")
            print(g[g.metric == m][show].round(4).to_string(index=False))
    summ = res.groupby(["system", "metric", "verdict"]).size().unstack(fill_value=0)
    run.save_csv(summ.reset_index(), "verdict_counts.csv")
    print("\nVerdict counts:\n", summ.to_string())
