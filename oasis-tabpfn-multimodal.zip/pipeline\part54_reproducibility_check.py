"""Part 54 - Amendment 12: the frozen models (Part 47, hash-checked) re-applied to the saved external features must
reproduce the saved Part 48 predictions exactly."""
import json

import joblib
import numpy as np
import pandas as pd

import config
import tabpfn_retry  # noqa: F401
from common import PhaseRun, sha256

FROZEN = config.OUTPUT_DIR / "part47_frozen_harmonised"
P48 = config.OUTPUT_DIR / "part48_external_oasis2"

with PhaseRun("part54_reproducibility_check", __file__,
              inputs=[FROZEN / "FROZEN_MODELS.json", P48 / "external_cohort_with_features.csv"]) as run:
    meta = json.loads((FROZEN / "FROZEN_MODELS.json").read_text(encoding="utf-8"))["models"]
    data = pd.read_csv(P48 / "external_cohort_with_features.csv")
    rows = []
    for subset in ["overlap-screened", "all"]:
        saved = pd.read_csv(P48 / f"predictions_label_cdr_{subset}.csv")
        d = data.set_index("subject_id").loc[saved.subject_id].reset_index()
        for name, m in meta.items():
            col = f"p_{name}"
            if col not in saved.columns:
                continue
            art = FROZEN / m["artifact"]
            ok_hash = sha256(art) == m["artifact_sha256"]
            p = joblib.load(art).predict_proba(d[m["features_in_order"]])[:, 1]
            rows.append({"subset": subset, "model": name, "hash_ok": ok_hash, "n": len(p),
                         "max_abs_diff": float(np.max(np.abs(p - saved[col].to_numpy())))})
    t = pd.DataFrame(rows)
    t["reproduced"] = t.hash_ok & (t.max_abs_diff < 1e-9)
    run.save_csv(t, "reproducibility.csv")
    print(t.to_string(index=False))
    print("ALL REPRODUCED" if t.reproduced.all() else "MISMATCH")
