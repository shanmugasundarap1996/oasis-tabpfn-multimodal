"""Part 46 - read-only results report: every number is read from the saved result files (no model is run).
Writes RESULTS_EVIDENCE.md (results tables + the file each number comes from) to outputs/part46_results_evidence/."""
import pandas as pd

import config

O = config.OUTPUT_DIR
OUT = O / "part46_results_evidence"
OUT.mkdir(exist_ok=True)
lines = []


def h(t):
    lines.append(f"\n## {t}\n")


def src(*files):
    lines.append("*Source:* " + ", ".join(f"`outputs/{f}`" for f in files) + "\n")


def md(df):
    cols = [str(c) for c in df.columns]
    lines.append("| " + " | ".join(cols) + " |")
    lines.append("|" + "---|" * len(cols))
    for row in df.itertuples(index=False):
        lines.append("| " + " | ".join("" if pd.isna(v) else str(v) for v in row) + " |")
    lines.append("")


def fmt(x, d=3):
    return "<0.001" if isinstance(x, float) and x < 0.001 else (f"{x:.{d}f}" if isinstance(x, float) else x)


def summary(path, models=None, cols=("balanced_accuracy_mean", "mcc_mean", "roc_auc_mean", "brier_mean")):
    s = pd.read_csv(O / path)
    if models:
        s = s[s.model.isin(models)]
    t = s[["model", *cols]].copy()
    t.columns = ["Model", *[c.replace("_mean", "").replace("balanced_accuracy", "BA").replace("roc_auc", "AUC")
                             .replace("mcc", "MCC").replace("brier", "Brier") for c in cols]]
    return t.round(3)


def tests(path, metrics=("mcc", "roc_auc", "brier"), extra=None):
    t = pd.read_csv(O / path)
    t = t[t.metric.isin(metrics)]
    keep = ["comparator", "metric", "delta", "ci95_low", "ci95_high", "p_wilcoxon", "p_holm", "p_nb_holm"] + (extra or [])
    t = t[keep].copy()
    t["significant (p_Holm<0.05)"] = (t.p_holm < 0.05).map({True: "YES", False: "no"})
    t["robust (also NB)"] = ((t.p_holm < 0.05) & (t.p_nb_holm < 0.05)).map({True: "YES", False: "no"})
    for c in ["delta", "ci95_low", "ci95_high"]:
        t[c] = t[c].round(3)
    for c in ["p_wilcoxon", "p_holm", "p_nb_holm"] + (extra or []):
        t[c] = t[c].map(lambda v: fmt(float(v), 4))
    return t


lines.append("# Results and evidence (Draft 7a) — generated from saved result files by part46_results_evidence_report.py\n")
lines.append("Primary test (pre-specified): paired two-sided Wilcoxon over 25 outer folds, Holm-corrected within each family. "
             "Sensitivity: Nadeau–Bengio corrected resampled t-test (NB), Holm-corrected. 'Robust' = significant under both.\n")

h("1. Main benchmark — performance (25 outer folds, mean)")
md(summary("part30_own_mri_benchmark/summary.csv"))
md(summary("part33_own_modern_and_recal/summary.csv"))
src("part30_own_mri_benchmark/summary.csv", "part33_own_modern_and_recal/summary.csv",
    "part04_clinical/summary.csv (clinical C4/C5)")

h("2. Main benchmark — proposed TabPFN vs baselines (primary test)")
md(tests("part30_own_mri_benchmark/tabpfn_vs_baselines_own.csv"))
src("part30_own_mri_benchmark/tabpfn_vs_baselines_own.csv")
md(tests("part33_own_modern_and_recal/tabpfn_vs_modern_recal_own.csv", metrics=("mcc", "roc_auc", "brier", "ece")))
src("part33_own_modern_and_recal/tabpfn_vs_modern_recal_own.csv")

h("3. Global Holm correction over all 84 tests (Parts 30, 31-ablation, 33, 36) — significant rows")
g = pd.read_csv(O / "part41_importance_calibration/global_holm.csv")
g = g[g.sig_family][["family", "comparator", "metric", "delta", "p_holm", "p_holm_global", "sig_global"]]
g["delta"] = g.delta.round(3)
g["p_holm"] = g.p_holm.map(lambda v: fmt(float(v), 4))
g["p_holm_global"] = g.p_holm_global.map(lambda v: fmt(float(v), 4))
md(g)
src("part41_importance_calibration/global_holm.csv")

h("4. Subject-level bootstrap (Amendment 8; resamples subjects, Holm over 33 tests)")
sb = pd.read_csv(O / "part45_subject_bootstrap/subject_bootstrap.csv")
sb["significant (p_Holm<0.05)"] = (sb.p_holm < 0.05).map({True: "YES", False: "no"})
for c in ["proposed", "comparator_value", "delta", "ci95_low", "ci95_high"]:
    sb[c] = sb[c].round(3)
sb["p_boot"] = sb.p_boot.map(lambda v: fmt(float(v), 4))
sb["p_holm"] = sb.p_holm.map(lambda v: fmt(float(v), 3))
md(sb)
src("part45_subject_bootstrap/subject_bootstrap.csv")

h("5. Modality ablation within TabPFN and CDR 0 vs 0.5")
md(tests("part31_own_mri_extended/ablation_vs_full.csv", metrics=("mcc", "balanced_accuracy", "roc_auc", "brier")))
md(summary("part31_own_mri_extended/cdr05_summary.csv"))
md(tests("part31_own_mri_extended/cdr05_tabpfn_vs_baselines.csv"))
src("part31_own_mri_extended/ablation_vs_full.csv", "part31_own_mri_extended/cdr05_summary.csv",
    "part31_own_mri_extended/cdr05_tabpfn_vs_baselines.csv")

h("6. Incremental value of MRI (non-imaging data; without MMSE; demographics)")
md(summary("part39_clinical_sensitivity/summary.csv"))
for f in ["M1_mri_beyond_nonimaging.csv", "M2_without_mmse.csv", "M2b_mri_plus_demographics.csv"]:
    lines.append(f"**{f}**\n")
    md(tests(f"part39_clinical_sensitivity/{f}"))
src("part39_clinical_sensitivity/")
imp = pd.read_csv(O / "part41_importance_calibration/permutation_importance.csv").round(3)
lines.append("**Permutation importance (AUC drop; 10 folds)**\n")
md(imp)
src("part41_importance_calibration/permutation_importance.csv")

h("7. Robustness: tissue morphometry as MRI block")
md(summary("part36_morph_benchmark/summary.csv"))
md(tests("part36_morph_benchmark/v12_vs_baselines.csv"))
src("part36_morph_benchmark/summary.csv", "part36_morph_benchmark/v12_vs_baselines.csv")

h("8. Unfiltered cohort (N = 198, new folds)")
md(summary("part40_full_cohort/summary.csv"))
md(tests("part40_full_cohort/tabpfn_vs_baselines_full.csv"))
src("part40_full_cohort/summary.csv", "part40_full_cohort/tabpfn_vs_baselines_full.csv")

h("9. Calibration slope and subgroups")
md(pd.read_csv(O / "part41_importance_calibration/calibration_slope.csv").round(3))
md(pd.read_csv(O / "part41_importance_calibration/subgroup_calibration.csv").round(3))
gap = pd.read_csv(O / "part34_sex_gap_bootstrap/subgroup_gap_bootstrap.csv")
md(gap.round(3))
src("part41_importance_calibration/calibration_slope.csv", "part41_importance_calibration/subgroup_calibration.csv",
    "part34_sex_gap_bootstrap/subgroup_gap_bootstrap.csv")

h("10. Feature-provenance audit (third-party vs study-label-free embeddings, same models and folds)")
md(tests("part30_own_mri_benchmark/own_vs_kaggle.csv"))
md(pd.read_csv(O / "part30_own_mri_benchmark/embedding_audit.csv").round(3))
src("part30_own_mri_benchmark/own_vs_kaggle.csv", "part30_own_mri_benchmark/embedding_audit.csv")

h("11. OASIS-2 external check and overlap")
ext = pd.read_csv(O / "part42_external_clinical/external_metrics.csv")
md(ext[["model", "subset", "n", "roc_auc", "roc_auc_lo", "roc_auc_hi", "mcc", "brier", "cal_slope"]].round(3))
t29 = pd.read_csv(O / "part42_external_clinical/tabpfn_vs_baselines_independent29.csv").round(4)
lines.append("**Paired tests on the 29 overlap-screened participants**\n")
md(t29[["comparator", "metric", "delta", "ci95_low", "ci95_high", "p_boot", "p_holm"]])
md(pd.read_csv(O / "part44_overlap_image_verification/overlap_summary.csv"))
md(pd.read_csv(O / "part44_overlap_image_verification/image_verification.csv").round(3))
src("part42_external_clinical/external_metrics.csv", "part42_external_clinical/tabpfn_vs_baselines_independent29.csv",
    "part44_overlap_image_verification/overlap_summary.csv", "part44_overlap_image_verification/image_verification.csv")

P48, P50 = O / "part48_external_oasis2", O / "part50_h_fidelity"
if P48.exists():
    h("12. Draft 8: harmonised MRI pipeline fidelity (OASIS-1) and LOCKED external test of the full model (OASIS-2)")
    md(pd.read_csv(P50 / "feature_agreement.csv").round(3))
    md(summary("part50_h_fidelity/summary.csv"))
    md(tests("part50_h_fidelity/h_vs_official.csv"))
    src("part50_h_fidelity/")
    for sub in ["overlap-screened", "all"]:
        lines.append(f"**Locked external metrics, OASIS-2, CDR 0 vs > 0, {sub}** (95% subject-bootstrap CIs)\n")
        m = pd.read_csv(P48 / f"metrics_label_cdr_{sub}.csv")
        md(m[["model", "n", "roc_auc", "roc_auc_lo", "roc_auc_hi", "mcc", "balanced_accuracy", "brier", "sensitivity",
              "specificity", "cal_slope", "citl"]].round(3))
    lines.append("**Paired bootstrap, locked transportable multimodal TabPFN − comparator (overlap-screened, Holm)**\n")
    pp = pd.read_csv(P48 / "paired_label_cdr_overlap-screened.csv")
    md(pp[["comparator", "metric", "delta", "ci95_low", "ci95_high", "p_boot", "p_holm"]].round(3))
    lines.append("**Subgroups, locked transportable multimodal TabPFN (overlap-screened)**\n")
    md(pd.read_csv(P48 / "subgroups_label_cdr_overlap-screened.csv")[["subgroup", "n", "roc_auc", "mcc", "brier"]].round(3))
    src("part48_external_oasis2/", "part47_frozen_harmonised/FROZEN_MODELS.json")

(OUT / "RESULTS_EVIDENCE.md").write_text("\n".join(lines), encoding="utf-8")
print(f"written {OUT / 'RESULTS_EVIDENCE.md'} ({len(lines)} blocks)")
