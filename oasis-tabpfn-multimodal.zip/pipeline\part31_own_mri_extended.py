"""Part 31 - Extended analyses with the documented, label-free MRI features (Part 29):
(a) TabPFN modality ablation on the main task: MRI only, MRI + MMSE, clinical only (8 variables);
(b) early-detection task CDR 0 vs CDR 0.5 (CDR >= 1 removed from training and test):
    TabPFN fusion, fusion RF/LR, clinical-only LR and TabPFN.
Same frozen folds and nested tuning as all other parts. Resumable per fold."""
import pandas as pd

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from compare_tools import paired_table, pca_grid, tabpfn_spec
from models import build

OWN = config.RAW_DIR / "mri_embeddings_own.csv"


def own_cohort():
    base = load_cohort()
    old = embedding_cols(base)
    df = base.drop(columns=old).merge(pd.read_csv(OWN), on="subject_id", how="left", validate="one_to_one")
    return df.set_index("subject_id").loc[base.subject_id].reset_index()


def tabpfn_clin_spec(group, tab, name):
    from sklearn.pipeline import Pipeline
    from tabpfn import TabPFNClassifier
    from tabpfn.constants import ModelVersion
    from models import preprocessor
    pipe = Pipeline([("prep", preprocessor((), tab)),
                     ("clf", TabPFNClassifier.create_default_for_version(ModelVersion.V2, device="cpu", random_state=42))])
    return {"group": group, "name": name, "features": list(tab), "pipeline": pipe, "grid": {"clf__random_state": [42]}}


with PhaseRun("part31_own_mri_extended", __file__,
              inputs=[config.COHORT_FILE, OWN, config.FOLDS_FILE, config.INNER_FOLDS_FILE]) as run:
    df = own_cohort()
    emb = embedding_cols(df)
    C5 = config.CLINICAL_FULL

    # (a) ablation, main task
    specs_a = [tabpfn_spec("Ablation_own", emb, [], name="TabPFN_MRI_only"),
               tabpfn_spec("Ablation_own", emb, ["MMSE"], name="TabPFN_MRI_MMSE"),
               tabpfn_clin_spec("Ablation_own", C5, "TabPFN_clinical_only")]
    fa, pa, ba = run_nested_cv(df, specs_a, ckpt_dir=str(run.dir / "_ckpt_a"))
    run.save_csv(fa, "ablation_fold_metrics.csv"); run.save_csv(pa, "ablation_oof_predictions.csv")
    sa = summarize(fa); run.save_csv(sa, "ablation_summary.csv")
    print("Ablation (own MRI):\n", sa[["model", "balanced_accuracy", "mcc", "roc_auc", "brier"]].to_string(index=False), flush=True)
    p30 = config.OUTPUT_DIR / "part30_own_mri_benchmark" / "fold_metrics.csv"
    if p30.exists():
        full = pd.read_csv(p30)
        tab_a = paired_table(full[full.model == "TabPFN_v2"], "TabPFN_full (own MRI)",
                             {m: fa[fa.model == m] for m in fa.model.unique()})
        run.save_csv(tab_a, "ablation_vs_full.csv")
        print(tab_a[tab_a.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False), flush=True)

    # (b) CDR 0 vs CDR 0.5
    sub = df[df.CDR.isin([0, 0.5])].reset_index(drop=True)
    specs_b = [tabpfn_spec("CDR05_own", emb, C5)]
    for name in ["RF", "LR"]:
        pipe, grid = build(name, mri_cols=emb, tab_cols=C5, pca_dim=8, extra_grid=pca_grid())
        specs_b.append({"group": "CDR05_own", "name": f"Fusion_PCA_{name}", "features": emb + C5, "pipeline": pipe, "grid": grid})
    pipe, grid = build("LR", tab_cols=C5)
    specs_b.append({"group": "CDR05_own", "name": "Clinical_C5_LR", "features": list(C5), "pipeline": pipe, "grid": grid})
    specs_b.append(tabpfn_clin_spec("CDR05_own", C5, "TabPFN_clinical_only"))
    fb, pb, bb = run_nested_cv(sub, specs_b, ckpt_dir=str(run.dir / "_ckpt_b"))
    run.save_csv(fb, "cdr05_fold_metrics.csv"); run.save_csv(pb, "cdr05_oof_predictions.csv")
    sb = summarize(fb); run.save_csv(sb, "cdr05_summary.csv")
    print("CDR 0 vs 0.5 (own MRI):\n", sb[["model", "balanced_accuracy", "mcc", "roc_auc", "brier"]].to_string(index=False))
    n_te = len(sub) / 5
    tab_b = paired_table(fb[fb.model == "TabPFN_v2"], "TabPFN_v2",
                         {m: fb[fb.model == m] for m in fb.model.unique() if m != "TabPFN_v2"},
                         n_tr=len(sub) - n_te, n_te=n_te)
    run.save_csv(tab_b, "cdr05_tabpfn_vs_baselines.csv")
    print(tab_b[tab_b.metric.isin(["mcc", "roc_auc"])].round(4).to_string(index=False))
    assert check_oof_integrity(pa, df) and check_oof_integrity(pb, sub)
