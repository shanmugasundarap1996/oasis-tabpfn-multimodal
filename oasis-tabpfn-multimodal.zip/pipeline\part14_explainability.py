"""Part 14 - Explainability + error analysis.

(a) SHAP for the fusion models (LR: LinearExplainer, XGBoost: TreeExplainer), computed on each
    outer TEST fold with the model fitted on that fold's training data. Because the MRI PCA basis
    differs between folds, MRI components are reported individually per fold and as one aggregated
    "MRI embedding" block; clinical variables are reported by name.
(b) Patient-level explanations for representative TP / TN / FP / FN subjects (seed 42).
(c) Error analysis: per-subject error rate across the 5 repeats of the Fusion-LR OOF predictions,
    clinical profile of consistently misclassified subjects.
(d) Graph neighbourhood: same-class share among each test subject's K nearest training subjects
    (G4 graph) versus whether the fusion model misclassified that subject.
PCA components of a ResNet embedding are not anatomical regions and are not interpreted as such.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
from scipy import stats
from sklearn.decomposition import PCA
from sklearn.model_selection import GridSearchCV

import config
from common import PhaseRun, embedding_cols, inner_splits, iter_outer_folds, load_cohort
from graphs import node_features, test_neighbours
from models import build

PART07_OOF = config.OUTPUT_DIR / "part07_fusion" / "oof_predictions.csv"
NESTED_K = [k for k in config.PCA_DIMS if k <= 64]
CLIN = config.CLINICAL_FULL
CONSISTENT_ERROR = 0.6        # misclassified in >= 3 of 5 repeats


with PhaseRun("part14_xai", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PART07_OOF],
              params={"models": ["LR", "XGBoost"], "consistent_error_threshold": CONSISTENT_ERROR,
                      "graph_for_neighbourhood": "G4_clin+MRI_PCA, K=9, euclidean"}) as run:
    df = load_cohort()
    emb = embedding_cols(df)
    feats = emb + CLIN
    y = df[config.TARGET_COL].to_numpy()
    pca_grid = {"prep__mri__pca": [PCA(n_components=k, random_state=42) for k in NESTED_K] + ["passthrough"]}

    # ---------------- (a) SHAP per outer fold
    rows, local_rows = [], []
    for seed, fold, tr, te in iter_outer_folds(df):
        cv_in = inner_splits(df, seed, fold, tr)
        for name in ["LR", "XGBoost"]:
            pipe, grid = build(name, mri_cols=emb, tab_cols=CLIN, pca_dim=8, extra_grid=pca_grid)
            gs = GridSearchCV(pipe, grid, cv=cv_in, scoring=config.TUNING_SCORING, n_jobs=-1)
            gs.fit(df.iloc[tr][feats], y[tr])
            best = gs.best_estimator_
            Ztr = best.named_steps["prep"].transform(df.iloc[tr][feats])
            Zte = best.named_steps["prep"].transform(df.iloc[te][feats])
            n_mri = Ztr.shape[1] - len(CLIN)
            names = [f"MRI_PC{i + 1}" for i in range(n_mri)] + CLIN
            clf = best.named_steps["clf"]
            if name == "LR":
                sv = shap.LinearExplainer(clf, Ztr).shap_values(Zte)
            else:
                sv = shap.TreeExplainer(clf).shap_values(Zte)
            sv = np.asarray(sv)
            if sv.ndim == 3:
                sv = sv[..., 1]
            mean_abs = np.abs(sv).mean(0)
            for f_name, v in zip(names, mean_abs):
                rows.append({"model": name, "seed": seed, "fold": fold, "feature": f_name, "mean_abs_shap": v})
            rows.append({"model": name, "seed": seed, "fold": fold, "feature": "MRI embedding (all PCs)",
                         "mean_abs_shap": np.abs(sv[:, :n_mri].sum(1)).mean()})
            if seed == 42:
                for j, idx in enumerate(te):
                    local_rows.append({"model": name, "fold": fold, "subject_id": df.subject_id.iloc[idx],
                                       "y_true": int(y[idx]),
                                       "y_prob": float(best.predict_proba(df.iloc[[idx]][feats])[0, 1]),
                                       "MRI embedding (all PCs)": float(sv[j, :n_mri].sum()),
                                       **{c: float(sv[j, n_mri + i]) for i, c in enumerate(CLIN)}})
        print(f"  seed {seed} fold {fold} done")
    shp = pd.DataFrame(rows)
    run.save_csv(shp, "shap_per_fold.csv")
    glob = shp[~shp.feature.str.startswith("MRI_PC")].groupby(["model", "feature"]).mean_abs_shap.agg(
        ["mean", "std"]).reset_index().sort_values(["model", "mean"], ascending=[True, False])
    run.save_csv(glob, "shap_global_importance.csv")
    print("\nGlobal mean |SHAP| (25 test folds):\n", glob.round(4).to_string(index=False))
    pcs = shp[shp.feature.str.startswith("MRI_PC")].groupby(["model", "feature"]).mean_abs_shap.mean()
    run.save_csv(pcs.reset_index(), "shap_mri_components.csv")

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    for ax, name in zip(axes, ["LR", "XGBoost"]):
        g = glob[glob.model == name].iloc[::-1]
        ax.barh(g.feature, g["mean"], xerr=g["std"], color="#5b7fa6", capsize=2)
        ax.set_title(f"Fusion PCA - {name}: mean |SHAP| (log-odds)")
    fig.tight_layout()
    run.save_fig(fig, "fig_shap_global.png")
    plt.close(fig)

    # ---------------- (b) patient-level explanations (seed 42, LR)
    loc = pd.DataFrame(local_rows)
    run.save_csv(loc, "shap_local_seed42.csv")
    lr = loc[loc.model == "LR"].copy()
    lr["pred"] = (lr.y_prob >= 0.5).astype(int)
    lr["case"] = np.select([(lr.y_true == 1) & (lr.pred == 1), (lr.y_true == 0) & (lr.pred == 0),
                            (lr.y_true == 0) & (lr.pred == 1), (lr.y_true == 1) & (lr.pred == 0)],
                           ["TP", "TN", "FP", "FN"], default="NA")
    reps = []
    for case in ["TP", "TN", "FP", "FN"]:
        c = lr[lr.case == case]
        if len(c):
            reps.append(c.iloc[(c.y_prob - c.y_prob.median()).abs().argsort().iloc[0]])
    reps = pd.DataFrame(reps)
    contrib_cols = ["MRI embedding (all PCs)"] + CLIN
    run.save_csv(reps.merge(df[["subject_id", "CDR"] + CLIN], on="subject_id", suffixes=("_shap", "")),
                 "representative_cases.csv")
    fig, axes = plt.subplots(1, len(reps), figsize=(4.2 * len(reps), 3.8), sharex=True)
    for ax, (_, r) in zip(np.atleast_1d(axes), reps.iterrows()):
        vals = r[contrib_cols].astype(float)
        ax.barh(contrib_cols, vals, color=["#b03a2e" if v > 0 else "#2e6fb0" for v in vals])
        ax.axvline(0, color="k", lw=0.6)
        ax.set_title(f"{r.case}: {r.subject_id}\np(CDR>0) = {r.y_prob:.2f}", fontsize=9)
    fig.tight_layout()
    run.save_fig(fig, "fig_patient_explanations.png")
    plt.close(fig)

    # ---------------- (c) error analysis across repeats
    oof = pd.read_csv(PART07_OOF)
    oof = oof[(oof.group == "Fusion_PCA_nested") & (oof.model == "LR")]
    err = oof.assign(wrong=(oof.y_true != oof.y_pred)).groupby("subject_id").agg(
        error_rate=("wrong", "mean"), mean_prob=("y_prob", "mean"), y_true=("y_true", "first")).reset_index()
    err = err.merge(df[["subject_id", "CDR", "Age", "MMSE", "nWBV", "Educ", "SES", "M/F"]], on="subject_id")
    err["consistent_error"] = err.error_rate >= CONSISTENT_ERROR
    run.save_csv(err, "per_subject_error_rates.csv")
    prof_rows = []
    for cls, lab in [(1, "true CDR>0: FN vs TP"), (0, "true CDR=0: FP vs TN")]:
        s = err[err.y_true == cls]
        bad, good = s[s.consistent_error], s[~s.consistent_error]
        for v in ["Age", "MMSE", "nWBV", "Educ", "SES", "CDR"]:
            p = stats.mannwhitneyu(bad[v].dropna(), good[v].dropna()).pvalue if len(bad) > 1 else np.nan
            prof_rows.append({"stratum": lab, "variable": v, "n_consistent_error": len(bad),
                              "mean_error_group": bad[v].mean(), "mean_correct_group": good[v].mean(),
                              "p_mannwhitney": p})
    prof = pd.DataFrame(prof_rows)
    run.save_csv(prof, "error_profile.csv")
    print("\nConsistently misclassified subjects:", int(err.consistent_error.sum()), "of", len(err))
    print(prof.round(4).to_string(index=False))
    cdr_err = err.groupby("CDR").agg(n=("subject_id", "size"), mean_error_rate=("error_rate", "mean"),
                                     consistent_errors=("consistent_error", "sum")).reset_index()
    run.save_csv(cdr_err, "error_rate_by_cdr.csv")
    print("\nError rate by CDR:\n", cdr_err.round(3).to_string(index=False))

    # ---------------- (d) graph neighbourhood purity vs error
    nb_rows = []
    oof_i = oof.set_index(["seed", "subject_id"])
    for seed, fold, tr, te in iter_outer_folds(df):
        Xtr, Xte = node_features(df, emb, tr, te, "G4_clin+MRI_PCA", seed=seed)
        nn = test_neighbours(Xtr, Xte, 9)
        for j, idx in enumerate(te):
            sid = df.subject_id.iloc[idx]
            nb_rows.append({"seed": seed, "subject_id": sid, "y_true": int(y[idx]),
                            "same_class_share": float((y[tr][nn[j]] == y[idx]).mean()),
                            "fusion_wrong": bool(oof_i.loc[(seed, sid), "y_pred"] != y[idx])})
    nb = pd.DataFrame(nb_rows)
    run.save_csv(nb, "neighbourhood_purity.csv")
    nb_sum = nb.groupby("fusion_wrong").same_class_share.agg(["size", "mean", "std"]).reset_index()
    p_nb = stats.mannwhitneyu(nb[nb.fusion_wrong].same_class_share, nb[~nb.fusion_wrong].same_class_share).pvalue
    nb_sum["p_mannwhitney"] = p_nb
    run.save_csv(nb_sum, "neighbourhood_purity_vs_error.csv")
    print("\nSame-class share among 9 nearest training neighbours (G4):\n", nb_sum.round(4).to_string(index=False))
