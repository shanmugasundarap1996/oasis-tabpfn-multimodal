"""Part 19 v8 - TabPFN bagged over MRI PCA dimensions k in {8,16,24,32,64} (mean probability)
+ inner-tuned MCC threshold. Removes the variance of choosing a single k. Resumable."""
import config
from common import PhaseRun
from newmethods import BASELINE_FILE, PROTOCOL_FILE, run_cached_version

KEYS = [f"tabpfn|full|{k}" for k in [8, 16, 24, 32, 64]]


def combine(P, y):
    return (sum(P[k]["oof"] for k in KEYS) / len(KEYS), sum(P[k]["test"] for k in KEYS) / len(KEYS), None)


with PhaseRun("part19_v8_tabpfn_kbag", __file__,
              inputs=[config.COHORT_FILE, config.FOLDS_FILE, config.INNER_FOLDS_FILE, PROTOCOL_FILE, BASELINE_FILE],
              params={"keys": KEYS, "combination": "mean probability", "threshold": "inner-OOF MCC-optimal"}) as run:
    run_cached_version(run, "v8_tabpfn_kbag", KEYS, combine)
