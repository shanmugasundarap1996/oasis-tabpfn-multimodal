@echo off
REM Double-click to resume the experiment queue after a shutdown / interruption.
REM Finished steps are skipped; unfinished steps continue from the last saved fold.
REM Progress: pipeline\outputs\_runner\queue_status.txt
start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0run_queue.ps1"
echo Queue runner started. Progress: %~dp0outputs\_runner\queue_status.txt
timeout /t 5
