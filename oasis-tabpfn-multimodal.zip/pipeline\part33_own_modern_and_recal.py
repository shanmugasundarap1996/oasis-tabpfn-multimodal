"""Part 33 - Modern boosting baselines (CatBoost, LightGBM) and recalibrated fusion-RF (isotonic) on the
documented, label-free MRI features (Part 29); same frozen folds and nested tuning. Resumable per fold."""
import pandas as pd
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline

import config
from common import PhaseRun, check_oof_integrity, embedding_cols, load_cohort, run_nested_cv, summarize
from compare_tools import paired_table, pca_grid
from models import build, preprocessor

OWN = config.RAW_DIR / "mri_embeddings_own.csv"
P30 = config.OUTPUT_DIR / "part30_own_mri_benchmark" / "fold_metrics.csv"

with PhaseRun("part33_own_modern_and_recal", __file__,
              inputs=[config.COHORT_FILE, OWN, config.FOLDS_FILE, config.INNER_FOLDS_FILE, P30]) as run:
    base = load_cohort()
    old = embedding_cols(base)
    df = base.drop(columns=old).merge(pd.read_csv(OWN), on="subject_id", how="left", validate="one_to_one")
    df = df.set_index("subject_id").loc[base.subject_id].reset_index()
    emb, C5 = embedding_cols(df), config.CLINICAL_FULL
    cat = Pipeline([("prep", preprocessor(emb, C5, pca_dim=8)),
                    ("clf", CatBoostClassifier(iterations=300, auto_class_weights="Balanced", verbose=0,
                                               random_seed=42, thread_count=1))])
    lgb = Pipeline([("prep", preprocessor(emb, C5, pca_dim=8)),
                    ("clf", LGBMClassifier(n_estimators=200, class_weight="balanced", random_state=42, n_jobs=1, verbose=-1))])
    rf, rf_grid = build("RF", mri_cols=emb, tab_cols=C5, pca_dim=8, extra_grid=pca_grid())
    rf_iso = CalibratedClassifierCV(rf, method="isotonic", cv=StratifiedKFold(3, shuffle=True, random_state=0))
    specs = [{"group": "OwnMRI", "name": "Fusion_PCA_CatBoost", "features": emb + C5, "pipeline": cat,
              "grid": {**pca_grid(), "clf__depth": [4, 6], "clf__learning_rate": [0.03, 0.1]}},
             {"group": "OwnMRI", "name": "Fusion_PCA_LightGBM", "features": emb + C5, "pipeline": lgb,
              "grid": {**pca_grid(), "clf__num_leaves": [7, 15], "clf__learning_rate": [0.03, 0.1],
                       "clf__min_child_samples": [5, 10]}},
             {"group": "OwnMRI", "name": "Fusion_PCA_RF_isotonic", "features": emb + C5, "pipeline": rf_iso,
              "grid": {f"estimator__{k}": v for k, v in rf_grid.items()}}]
    folds, preds, params = run_nested_cv(df, specs, ckpt_dir=str(run.dir / "_ckpt"))
    run.save_csv(folds, "fold_metrics.csv"); run.save_csv(preds, "oof_predictions.csv")
    run.save_csv(params, "best_params.csv")
    summ = summarize(folds); run.save_csv(summ, "summary.csv")
    print(summ[["model", "balanced_accuracy", "mcc", "roc_auc", "brier", "ece"]].to_string(index=False))
    p30 = pd.read_csv(P30)
    tab = paired_table(p30[p30.model == "TabPFN_v2"], "TabPFN_v2 (own MRI)",
                       {m: folds[folds.model == m] for m in folds.model.unique()},
                       metrics=("mcc", "roc_auc", "brier", "ece"))
    run.save_csv(tab, "tabpfn_vs_modern_recal_own.csv")
    print(tab.round(4).to_string(index=False))
    assert check_oof_integrity(preds, df)
